package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfileEntity(
  @PrimaryKey val id: Int = 1,
  val fullName: String = "Indrajit Hota",
  val email: String = "indrajithota5@gmail.com",
  val gender: String = "Male",
  val isOnboarded: Boolean = true,
  val activeEngagementMinutes: Int = 150,
  val selectedAvatar: String = "Arjun",
  val selectedLanguage: String = "Odia (ଓଡ଼ିଆ)",
  val selectedAccent: String = "Cuttack-Bhubaneswar Standard",
  val arcadeVoiceLanguage: String = "Odia", // Odia or English
  val privacyEncryptionEnabled: Boolean = true,
  val offlineModeActive: Boolean = false
)

@Entity(tableName = "ai_memories")
data class MemoryEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val key: String,
  val value: String,
  val category: String = "General",
  val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "game_scores")
data class GameScoreEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val gameType: String, // SHOOTER, TYPING, MATH, TRIVIA
  val score: Int,
  val accuracyPercent: Int = 100,
  val difficulty: String = "Normal",
  val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_badges")
data class BadgeEntity(
  @PrimaryKey val badgeId: String,
  val title: String,
  val tierName: String,
  val description: String,
  val isUnlocked: Boolean,
  val progress: Float, // 0.0 to 1.0
  val unlockedDate: String? = null
)
