package com.example.data.ai

enum class AgentType(
  val id: String,
  val displayName: String,
  val tag: String,
  val description: String,
  val iconName: String,
  val systemPrompt: String
) {
  PERSONAL_LIFE(
    "life",
    "Life Manager",
    "PAIOS Core",
    "Habit tracking, daily routines, emotional reflection, and personal executive assistant.",
    "Person",
    "You are the Hotaji Personal Life Manager Agent. You help users maintain balanced lifestyles, daily schedules, emotional mindfulness, and goal execution with empathy and precision. Follow Epistemic Labeling ([FACT], [INTERPRETATION], [TRADITIONAL BELIEF], [OPINION], [UNCERTAIN])."
  ),
  ACADEMIC(
    "academic",
    "Academic Scholar",
    "STEM & Humanities",
    "Rigorous research, mathematics, physics, history, and Odia Barnabodha language pedagogy.",
    "School",
    "You are the Hotaji Academic Scholar Agent. Master of STEM, mathematics derivations, world history, and linguistic fundamentals including Odia Barnabodha. Always verify facts and tag epistemic certainty."
  ),
  FINANCE(
    "finance",
    "Finance & Wealth",
    "Markets & Budget",
    "Personal budgeting, macroeconomics, portfolio allocation frameworks, and financial literacy.",
    "MonetizationOn",
    "You are the Hotaji Finance Agent. Provide analytical breakdown of financial concepts, budgeting strategies, and economic insights. Clearly distinguish [FACT] from [OPINION] and [UNCERTAIN]."
  ),
  CAREER_WRITING(
    "career",
    "Career & Writing",
    "Executive Prose",
    "Resume crafting, executive memo drafting, creative storytelling, and speechwriting.",
    "EditNote",
    "You are the Hotaji Career & Writing Agent. Help users write powerful, persuasive prose, technical documentation, speeches, and career development roadmaps."
  ),
  CODE_ARCHITECT(
    "code",
    "Code Architect",
    "Systems & Algorithmic",
    "Full-stack architecture, Kotlin, systems engineering, optimization, and clean code principles.",
    "Terminal",
    "You are the Hotaji Code Architect. Master of systems programming, Kotlin, Android, cloud infrastructure, and low-latency architectures. Deliver clean, high-performance code."
  ),
  LIFESTYLE(
    "lifestyle",
    "Lifestyle & Health",
    "Wellness & Nutrition",
    "Sleep hygiene, workout routines, nutrition science, and mind-body balance.",
    "FitnessCenter",
    "You are the Hotaji Lifestyle & Health Agent. Offer wellness suggestions backed by nutritional science and circadian biology. Note: Not a substitute for licensed medical practitioners."
  ),
  SPIRITUAL_LIBRARY(
    "spiritual",
    "Spiritual & Heritage Library",
    "Universal Wisdom",
    "Comparative theology and philosophy across Bhagavad Gita, Quran, Bible, Vedas, Upanishads, and Jagannath Sanskruti.",
    "AutoStories",
    "You are the Hotaji Spiritual & Heritage Library Agent. Maintain strict neutrality, deep respect, and historical depth across all scriptures (Gita, Quran, Bible, Vedas, Upanishads, and Odia heritage). Use [TRADITIONAL BELIEF] and [INTERPRETATION] tags appropriately."
  )
}

data class EpistemicSegment(
  val tag: String, // FACT, INTERPRETATION, TRADITIONAL BELIEF, OPINION, UNCERTAIN, or NONE
  val content: String
)

object EpistemicParser {
  private val forbiddenKeywords = listOf(
    "suicide", "kill yourself", "bomb", "explosive", "hack government", "child abuse", "ddos bank"
  )

  fun checkSafetyViolation(input: String): Boolean {
    val lower = input.lowercase()
    return forbiddenKeywords.any { lower.contains(it) }
  }

  fun parseEpistemicTags(rawText: String): List<EpistemicSegment> {
    val regex = Regex("""\[(FACT|INTERPRETATION|TRADITIONAL BELIEF|OPINION|UNCERTAIN)\]""", RegexOption.IGNORE_CASE)
    val matches = regex.findAll(rawText).toList()

    if (matches.isEmpty()) {
      return listOf(EpistemicSegment("NONE", rawText))
    }

    val segments = mutableListOf<EpistemicSegment>()
    var currentIndex = 0

    for (i in matches.indices) {
      val match = matches[i]
      val tag = match.groupValues[1].uppercase()
      val tagStartIndex = match.range.first
      val contentStartIndex = match.range.last + 1

      if (tagStartIndex > currentIndex) {
        val prefix = rawText.substring(currentIndex, tagStartIndex).trim()
        if (prefix.isNotEmpty()) {
          segments.add(EpistemicSegment("NONE", prefix))
        }
      }

      val contentEndIndex = if (i < matches.size - 1) {
        matches[i + 1].range.first
      } else {
        rawText.length
      }

      val content = rawText.substring(contentStartIndex, contentEndIndex).trim()
      segments.add(EpistemicSegment(tag, content))
      currentIndex = contentEndIndex
    }

    return segments
  }
}
