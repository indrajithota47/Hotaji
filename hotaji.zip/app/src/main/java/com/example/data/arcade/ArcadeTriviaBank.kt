package com.example.data.arcade

import java.util.Random

enum class TriviaCategory(val displayName: String, val badgeColorName: String) {
  ALL("All Categories", "AestheticGold"),
  ODISHA_CULTURE("Odisha & Heritage", "SoftAqua"),
  SCIENCE_NATURE("Science & Nature", "OceanBlue"),
  ANIMALS_WILDLIFE("Animals & Wildlife", "SoftAqua"),
  EVERYDAY_GK("General Knowledge", "AestheticGold"),
  FUNNY_RIDDLES("Funny Riddles", "MetallicGoldLight")
}

data class TriviaQuestion(
  val id: Int,
  val question: String,
  val options: List<String>,
  val correctIndex: Int,
  val category: TriviaCategory,
  val explanation: String,
  val odiaTranslation: String = ""
)

object ArcadeTriviaBank {
  private val random = Random()

  // Comprehensive Handcrafted Offline Knowledge Base
  private val curatedTriviaDatabase = listOf(
    // === ODISHA CULTURE & HERITAGE ===
    TriviaQuestion(
      id = 1,
      question = "Which famous temple in Odisha is known across the world as the 'Black Pagoda'?",
      options = listOf("Konark Sun Temple", "Jagannath Temple Puri", "Lingaraj Temple", "Rajarani Temple"),
      correctIndex = 0,
      category = TriviaCategory.ODISHA_CULTURE,
      explanation = "Konark Sun Temple, built by King Narasimhadeva I in the 13th century, was called the 'Black Pagoda' by European sailors.",
      odiaTranslation = "କୋଣାର୍କ ସୂର୍ଯ୍ୟ ମନ୍ଦିରକୁ 'ବ୍ଲାକ୍ ପାଗୋଡା' ବୋଲି କୁହାଯାଏ।"
    ),
    TriviaQuestion(
      id = 2,
      question = "What is the largest brackish water coastal lagoon in India, located in Odisha?",
      options = listOf("Chilika Lake", "Ansupa Lake", "Kanjia Lake", "Kolab Reservoir"),
      correctIndex = 0,
      category = TriviaCategory.ODISHA_CULTURE,
      explanation = "Chilika Lake is Asia's largest brackish water lagoon and home to the endangered Irrawaddy dolphins and millions of migratory birds.",
      odiaTranslation = "ଚିଲିକା ହ୍ରଦ ଭାରତର ବୃହତ୍ତମ ଲବଣାକ୍ତ ହ୍ରଦ।"
    ),
    TriviaQuestion(
      id = 3,
      question = "Who wrote the foundational Odia educational primer 'Barnabodha' (ବର୍ଣ୍ଣବୋଧ)?",
      options = listOf("Bhakta Kabi Madhusudan Rao", "Fakir Mohan Senapati", "Radhanath Ray", "Upendra Bhanja"),
      correctIndex = 0,
      category = TriviaCategory.ODISHA_CULTURE,
      explanation = "Bhakta Kabi Madhusudan Rao authored the iconic 'Barnabodha' in 1895, which has educated generations of Odia children.",
      odiaTranslation = "ଭକ୍ତକବି ମଧୁସୂଦନ ରାଓ ୧୮୯୫ ମସିହାରେ ବର୍ଣ୍ଣବୋଧ ରଚନା କରିଥିଲେ।"
    ),
    TriviaQuestion(
      id = 4,
      question = "Which world-famous sweet delicacy originated in Nayagarh district of Odisha?",
      options = listOf("Chhena Poda", "Rasagola", "Chhena Gaja", "Rasabali"),
      correctIndex = 0,
      category = TriviaCategory.ODISHA_CULTURE,
      explanation = "Chhena Poda was invented by Sudarsan Sahoo in Dasapalla, Nayagarh, by baking cottage cheese and caramelized sugar overnight.",
      odiaTranslation = "ଛେନାପୋଡ଼ ନୟାଗଡ଼ ଜିଲ୍ଲାର ଦଶପଲ୍ଲାରେ ଉଦ୍ଭାବିତ ହୋଇଥିଲା।"
    ),
    TriviaQuestion(
      id = 5,
      question = "What are the names of the three majestic chariots in Puri Ratha Yatra?",
      options = listOf("Nandighosha, Taladhwaja & Darpadalana", "Pushpaka, Garuda & Mayura", "Indra, Varuna & Agni", "Surya, Chandra & Vayu"),
      correctIndex = 0,
      category = TriviaCategory.ODISHA_CULTURE,
      explanation = "Lord Jagannath rides Nandighosha, Lord Balabhadra rides Taladhwaja, and Devi Subhadra rides Darpadalana (Padmadhwaja).",
      odiaTranslation = "ରଥ ତିନୋଟିର ନାମ: ନନ୍ଦିଘୋଷ, ତାଳଧ୍ୱଜ ଓ ଦର୍ପଦଳନ।"
    ),
    TriviaQuestion(
      id = 6,
      question = "Which longest earthen dam in the world is built across the Mahanadi river in Odisha?",
      options = listOf("Hirakud Dam", "Rengali Dam", "Mandira Dam", "Upper Kolab Dam"),
      correctIndex = 0,
      category = TriviaCategory.ODISHA_CULTURE,
      explanation = "Hirakud Dam in Sambalpur is approximately 25.8 km long and one of the earliest major multipurpose river valley projects in India.",
      odiaTranslation = "ହୀରାକୁଦ ବନ୍ଧ ବିଶ୍ୱର ସବୁଠାରୁ ଲମ୍ବା ମାଟି ବନ୍ଧ।"
    ),
    TriviaQuestion(
      id = 7,
      question = "Who is revered as 'Utkalmani' (Jewel of Utkal) in Odisha history?",
      options = listOf("Pandit Gopabandhu Das", "Madhusudan Das", "Gourishankar Ray", "Gopabandhu Choudhury"),
      correctIndex = 0,
      category = TriviaCategory.ODISHA_CULTURE,
      explanation = "Pandit Gopabandhu Das was bestowed the title 'Utkalmani' for his selfless sacrifice, social reforms, and founding the Satyabadi Bana Bidyalaya.",
      odiaTranslation = "ପଣ୍ଡିତ ଗୋପବନ୍ଧୁ ଦାସଙ୍କୁ 'ଉତ୍କଳମଣି' ଭାବେ ସମ୍ମାନିତ କରାଯାଇଛି।"
    ),
    TriviaQuestion(
      id = 8,
      question = "Which famous village near Puri is globally renowned for traditional Pattachitra paintings?",
      options = listOf("Raghurajpur", "Pipli", "Bhatli", "Padmapur"),
      correctIndex = 0,
      category = TriviaCategory.ODISHA_CULTURE,
      explanation = "Raghurajpur is an artisan heritage crafts village famous for Pattachitra scroll paintings and Gotipua dance troupes.",
      odiaTranslation = "ରଘୁରାଜପୁର ଗ୍ରାମ ପଟ୍ଟଚିତ୍ର କଳା ପାଇଁ ବିଶ୍ୱ ପ୍ରସିଦ୍ଧ।"
    ),
    TriviaQuestion(
      id = 9,
      question = "Which National Park in Mayurbhanj, Odisha is famous for tigers, waterfalls, and biosphere diversity?",
      options = listOf("Simlipal National Park", "Bhitarkanika", "Satkosia", "Chandaka"),
      correctIndex = 0,
      category = TriviaCategory.ODISHA_CULTURE,
      explanation = "Simlipal Tiger Reserve is part of the UNESCO World Network of Biosphere Reserves with stunning Barehipani and Joranda falls.",
      odiaTranslation = "ଶିମିଳିପାଳ ଜାତୀୟ ଉଦ୍ୟାନ ବ୍ୟାଘ୍ର ସଂରକ୍ଷଣ ଓ ପ୍ରାକୃତିକ ସୌନ୍ଦର୍ଯ୍ୟ ପାଇଁ ପ୍ରସିଦ୍ଧ।"
    ),
    TriviaQuestion(
      id = 10,
      question = "Which unique three-day festival in Odisha celebrates womanhood, mother earth, and agricultural cycles?",
      options = listOf("Raja Parba", "Nuakhai", "Kumar Purnima", "Dola Purnima"),
      correctIndex = 0,
      category = TriviaCategory.ODISHA_CULTURE,
      explanation = "Raja Parba is celebrated in mid-June with swings (doli), Poda Pitha, traditional games, and honoring the fertility of Mother Earth.",
      odiaTranslation = "ରଜ ପର୍ବ ଓଡ଼ିଶାର ଏକ ଅନନ୍ୟ ସାଂସ୍କୃତିକ ଉତ୍ସବ।"
    ),
    TriviaQuestion(
      id = 11,
      question = "Who is known as 'Utkal Gourav' (Pride of Utkal) and played a pioneering role in the formation of Odisha province?",
      options = listOf("Madhusudan Das", "Gopabandhu Das", "Krushna Chandra Gajapati", "Fakir Mohan Senapati"),
      correctIndex = 0,
      category = TriviaCategory.ODISHA_CULTURE,
      explanation = "Madhusudan Das (Madhu Babu) was a visionary lawyer, industrialist, and statesman who led the Utkal Sammilani.",
      odiaTranslation = "ମଧୁସୂଦନ ଦାସଙ୍କୁ 'ଉତ୍କଳ ଗୌରବ' ଭାବେ ଆଖ୍ୟା ଦିଆଯାଇଛି।"
    ),
    TriviaQuestion(
      id = 12,
      question = "Which harvest festival is celebrated with great devotion in Western Odisha?",
      options = listOf("Nuakhai", "Prathamastami", "Pana Sankranti", "Sital Sasthi"),
      correctIndex = 0,
      category = TriviaCategory.ODISHA_CULTURE,
      explanation = "Nuakhai is celebrated on the Panchami tithi of Bhadraba to welcome newly harvested rice with family unity and 'Nuakhai Juhar'.",
      odiaTranslation = "ନୂଆଁଖାଇ ପଶ୍ଚିମ ଓଡ଼ିଶାର ଏକ ପ୍ରମୁଖ କୃଷି ଭିତ୍ତିକ ଗଣପର୍ବ।"
    ),

    // === ANIMALS & WILDLIFE ===
    TriviaQuestion(
      id = 20,
      question = "What is the fastest land animal in the world?",
      options = listOf("Cheetah (120 km/h)", "Lion", "Pronghorn Antelope", "Greyhound"),
      correctIndex = 0,
      category = TriviaCategory.ANIMALS_WILDLIFE,
      explanation = "The Cheetah can accelerate from 0 to 100 km/h in just 3 seconds, reaching top speeds around 120 km/h.",
      odiaTranslation = "ଚିତାବାଘ ପୃଥିବୀର ସବୁଠାରୁ ଦ୍ରୁତତମ ସ୍ଥଳଚର ପ୍ରାଣୀ।"
    ),
    TriviaQuestion(
      id = 21,
      question = "What is the largest living animal on planet Earth?",
      options = listOf("Blue Whale", "African Elephant", "Colossal Squid", "Giraffe"),
      correctIndex = 0,
      category = TriviaCategory.ANIMALS_WILDLIFE,
      explanation = "The Blue Whale can grow up to 30 meters (100 feet) long and weigh up to 200 tonnes — heavier than any dinosaur that ever lived!",
      odiaTranslation = "ନୀଳ ତିମି ପୃଥିବୀର ସବୁଠାରୁ ବଡ଼ ଜୀବନ୍ତ ପ୍ରାଣୀ।"
    ),
    TriviaQuestion(
      id = 22,
      question = "What is the only mammal capable of true sustained flight?",
      options = listOf("Bat", "Flying Squirrel", "Sugar Glider", "Flying Lemur"),
      correctIndex = 0,
      category = TriviaCategory.ANIMALS_WILDLIFE,
      explanation = "Bats are true flying mammals with hand-wings (order Chiroptera), unlike flying squirrels which only glide.",
      odiaTranslation = "ବାଦୁଡ଼ି ଏକମାତ୍ର ସ୍ତନ୍ୟପାୟୀ ପ୍ରାଣୀ ଯିଏ ଉଡ଼ିପାରେ।"
    ),
    TriviaQuestion(
      id = 23,
      question = "Why do chameleons change their skin color?",
      options = listOf("To regulate body temperature & express mood", "Only to match background walls", "Because they are sleepy", "To scare birds"),
      correctIndex = 0,
      category = TriviaCategory.ANIMALS_WILDLIFE,
      explanation = "Chameleons change color mainly for communication, territorial defense, courtship, and temperature regulation using nanocrystals in their skin.",
      odiaTranslation = "ଏଣ୍ଡୁଅ ନିଜ ଶରୀରର ତାପମାତ୍ରା ଓ ଭାବ ପ୍ରକାଶ ପାଇଁ ରଙ୍ଗ ବଦଳାଏ।"
    ),
    TriviaQuestion(
      id = 24,
      question = "What is a baby kangaroo called?",
      options = listOf("Joey", "Calf", "Cub", "Fawn"),
      correctIndex = 0,
      category = TriviaCategory.ANIMALS_WILDLIFE,
      explanation = "A baby kangaroo is called a joey. It is born tiny like a jellybean and climbs into its mother's pouch to develop.",
      odiaTranslation = "କଙ୍ଗାରୁର ଛୁଆକୁ 'ଜୋଇ' (Joey) କୁହାଯାଏ।"
    ),
    TriviaQuestion(
      id = 25,
      question = "How do honeybees communicate the location of distant flowers to their hive?",
      options = listOf("Waggle Dance", "High-pitched whistles", "Flashing lights", "Bumping wings"),
      correctIndex = 0,
      category = TriviaCategory.ANIMALS_WILDLIFE,
      explanation = "Karl von Frisch won a Nobel Prize for discovering that bees perform a figure-eight 'Waggle Dance' encoding the angle and distance of flowers relative to the sun.",
      odiaTranslation = "ମହୁମାଛିମାନେ 'ୱାଗଲ୍ ନୃତ୍ୟ' ଦ୍ୱାରା ଫୁଲର ଦିଗ ସୂଚାଇଥାନ୍ତି।"
    ),
    TriviaQuestion(
      id = 26,
      question = "How many hearts does an Octopus have?",
      options = listOf("3 Hearts", "1 Heart", "2 Hearts", "4 Hearts"),
      correctIndex = 0,
      category = TriviaCategory.ANIMALS_WILDLIFE,
      explanation = "An octopus has 3 hearts: two pump blood to the gills, while the third pumps blood through the rest of its body. It also has blue blood!",
      odiaTranslation = "ଅକ୍ଟୋପସ୍ ର ୩ଟି ହୃତ୍‌ପିଣ୍ଡ ଓ ନୀଳ ରଙ୍ଗର ରକ୍ତ ଥାଏ।"
    ),
    TriviaQuestion(
      id = 27,
      question = "Which bird lays the largest egg of all living species?",
      options = listOf("Ostrich", "Emu", "Albatross", "Eagle"),
      correctIndex = 0,
      category = TriviaCategory.ANIMALS_WILDLIFE,
      explanation = "An ostrich egg weighs around 1.4 kg (3 lbs) and is equivalent to about 24 chicken eggs!",
      odiaTranslation = "ଓଟପକ୍ଷୀର ଅଣ୍ଡା ସବୁଠାରୁ ବଡ଼ ହୋଇଥାଏ।"
    ),
    TriviaQuestion(
      id = 28,
      question = "How far can an Owl rotate its head without moving its body?",
      options = listOf("270 degrees", "180 degrees", "360 degrees", "90 degrees"),
      correctIndex = 0,
      category = TriviaCategory.ANIMALS_WILDLIFE,
      explanation = "Owls have 14 neck vertebrae (double that of humans) and specialized blood vessels, allowing them to turn their heads 270° safely.",
      odiaTranslation = "ପେଚା ନିଜ ମୁଣ୍ଡକୁ ୨୭୦ ଡିଗ୍ରୀ ପର୍ଯ୍ୟନ୍ତ ବୁଲାଇପାରେ।"
    ),
    TriviaQuestion(
      id = 29,
      question = "How do Dolphins sleep without drowning?",
      options = listOf("With one brain hemisphere asleep & one eye open", "They never sleep at all", "They bury in sand", "They float like wood"),
      correctIndex = 0,
      category = TriviaCategory.ANIMALS_WILDLIFE,
      explanation = "Dolphins practice 'unihemispheric sleep' — half of their brain sleeps while the other half stays awake to surface for air and watch for predators.",
      odiaTranslation = "ଡଲ୍‌ଫିନ୍ ଗୋଟିଏ ଆଖି ଖୋଲା ରଖି ଏବଂ ଅଧା ମସ୍ତିଷ୍କ ଶୋଇ ବିଶ୍ରାମ ନିଏ।"
    ),

    // === SIMPLE SCIENCE & NATURE ===
    TriviaQuestion(
      id = 40,
      question = "What green pigment in plant leaves absorbs sunlight for photosynthesis?",
      options = listOf("Chlorophyll", "Hemoglobin", "Carotene", "Melanin"),
      correctIndex = 0,
      category = TriviaCategory.SCIENCE_NATURE,
      explanation = "Chlorophyll absorbs blue and red wavelengths of light and reflects green light, giving plants their lush green color.",
      odiaTranslation = "କ୍ଲୋରୋଫିଲ୍ (ହରିତ୍‌କଣା) ସୂର୍ଯ୍ୟାଲୋକ ଶୋଷଣ କରି ଖାଦ୍ୟ ପ୍ରସ୍ତୁତ କରେ।"
    ),
    TriviaQuestion(
      id = 41,
      question = "At what temperature does pure water boil at standard sea-level atmospheric pressure?",
      options = listOf("100°C (212°F)", "0°C (32°F)", "50°C", "150°C"),
      correctIndex = 0,
      category = TriviaCategory.SCIENCE_NATURE,
      explanation = "Water boils at 100 degrees Celsius (212°F) and freezes at 0 degrees Celsius (32°F).",
      odiaTranslation = "ଜଳ ସାଧାରଣ ଚାପରେ ୧୦୦ ଡିଗ୍ରୀ ସେଲସିୟସ୍ ରେ ଫୁଟେ।"
    ),
    TriviaQuestion(
      id = 42,
      question = "Which planet in our solar system is famously known as the 'Red Planet'?",
      options = listOf("Mars", "Venus", "Jupiter", "Mercury"),
      correctIndex = 0,
      category = TriviaCategory.SCIENCE_NATURE,
      explanation = "Mars appears reddish because its surface is rich in iron oxide (rust) minerals.",
      odiaTranslation = "ମଙ୍ଗଳ ଗ୍ରହକୁ 'ଲାଲ ଗ୍ରହ' କୁହାଯାଏ।"
    ),
    TriviaQuestion(
      id = 43,
      question = "What is the closest star to planet Earth?",
      options = listOf("The Sun", "Proxima Centauri", "Sirius", "Alpha Centauri"),
      correctIndex = 0,
      category = TriviaCategory.SCIENCE_NATURE,
      explanation = "The Sun is our closest star (approx. 150 million km away). Sunlight takes about 8 minutes and 20 seconds to reach us.",
      odiaTranslation = "ସୂର୍ଯ୍ୟ ପୃଥିବୀର ନିକଟତମ ନକ୍ଷତ୍ର।"
    ),
    TriviaQuestion(
      id = 44,
      question = "How many bones are there in a fully grown adult human skeleton?",
      options = listOf("206 bones", "300 bones", "150 bones", "250 bones"),
      correctIndex = 0,
      category = TriviaCategory.SCIENCE_NATURE,
      explanation = "Human babies are born with around 300 bones, which gradually fuse together into 206 bones in adulthood.",
      odiaTranslation = "ଏକ ବୟସ୍କ ମାନବ ଶରୀରରେ ୨୦୬ଟି ହାଡ଼ ଥାଏ।"
    ),
    TriviaQuestion(
      id = 45,
      question = "What is the hardest naturally occurring substance found on Earth?",
      options = listOf("Diamond", "Titanium", "Granite", "Quartz"),
      correctIndex = 0,
      category = TriviaCategory.SCIENCE_NATURE,
      explanation = "Diamond, composed of pure carbon atoms bonded in a rigid tetrahedral lattice, rates a maximum 10 on the Mohs hardness scale.",
      odiaTranslation = "ହୀରା ପୃଥିବୀର ସବୁଠାରୁ କଠିନ ପ୍ରାକୃତିକ ପଦାର୍ଥ।"
    ),
    TriviaQuestion(
      id = 46,
      question = "Which gas do human beings breathe in for cellular survival, and which do we exhale?",
      options = listOf("Inhale Oxygen, Exhale Carbon Dioxide", "Inhale Carbon Dioxide, Exhale Nitrogen", "Inhale Helium, Exhale Oxygen", "Inhale Hydrogen, Exhale Argon"),
      correctIndex = 0,
      category = TriviaCategory.SCIENCE_NATURE,
      explanation = "We breathe in oxygen (O₂) to fuel cellular respiration and exhale carbon dioxide (CO₂) as a metabolic byproduct.",
      odiaTranslation = "ଆମେ ଅମ୍ଳଜାନ ଗ୍ରହଣ କରୁ ଏବଂ ଅଙ୍ଗାରକାମ୍ଳ ତ୍ୟାଗ କରୁ।"
    ),
    TriviaQuestion(
      id = 47,
      question = "What is the speed of light in a vacuum?",
      options = listOf("Approx. 300,000 km per second (3 × 10⁸ m/s)", "3,000 km per hour", "100 km per second", "Speed of sound"),
      correctIndex = 0,
      category = TriviaCategory.SCIENCE_NATURE,
      explanation = "Light travels at 299,792,458 meters per second in vacuum — the universal speed limit of physics (c).",
      odiaTranslation = "ଆଲୋକର ବେଗ ସେକେଣ୍ଡକୁ ପ୍ରାୟ ୩ ଲକ୍ଷ କିଲୋମିଟର।"
    ),
    TriviaQuestion(
      id = 48,
      question = "What causes the 7 vibrant colors of a rainbow to appear in the sky?",
      options = listOf("Refraction, reflection and dispersion of sunlight through raindrops", "Clouds painted with natural dust", "Reflected moonlight", "Heat lightning"),
      correctIndex = 0,
      category = TriviaCategory.SCIENCE_NATURE,
      explanation = "Raindrops act like tiny prisms that disperse white sunlight into its constituent spectral colors: VIBGYOR.",
      odiaTranslation = "ଇନ୍ଦ୍ରଧନୁ ବର୍ଷା ବିନ୍ଦୁ ଦ୍ୱାରା ଆଲୋକର ବିଚ୍ଛୁରଣ ଯୋଗୁଁ ସୃଷ୍ଟି ହୁଏ।"
    ),

    // === BASIC EVERYDAY GENERAL KNOWLEDGE ===
    TriviaQuestion(
      id = 60,
      question = "How many continents and how many oceans exist on planet Earth?",
      options = listOf("7 Continents & 5 Oceans", "6 Continents & 4 Oceans", "8 Continents & 7 Oceans", "5 Continents & 5 Oceans"),
      correctIndex = 0,
      category = TriviaCategory.EVERYDAY_GK,
      explanation = "Earth has 7 continents (Asia, Africa, North America, South America, Antarctica, Europe, Australia) and 5 oceans.",
      odiaTranslation = "ପୃଥିବୀରେ ୭ଟି ମହାଦେଶ ଓ ୫ଟି ମହାସାଗର ଅଛି।"
    ),
    TriviaQuestion(
      id = 61,
      question = "What is the national animal of India?",
      options = listOf("Royal Bengal Tiger", "Asiatic Lion", "Indian Elephant", "Indian Rhinoceros"),
      correctIndex = 0,
      category = TriviaCategory.EVERYDAY_GK,
      explanation = "The Royal Bengal Tiger (Panthera tigris) was declared the national animal of India in April 1973.",
      odiaTranslation = "ଭାରତର ଜାତୀୟ ପଶୁ ହେଉଛି ମହାବଳ ବାଘ।"
    ),
    TriviaQuestion(
      id = 62,
      question = "How many spokes are in the Ashoka Chakra on India's national flag?",
      options = listOf("24 Spokes", "12 Spokes", "30 Spokes", "20 Spokes"),
      correctIndex = 0,
      category = TriviaCategory.EVERYDAY_GK,
      explanation = "The navy blue Ashoka Chakra has 24 spokes representing 24 virtues and the constant movement of progress and dharma.",
      odiaTranslation = "ଅଶୋକ ଚକ୍ରରେ ୨୪ଟି ଅର (ସ୍ପୋକ୍ସ) ଥାଏ।"
    ),
    TriviaQuestion(
      id = 63,
      question = "What is the capital city of Odisha, famously known as the 'Temple City'?",
      options = listOf("Bhubaneswar", "Cuttack", "Puri", "Rourkela"),
      correctIndex = 0,
      category = TriviaCategory.EVERYDAY_GK,
      explanation = "Bhubaneswar is the capital of Odisha, renowned for historic Kalinga architecture and hundreds of ancient stone temples.",
      odiaTranslation = "ଭୁବନେଶ୍ୱର ଓଡ଼ିଶାର ରାଜଧାନୀ ଓ ଏହାକୁ 'ମନ୍ଦିର ମାଳିନୀ ନଗର' କୁହାଯାଏ।"
    ),
    TriviaQuestion(
      id = 64,
      question = "How many days are there in a standard Leap Year?",
      options = listOf("366 Days", "365 Days", "364 Days", "367 Days"),
      correctIndex = 0,
      category = TriviaCategory.EVERYDAY_GK,
      explanation = "A leap year has 366 days, with an extra 29th day added to February because Earth takes approx. 365.242 days to orbit the sun.",
      odiaTranslation = "ଅଧିବର୍ଷ (Leap Year) ରେ ୩୬୬ ଦିନ ଥାଏ।"
    ),
    TriviaQuestion(
      id = 65,
      question = "Which is the largest ocean in the world?",
      options = listOf("Pacific Ocean", "Atlantic Ocean", "Indian Ocean", "Arctic Ocean"),
      correctIndex = 0,
      category = TriviaCategory.EVERYDAY_GK,
      explanation = "The Pacific Ocean is the largest and deepest ocean, covering more area than all of Earth's land masses combined!",
      odiaTranslation = "ପ୍ରଶାନ୍ତ ମହାସାଗର ପୃଥିବୀର ବୃହତ୍ତମ ମହାସାଗର।"
    ),

    // === FUNNY & WITTY BRAIN TEASERS ===
    TriviaQuestion(
      id = 80,
      question = "What has hands and a face, but cannot clap or smile?",
      options = listOf("A Clock ⏰", "A Statue", "A Robot", "A Doll"),
      correctIndex = 0,
      category = TriviaCategory.FUNNY_RIDDLES,
      explanation = "A clock has an hour hand, a minute hand, and a dial face, but no hands to clap!",
      odiaTranslation = "ଘଣ୍ଟାର ହାତ ଓ ମୁହଁ ଥାଏ କିନ୍ତୁ ତାହା ତାଳି ମାରିପାରେ ନାହିଁ।"
    ),
    TriviaQuestion(
      id = 81,
      question = "What gets wetter and wetter the more it dries?",
      options = listOf("A Towel 🧖‍♂️", "A Sponge", "The Sun", "Water"),
      correctIndex = 0,
      category = TriviaCategory.FUNNY_RIDDLES,
      explanation = "A towel gets wetter as it dries your body!",
      odiaTranslation = "ଗାମୁଛା ଯେତେ ଅଧିକ ଶୁଖାଏ, ସେତେ ଅଧିକ ଓଦା ହୁଏ।"
    ),
    TriviaQuestion(
      id = 82,
      question = "Which month of the year has 28 days?",
      options = listOf("All 12 Months! 🗓️", "Only February", "Only January", "None of them"),
      correctIndex = 0,
      category = TriviaCategory.FUNNY_RIDDLES,
      explanation = "Every single month has at least 28 days! Some just have 30 or 31 as well!",
      odiaTranslation = "ବର୍ଷର ସମସ୍ତ ୧୨ଟି ମାସରେ ୨୮ ଦିନ ଥାଏ।"
    ),
    TriviaQuestion(
      id = 83,
      question = "What can travel around the whole world while staying stuck in a tiny corner?",
      options = listOf("A Postage Stamp ✉️", "A Spider", "A Bookmark", "An Airplane"),
      correctIndex = 0,
      category = TriviaCategory.FUNNY_RIDDLES,
      explanation = "A postage stamp stays glued to the corner of an envelope as it travels across continents.",
      odiaTranslation = "ଡାକ ଟିକେଟ୍ କୋଣରେ ଥାଇ ମଧ୍ୟ ସାରା ବିଶ୍ୱ ଭ୍ରମଣ କରେ।"
    ),
    TriviaQuestion(
      id = 84,
      question = "What has many keys but cannot unlock a single door?",
      options = listOf("A Piano 🎹", "A Computer Keyboard", "A Locksmith", "A Skeleton"),
      correctIndex = 0,
      category = TriviaCategory.FUNNY_RIDDLES,
      explanation = "A piano has 88 musical keys, but none of them open doors!",
      odiaTranslation = "ପିଆନୋରେ ଅନେକ ଚାବି (Keys) ଥାଏ କିନ୍ତୁ କବାଟ ଖୋଲି ହୁଏନାହିଁ।"
    ),
    TriviaQuestion(
      id = 85,
      question = "If an electric train is traveling north at 100 km/h, which way does the smoke blow?",
      options = listOf("Electric trains have no smoke! ⚡", "South", "East", "North-West"),
      correctIndex = 0,
      category = TriviaCategory.FUNNY_RIDDLES,
      explanation = "Electric trains run on clean electricity and produce zero smoke!",
      odiaTranslation = "ବିଦ୍ୟୁତ୍ ଟ୍ରେନ୍ ରୁ କୌଣସି ଧୂଆଁ ବାହାରେ ନାହିଁ।"
    ),
    TriviaQuestion(
      id = 86,
      question = "What has a neck, but absolutely no head?",
      options = listOf("A Bottle 🍾", "A Shirt", "A Guitar", "A Giraffe"),
      correctIndex = 0,
      category = TriviaCategory.FUNNY_RIDDLES,
      explanation = "A glass bottle has a slender neck and a mouth/opening, but no head!",
      odiaTranslation = "ବୋତଲର ବେକ ଥାଏ କିନ୍ତୁ ମୁଣ୍ଡ ନଥାଏ।"
    ),
    TriviaQuestion(
      id = 87,
      question = "What has many teeth, but cannot eat or bite an apple?",
      options = listOf("A Comb 🪮", "A Saw", "A Zipper", "A Shark"),
      correctIndex = 0,
      category = TriviaCategory.FUNNY_RIDDLES,
      explanation = "A hair comb has dozens of teeth, but only grooms hair without biting!",
      odiaTranslation = "ପାନିଆର ଅନେକ ଦାନ୍ତ ଥାଏ କିନ୍ତୁ ସେ କିଛି ଖାଇପାରେ ନାହିଁ।"
    ),
    TriviaQuestion(
      id = 88,
      question = "What goes up, but never comes back down?",
      options = listOf("Your Age 🎂", "A Rocket", "Rain", "A Hot Air Balloon"),
      correctIndex = 0,
      category = TriviaCategory.FUNNY_RIDDLES,
      explanation = "Your age always increases year by year and never decreases!",
      odiaTranslation = "ଆପଣଙ୍କ ବୟସ ସର୍ବଦା ବଢ଼େ କିନ୍ତୁ କେବେ କମେ ନାହିଁ।"
    ),
    TriviaQuestion(
      id = 89,
      question = "What has one eye, but cannot see anything around it?",
      options = listOf("A Sewing Needle 🪡", "A Potato", "A Storm", "A Cyclops"),
      correctIndex = 0,
      category = TriviaCategory.FUNNY_RIDDLES,
      explanation = "A sewing needle has an eye for threading thread, but no sight!",
      odiaTranslation = "ଛୁଞ୍ଚିର ଆଖି ଥାଏ କିନ୍ତୁ ତାହା କିଛି ଦେଖିପାରେ ନାହିଁ।"
    )
  )

  /**
   * Generates dynamic trivia questions on the fly with varied numbers, topics, and templates
   * to provide a virtually infinite 1000+ question bank experience.
   */
  private val dynamicQuestionTemplates: List<() -> TriviaQuestion> = listOf(
    // Template 1: Planet order
    {
      val planets = listOf("Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune")
      val idx = random.nextInt(planets.size)
      val p = planets[idx]
      val ord = when (idx + 1) {
        1 -> "1st"; 2 -> "2nd"; 3 -> "3rd"; 4 -> "4th"; 5 -> "5th"; 6 -> "6th"; 7 -> "7th"; else -> "8th"
      }
      val correct = p
      val wrongs = planets.filter { it != p }.shuffled().take(3)
      val options = (wrongs + correct).shuffled()
      TriviaQuestion(
        id = random.nextInt(200000) + 10000,
        question = "Which is the $ord planet from the Sun in our Solar System?",
        options = options,
        correctIndex = options.indexOf(correct),
        category = TriviaCategory.SCIENCE_NATURE,
        explanation = "$p is the $ord planet from the Sun.",
        odiaTranslation = "$p ସୂର୍ଯ୍ୟ ଠାରୁ $ord ଗ୍ରହ।"
      )
    },
    // Template 2: Animal speed & characteristic
    {
      val animals = listOf(
        Pair("Kangaroo", "Australia's national marsupial known for jumping on powerful hind legs"),
        Pair("Penguin", "Flightless bird that is an incredible underwater swimmer in icy waters"),
        Pair("Koala", "Sleepy tree-dwelling marsupial that feeds almost entirely on eucalyptus leaves"),
        Pair("Cheetah", "Spotted big cat capable of accelerating up to 120 km/h in short bursts"),
        Pair("Camel", "Desert marvel known as the 'Ship of the Desert' storing fat in its hump"),
        Pair("Peacock", "National bird of India celebrated for iridescent feathers and monsoon dances")
      )
      val pair = animals[random.nextInt(animals.size)]
      val correct = pair.first
      val wrongs = animals.filter { it.first != correct }.map { it.first }.shuffled().take(3)
      val options = (wrongs + correct).shuffled()
      TriviaQuestion(
        id = random.nextInt(200000) + 10000,
        question = "Which animal is described as: '${pair.second}'?",
        options = options,
        correctIndex = options.indexOf(correct),
        category = TriviaCategory.ANIMALS_WILDLIFE,
        explanation = "That is the ${pair.first}.",
        odiaTranslation = "ଏହି ବର୍ଣ୍ଣନା ${pair.first} ର ଅଟେ।"
      )
    },
    // Template 3: Odisha Districts & Specialties
    {
      val odishaSpecialties = listOf(
        Pair("Sambalpur", "Famous for Sambalpuri handloom Ikat sarees and Hirakud Dam"),
        Pair("Puri", "Famous for the historic Jagannath Temple and sacred Golden Sea Beach"),
        Pair("Kendrapara", "Famous for Bhitarkanika mangrove crocodiles and soft Rasabali sweet"),
        Pair("Mayurbhanj", "Famous for Simlipal Tiger Reserve and traditional Chhau dance"),
        Pair("Cuttack", "Historic Millennium City famous for exquisite Silver Filigree (Tarakasi) art"),
        Pair("Koraput", "Famous for scenic Deomali hills, tribal culture, and organic coffee plantations"),
        Pair("Bargarh", "Famous for hosting the world's largest open-air theater: Dhanu Jatra"),
        Pair("Ganjam", "Famous for Gopalpur beach, Berhampuri Patta sarees, and Tara Tarini shrine")
      )
      val pair = odishaSpecialties[random.nextInt(odishaSpecialties.size)]
      val correct = pair.first
      val wrongs = odishaSpecialties.filter { it.first != correct }.map { it.first }.shuffled().take(3)
      val options = (wrongs + correct).shuffled()
      TriviaQuestion(
        id = random.nextInt(200000) + 10000,
        question = "Which district of Odisha is '${pair.second}'?",
        options = options,
        correctIndex = options.indexOf(correct),
        category = TriviaCategory.ODISHA_CULTURE,
        explanation = "${pair.first} district is famous for this heritage.",
        odiaTranslation = "${pair.first} ଜିଲ୍ଲା ଏଥିପାଇଁ ବିଶେଷ ପ୍ରସିଦ୍ଧ।"
      )
    },
    // Template 4: Basic Science Concepts
    {
      val scienceItems = listOf(
        Triple("H₂O", "Water", "Chemical formula consisting of 2 Hydrogen atoms and 1 Oxygen atom"),
        Triple("CO₂", "Carbon Dioxide", "Gas absorbed by green plants during photosynthesis"),
        Triple("O₂", "Oxygen", "Life-sustaining gas that makes up roughly 21% of Earth's atmosphere"),
        Triple("NaCl", "Common Salt (Sodium Chloride)", "Essential mineral crystalline compound used in cooking"),
        Triple("Au", "Gold", "Precious transition metal with the chemical symbol Au (from Latin 'Aurum')"),
        Triple("Ag", "Silver", "Lustrous white transition metal with the highest electrical conductivity")
      )
      val item = scienceItems[random.nextInt(scienceItems.size)]
      val correct = item.second
      val wrongs = scienceItems.filter { it.second != correct }.map { it.second }.shuffled().take(3)
      val options = (wrongs + correct).shuffled()
      TriviaQuestion(
        id = random.nextInt(200000) + 10000,
        question = "In science, what substance has the formula ${item.first} (${item.third})?",
        options = options,
        correctIndex = options.indexOf(correct),
        category = TriviaCategory.SCIENCE_NATURE,
        explanation = "${item.first} is the scientific chemical notation for $correct.",
        odiaTranslation = "${item.first} ହେଉଛି $correct ର ରାସାୟନିକ ସୂତ୍ର।"
      )
    },
    // Template 5: Everyday Knowledge Numbers
    {
      val gks = listOf(
        Triple("hours in 1 day", "24", listOf("12", "48", "36")),
        Triple("minutes in 1 hour", "60", listOf("100", "50", "45")),
        Triple("seconds in 1 minute", "60", listOf("100", "120", "30")),
        Triple("days in a standard non-leap year", "365", listOf("366", "360", "300")),
        Triple("weeks in a standard year", "52", listOf("48", "50", "54")),
        Triple("months in a single year", "12", listOf("10", "14", "11")),
        Triple("centimeters in 1 meter", "100", listOf("10", "1000", "50")),
        Triple("grams in 1 kilogram", "1000", listOf("100", "500", "10000")),
        Triple("milliliters in 1 liter", "1000", listOf("100", "500", "2000"))
      )
      val item = gks[random.nextInt(gks.size)]
      val correct = item.second
      val options = (item.third + correct).shuffled()
      TriviaQuestion(
        id = random.nextInt(200000) + 10000,
        question = "How many ${item.first} are there?",
        options = options,
        correctIndex = options.indexOf(correct),
        category = TriviaCategory.EVERYDAY_GK,
        explanation = "There are exactly $correct ${item.first}.",
        odiaTranslation = "ଏଥିରେ ଠିକ୍ $correct ଥାଏ।"
      )
    }
  )

  /**
   * Retrieves a randomized trivia question from the curated dataset or generated dynamically.
   */
  fun getRandomQuestion(categoryFilter: TriviaCategory = TriviaCategory.ALL): TriviaQuestion {
    // 60% curated, 40% dynamic template
    val useCurated = random.nextInt(10) < 6
    if (useCurated) {
      val matching = if (categoryFilter == TriviaCategory.ALL) {
        curatedTriviaDatabase
      } else {
        curatedTriviaDatabase.filter { it.category == categoryFilter }
      }
      if (matching.isNotEmpty()) {
        val q = matching[random.nextInt(matching.size)]
        return shuffleTriviaOptions(q)
      }
    }

    // Dynamic generation
    val template = dynamicQuestionTemplates[random.nextInt(dynamicQuestionTemplates.size)]
    val dynamicQ = template()
    return if (categoryFilter == TriviaCategory.ALL || dynamicQ.category == categoryFilter) {
      dynamicQ
    } else {
      // Fallback to curated if template category doesn't match filter
      val fallbackList = curatedTriviaDatabase.filter { it.category == categoryFilter }
      if (fallbackList.isNotEmpty()) {
        shuffleTriviaOptions(fallbackList[random.nextInt(fallbackList.size)])
      } else {
        dynamicQ
      }
    }
  }

  private fun shuffleTriviaOptions(q: TriviaQuestion): TriviaQuestion {
    val correctText = q.options[q.correctIndex]
    val shuffled = q.options.shuffled()
    val newIdx = shuffled.indexOf(correctText)
    return q.copy(options = shuffled, correctIndex = newIdx)
  }
}
