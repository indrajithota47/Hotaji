package com.example.data.ai

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiClient {

  private val client = OkHttpClient.Builder()
    .connectTimeout(60, TimeUnit.SECONDS)
    .readTimeout(60, TimeUnit.SECONDS)
    .writeTimeout(60, TimeUnit.SECONDS)
    .build()

  private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

  suspend fun generateAgentResponse(
    agent: AgentType,
    userQuery: String,
    languageName: String,
    memories: List<String> = emptyList()
  ): String = withContext(Dispatchers.IO) {
    val apiKey = try { BuildConfig.GEMINI_API_KEY } catch (_: Exception) { "" }

    if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
      return@withContext getOfflineKnowledgeResponse(agent, userQuery, languageName)
    }

    try {
      val memoryContext = if (memories.isNotEmpty()) {
        "\nActive User Long-term Memories:\n" + memories.joinToString("\n") { "- $it" }
      } else ""

      val systemPrompt = """
        ${agent.systemPrompt}
        
        Operating Context:
        - System: Hotaji App (Personal AI Operating System - PAIOS v1.0)
        - Founder & Owner: Indrajit Hota
        - Origin: Made in Odisha | Made in India
        - Target Language: $languageName
        - Mandatory Requirement: Always categorize your statements using Epistemic Labels:
          [FACT] for verifiable empirical facts,
          [INTERPRETATION] for analytical conclusions,
          [TRADITIONAL BELIEF] for spiritual and cultural concepts,
          [OPINION] for perspectives or advice,
          [UNCERTAIN] for areas with emerging consensus.
        $memoryContext
      """.trimIndent()

      val requestJson = JSONObject().apply {
        put("contents", JSONArray().apply {
          put(JSONObject().apply {
            put("parts", JSONArray().apply {
              put(JSONObject().apply { put("text", userQuery) })
            })
          })
        })
        put("systemInstruction", JSONObject().apply {
          put("parts", JSONArray().apply {
            put(JSONObject().apply { put("text", systemPrompt) })
          })
        })
        put("generationConfig", JSONObject().apply {
          put("temperature", 0.7)
          put("topP", 0.95)
        })
      }

      val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
      val request = Request.Builder()
        .url(url)
        .post(requestJson.toString().toRequestBody(jsonMediaType))
        .build()

      val response = client.newCall(request).execute()
      val responseBody = response.body?.string() ?: ""

      if (response.isSuccessful && responseBody.isNotEmpty()) {
        val json = JSONObject(responseBody)
        val candidates = json.optJSONArray("candidates")
        val firstCand = candidates?.optJSONObject(0)
        val content = firstCand?.optJSONObject("content")
        val parts = content?.optJSONArray("parts")
        val text = parts?.optJSONObject(0)?.optString("text")
        if (!text.isNullOrBlank()) {
          return@withContext text
        }
      }
      return@withContext getOfflineKnowledgeResponse(agent, userQuery, languageName)
    } catch (e: Exception) {
      Log.e("GeminiClient", "API call failed: ${e.message}")
      return@withContext getOfflineKnowledgeResponse(agent, userQuery, languageName)
    }
  }

  // Built-in offline knowledge bank with Odia Barnabodha, scriptures, STEM & regional heritage
  fun getOfflineKnowledgeResponse(agent: AgentType, query: String, languageName: String): String {
    val q = query.lowercase()
    val isOdia = languageName.contains("Odia") || query.any { it in '\u0B00'..'\u0B7F' }

    return when (agent) {
      AgentType.SPIRITUAL_LIBRARY -> {
        if (q.contains("gita") || q.contains("krishna") || q.contains("karma")) {
          if (isOdia) {
            "[TRADITIONAL BELIEF] ଶ୍ରୀମଦ୍ ଭଗବଦ୍ ଗୀତାର କର୍ମଯୋଗ ଅନୁଯାୟୀ, 'କର୍ମଣ୍ୟେବାଧିକାରସ୍ତେ ମା ଫଳେଷୁ କଦାଚନ'। [FACT] ଏହା ମହାଭାରତର ଭୀଷ୍ମ ପର୍ବର ଅଂଶବିଶେଷ ଯେଉଁଥିରେ ୧୮ଟି ଅଧ୍ୟାୟ ଓ ୭୦୦ ଶ୍ଳୋକ ରହିଛି। [INTERPRETATION] ନିଷ୍କାମ କର୍ମ ହିଁ ମାନସିକ ଶାନ୍ତି ଓ ଆଧ୍ୟାତ୍ମିକ ପ୍ରଗତିର ମୂଳଦୁଆ।"
          } else {
            "[FACT] The Bhagavad Gita is a 700-verse Hindu scripture that is part of the epic Mahabharata (chapters 23–40 of Bhishma Parva). [TRADITIONAL BELIEF] It teaches the core philosophy of Nishkama Karma (selfless action without attachment to fruits). [INTERPRETATION] Maintaining equanimity in success and failure fosters profound psychological resilience."
          }
        } else if (q.contains("barnabodha") || q.contains("odia") || q.contains("madhusudan")) {
          "[FACT] 'ଛାନ୍ଦଶ୍ରୀ' ଭକ୍ତକବି ମଧୁସୂଦନ ରାଓଙ୍କ ଦ୍ଵାରା ୧୮୯୫ ରେ 'ବର୍ଣ୍ଣବୋଧ' (Barnabodha) ରଚିତ ହୋଇଥିଲା। [FACT] ଏଥିରେ ଓଡ଼ିଆ ସ୍ୱରବର୍ଣ୍ଣ (ଅ, ଆ, ଇ, ଈ...) ଓ ବ୍ୟଞ୍ଜନବର୍ଣ୍ଣ (କ, ଖ, ଗ, ଘ...) ର ବିଶୁଦ୍ଧ ଶିକ୍ଷା ରହିଛି। [TRADITIONAL BELIEF] 'କମଳ ଲୋଚନ ଶ୍ରୀହରି, ଶ୍ରୀପଦେ ସୁମରୁ ନରହରି' ଏହାର ପ୍ରସିଦ୍ଧ ଆଦ୍ୟ ପ୍ରାର୍ଥନା।"
        } else if (q.contains("quran") || q.contains("islam")) {
          "[FACT] The Holy Quran comprises 114 Surahs and is the central religious text of Islam. [TRADITIONAL BELIEF] It emphasizes tawhid (the absolute oneness of God) and social justice. [INTERPRETATION] Central themes focus on compassion, charity (Zakat), and righteous conduct."
        } else if (q.contains("bible") || q.contains("christianity")) {
          "[FACT] The Christian Bible includes the Old and New Testaments spanning 66 canonical books in Protestant tradition. [TRADITIONAL BELIEF] Jesus Christ's teachings center on agape (unconditional love) and redemption. [INTERPRETATION] The Sermon on the Mount presents an ethic of humility and peace."
        } else {
          "[TRADITIONAL BELIEF] Hotaji Universal Spiritual Engine indexes foundational scriptures: Vedas, Upanishads, Gita, Quran, and Bible. [FACT] Odisha is renowned for the syncretic Jagannath culture (Purusottama Kshetra) blending Vedic, Buddhist, Jain, and tribal traditions. [INTERPRETATION] Truth is one; wise sages articulate it in diverse ways (Ekam Sat Vipra Bahudha Vadanti)."
        }
      }
      AgentType.ACADEMIC -> {
        if (q.contains("math") || q.contains("equation") || q.contains("calculus")) {
          "[FACT] In mathematics, Euler's identity e^(iπ) + 1 = 0 connects the five most fundamental constants: e, i, π, 1, and 0. [INTERPRETATION] This elegant relation establishes an invariant geometric harmony between exponential growth, trigonometry, and complex coordinate geometry."
        } else {
          "[FACT] The Hotaji Academic Engine provides rigorous proofs across physics, quantum mechanics, computer science, and linguistics. [INTERPRETATION] Analytical modeling enables rapid comprehension of multi-variable non-linear systems. [UNCERTAIN] Quantum gravity unification hypotheses remain subject to empirical collider verification."
        }
      }
      AgentType.CODE_ARCHITECT -> {
        "[FACT] Modern Android architecture prioritizes Jetpack Compose with unidirectional data flow (StateFlow), Room local persistence, and Kotlin Coroutines. [OPINION] Clean modularization between Data, Domain, and UI layers minimizes technical debt and maximizes testing velocity."
      }
      AgentType.FINANCE -> {
        "[FACT] Compound interest calculates returns on both initial principal and accumulated interest via A = P(1 + r/n)^(nt). [OPINION] Maintaining a diversified 6-month emergency fund in liquid assets provides vital macroeconomic risk insulation."
      }
      AgentType.CAREER_WRITING -> {
        "[FACT] High-impact communication uses the STAR methodology (Situation, Task, Action, Result) for structured storytelling. [OPINION] Executive memos should lead with the bottom-line recommendation before presenting supporting evidence."
      }
      AgentType.LIFESTYLE -> {
        "[FACT] Circadian biology confirms that early morning sunlight exposure calibrates cortisol rhythms and enhances nighttime melatonin synthesis. [OPINION] Prioritize 7.5 to 8.5 hours of uninterrupted restorative sleep for peak cognitive performance."
      }
      AgentType.PERSONAL_LIFE -> {
        "[FACT] Consistent daily atomic habits compound over time to generate substantial cognitive and personal growth. [INTERPRETATION] Reflecting on daily challenges helps clarify core priorities. [OPINION] Hotaji PAIOS recommends dedicating 15 minutes each evening to structured goal review."
      }
    }
  }
}
