package com.example.data.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

enum class VoiceAvatar(
  val id: String,
  val displayName: String,
  val gender: String,
  val trait: String,
  val defaultPitch: Float,
  val defaultRate: Float,
  val voiceDescription: String
) {
  ARJUN("arjun", "Arjun", "Male", "Confident & Crisp", 0.92f, 1.05f, "Authoritative, resonant tone optimized for strategic briefings and coding."),
  JEET("jeet", "Jeet", "Male", "Warm & Empathetic", 1.00f, 0.95f, "Gentle, reassuring cadence for personal life mentorship."),
  BHAVISHYA("bhavishya", "Bhavishya", "Male", "Visionary & Dynamic", 1.12f, 1.08f, "Energetic projection for technology, research, and future trends."),
  VAISHNAV("vaishnav", "Vaishnav", "Male", "Humble & Contemplative", 0.82f, 0.88f, "Calm, grounded voice suited for Odia scriptures and philosophy."),
  GITA("gita", "Gita", "Female", "Expressive & Articulate", 1.25f, 1.00f, "Nuanced, lyrical delivery with rich regional expression."),
  PRIYA("priya", "Priya", "Female", "Upbeat & Fast", 1.35f, 1.15f, "Bright, enthusiastic tempo for quick answers and arcade guidance."),
  ANANYA("ananya", "Ananya", "Female", "Patient Tutor", 1.15f, 0.95f, "Clear, measured pedagogical pacing for STEM and Barnabodha."),
  KAVYA("kavya", "Kavya", "Female", "Narrative & Poetic", 1.05f, 0.90f, "Rich storyteller cadence for history, culture, and creative writing."),
  DUAL_TONE("dual_tone", "Dual-Tone", "Dynamic", "Adaptive Modulation", 1.00f, 1.00f, "Auto-modulates between resonant low and airy high tones.")
}

class VoiceEngine(private val context: Context) : TextToSpeech.OnInitListener {

  private var tts: TextToSpeech? = null
  private var isTtsReady = false

  private val _isSpeaking = MutableStateFlow(false)
  val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

  private val _currentAvatar = MutableStateFlow(VoiceAvatar.ARJUN)
  val currentAvatar: StateFlow<VoiceAvatar> = _currentAvatar.asStateFlow()

  private val _audioFrequencies = MutableStateFlow(FloatArray(8) { 0.2f })
  val audioFrequencies: StateFlow<FloatArray> = _audioFrequencies.asStateFlow()

  private var toneGenerator: ToneGenerator? = null

  init {
    try {
      tts = TextToSpeech(context.applicationContext, this)
      toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 100)
    } catch (e: Exception) {
      Log.e("VoiceEngine", "Init error: ${e.message}")
    }
  }

  override fun onInit(status: Int) {
    if (status == TextToSpeech.SUCCESS) {
      isTtsReady = true
      tts?.let { engine ->
        val result = engine.setLanguage(Locale("or", "IN")) // Try Odia first
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
          engine.setLanguage(Locale("en", "IN"))
        }
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
          override fun onStart(utteranceId: String?) {
            _isSpeaking.value = true
          }

          override fun onDone(utteranceId: String?) {
            _isSpeaking.value = false
          }

          override fun onError(utteranceId: String?) {
            _isSpeaking.value = false
          }
        })
      }
    }
  }

  fun setAvatar(avatar: VoiceAvatar) {
    _currentAvatar.value = avatar
  }

  fun speak(text: String, languageCode: String = "or") {
    if (!isTtsReady || tts == null) return

    val avatar = _currentAvatar.value
    tts?.let { engine ->
      // Language modulation
      when (languageCode.lowercase()) {
        "or", "odia" -> {
          val res = engine.setLanguage(Locale("or", "IN"))
          if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.setLanguage(Locale("hi", "IN"))
          }
        }
        "hi", "hindi" -> engine.setLanguage(Locale("hi", "IN"))
        else -> engine.setLanguage(Locale("en", "IN"))
      }

      val pitch = if (avatar == VoiceAvatar.DUAL_TONE) {
        if (text.length % 2 == 0) 1.25f else 0.85f
      } else {
        avatar.defaultPitch
      }

      engine.setPitch(pitch)
      engine.setSpeechRate(avatar.defaultRate)

      val utteranceId = "Hotaji_Utterance_${System.currentTimeMillis()}"
      engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }
  }

  fun stop() {
    tts?.stop()
    _isSpeaking.value = false
  }

  // Pure Laser / Shooter SFX without any external file dependency
  fun playLaserSound() {
    CoroutineScope(Dispatchers.Default).launch {
      try {
        playSynthesizedLaser()
      } catch (e: Exception) {
        try {
          toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 80)
        } catch (_: Exception) {}
      }
    }
  }

  fun playSuccessSound() {
    CoroutineScope(Dispatchers.Default).launch {
      try {
        toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 120)
      } catch (_: Exception) {}
    }
  }

  fun playExplosionSound() {
    CoroutineScope(Dispatchers.Default).launch {
      try {
        playSynthesizedNoise()
      } catch (_: Exception) {}
    }
  }

  private fun playSynthesizedLaser() {
    val sampleRate = 22050
    val durationSec = 0.12f
    val numSamples = (durationSec * sampleRate).toInt()
    val buffer = ShortArray(numSamples)

    // Rapid downward frequency chirp: 1800Hz down to 250Hz
    var phase = 0.0
    for (i in 0 until numSamples) {
      val progress = i.toDouble() / numSamples
      val currentFreq = 1800.0 * (1.0 - progress) + 250.0
      phase += 2.0 * Math.PI * currentFreq / sampleRate
      val envelope = 1.0 - progress // Linear fade
      buffer[i] = (Math.sin(phase) * 32767.0 * envelope * 0.8).toInt().toShort()
    }

    val audioTrack = AudioTrack.Builder()
      .setAudioAttributes(
        AudioAttributes.Builder()
          .setUsage(AudioAttributes.USAGE_GAME)
          .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
          .build()
      )
      .setAudioFormat(
        AudioFormat.Builder()
          .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
          .setSampleRate(sampleRate)
          .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
          .build()
      )
      .setBufferSizeInBytes(buffer.size * 2)
      .setTransferMode(AudioTrack.MODE_STATIC)
      .build()

    audioTrack.write(buffer, 0, buffer.size)
    audioTrack.play()
  }

  private fun playSynthesizedNoise() {
    val sampleRate = 22050
    val durationSec = 0.15f
    val numSamples = (durationSec * sampleRate).toInt()
    val buffer = ShortArray(numSamples)

    val random = java.util.Random()
    for (i in 0 until numSamples) {
      val progress = i.toDouble() / numSamples
      val envelope = Math.exp(-progress * 5.0)
      val noise = (random.nextDouble() * 2.0 - 1.0)
      buffer[i] = (noise * 32767.0 * envelope * 0.7).toInt().toShort()
    }

    val audioTrack = AudioTrack.Builder()
      .setAudioAttributes(
        AudioAttributes.Builder()
          .setUsage(AudioAttributes.USAGE_GAME)
          .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
          .build()
      )
      .setAudioFormat(
        AudioFormat.Builder()
          .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
          .setSampleRate(sampleRate)
          .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
          .build()
      )
      .setBufferSizeInBytes(buffer.size * 2)
      .setTransferMode(AudioTrack.MODE_STATIC)
      .build()

    audioTrack.write(buffer, 0, buffer.size)
    audioTrack.play()
  }

  fun shutdown() {
    try {
      tts?.stop()
      tts?.shutdown()
      toneGenerator?.release()
    } catch (_: Exception) {}
  }
}
