package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface HotajiDao {
  @Query("SELECT * FROM user_profile WHERE id = 1")
  fun getUserProfile(): Flow<UserProfileEntity?>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun saveUserProfile(profile: UserProfileEntity)

  // Memories
  @Query("SELECT * FROM ai_memories ORDER BY timestamp DESC")
  fun getAllMemories(): Flow<List<MemoryEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMemory(memory: MemoryEntity): Long

  @Query("DELETE FROM ai_memories WHERE id = :id")
  suspend fun deleteMemory(id: Long)

  @Query("DELETE FROM ai_memories WHERE key LIKE :query OR value LIKE :query")
  suspend fun deleteMemoryByContent(query: String)

  @Query("DELETE FROM ai_memories")
  suspend fun clearAllMemories()

  // Game Scores
  @Query("SELECT * FROM game_scores ORDER BY timestamp DESC")
  fun getAllScores(): Flow<List<GameScoreEntity>>

  @Query("SELECT MAX(score) FROM game_scores WHERE gameType = :gameType")
  fun getHighScore(gameType: String): Flow<Int?>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun recordGameScore(score: GameScoreEntity)

  // Badges
  @Query("SELECT * FROM user_badges")
  fun getAllBadges(): Flow<List<BadgeEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrUpdateBadge(badge: BadgeEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAllBadges(badges: List<BadgeEntity>)
}
