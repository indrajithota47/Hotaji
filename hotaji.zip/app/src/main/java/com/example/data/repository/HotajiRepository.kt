package com.example.data.repository

import com.example.data.ai.AgentType
import com.example.data.ai.GeminiClient
import com.example.data.local.BadgeEntity
import com.example.data.local.GameScoreEntity
import com.example.data.local.HotajiDao
import com.example.data.local.MemoryEntity
import com.example.data.local.UserProfileEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class HotajiRepository(
  private val dao: HotajiDao,
  private val geminiClient: GeminiClient = GeminiClient()
) {

  val userProfile: Flow<UserProfileEntity?> = dao.getUserProfile()
  val allMemories: Flow<List<MemoryEntity>> = dao.getAllMemories()
  val allScores: Flow<List<GameScoreEntity>> = dao.getAllScores()
  val allBadges: Flow<List<BadgeEntity>> = dao.getAllBadges()

  suspend fun initializeDefaultsIfNeeded() {
    val profile = dao.getUserProfile().firstOrNull()
    if (profile == null) {
      dao.saveUserProfile(
        UserProfileEntity(
          id = 1,
          fullName = "Indrajit Hota",
          email = "indrajithota5@gmail.com",
          gender = "Male",
          isOnboarded = true,
          activeEngagementMinutes = 135,
          selectedAvatar = "Arjun",
          selectedLanguage = "Odia (ଓଡ଼ିଆ)",
          selectedAccent = "Cuttack-Bhubaneswar Standard",
          arcadeVoiceLanguage = "Odia",
          privacyEncryptionEnabled = true,
          offlineModeActive = false
        )
      )
    }

    val badges = dao.getAllBadges().firstOrNull()
    if (badges.isNullOrEmpty()) {
      dao.insertAllBadges(defaultBadges())
    }
  }

  suspend fun updateUserProfile(profile: UserProfileEntity) {
    dao.saveUserProfile(profile)
  }

  suspend fun addActiveMinutes(minutes: Int) {
    val current = dao.getUserProfile().firstOrNull() ?: UserProfileEntity()
    val updatedMinutes = current.activeEngagementMinutes + minutes
    dao.saveUserProfile(current.copy(activeEngagementMinutes = updatedMinutes))
    checkAndUpdateBadgeProgress(updatedMinutes)
  }

  // Memory management: Remember this / Forget this
  suspend fun remember(key: String, value: String, category: String = "User Preference") {
    dao.insertMemory(MemoryEntity(key = key, value = value, category = category))
  }

  suspend fun forget(id: Long) {
    dao.deleteMemory(id)
  }

  suspend fun forgetByQuery(query: String) {
    dao.deleteMemoryByContent("%$query%")
  }

  suspend fun clearMemories() {
    dao.clearAllMemories()
  }

  // Arcade scores
  suspend fun recordGameScore(gameType: String, score: Int, accuracy: Int, difficulty: String) {
    dao.recordGameScore(
      GameScoreEntity(
        gameType = gameType,
        score = score,
        accuracyPercent = accuracy,
        difficulty = difficulty
      )
    )
    addActiveMinutes(5)
  }

  suspend fun getAiResponse(
    agent: AgentType,
    query: String,
    languageName: String,
    memories: List<String> = emptyList()
  ): String {
    addActiveMinutes(2)
    return geminiClient.generateAgentResponse(agent, query, languageName, memories)
  }

  private suspend fun checkAndUpdateBadgeProgress(activeMinutes: Int) {
    val bronzeProgress = (activeMinutes.toFloat() / 120f).coerceIn(0f, 1f) // 2 hours = 120 min
    val silverProgress = (activeMinutes.toFloat() / 300f).coerceIn(0f, 1f) // 5 hours
    val goldProgress = (activeMinutes.toFloat() / 600f).coerceIn(0f, 1f) // 10 hours
    val platinumProgress = (activeMinutes.toFloat() / 1000f).coerceIn(0f, 1f)
    val diamondProgress = (activeMinutes.toFloat() / 1500f).coerceIn(0f, 1f)
    val rubyProgress = (activeMinutes.toFloat() / 2400f).coerceIn(0f, 1f)
    val eliteProgress = (activeMinutes.toFloat() / 3600f).coerceIn(0f, 1f)
    val masterLegendProgress = (activeMinutes.toFloat() / 5000f).coerceIn(0f, 1f)

    dao.insertOrUpdateBadge(
      BadgeEntity(
        badgeId = "bronze_explorer",
        title = "Bronze Badge",
        tierName = "Beginner Explorer",
        description = "Unlocked after 2 hours of active platform engagement.",
        isUnlocked = bronzeProgress >= 1f,
        progress = bronzeProgress,
        unlockedDate = if (bronzeProgress >= 1f) "Verified Active" else null
      )
    )
    dao.insertOrUpdateBadge(
      BadgeEntity(
        badgeId = "silver_practitioner",
        title = "Silver Badge",
        tierName = "Regular Practitioner",
        description = "Multi-day interaction across diverse agent modes.",
        isUnlocked = silverProgress >= 1f,
        progress = silverProgress,
        unlockedDate = if (silverProgress >= 1f) "Verified Active" else null
      )
    )
    dao.insertOrUpdateBadge(
      BadgeEntity(
        badgeId = "gold_scholar",
        title = "Gold Badge",
        tierName = "Dedicated Scholar",
        description = "Deep continuous usage (learning, coding, research).",
        isUnlocked = goldProgress >= 1f,
        progress = goldProgress,
        unlockedDate = if (goldProgress >= 1f) "Verified Active" else null
      )
    )
    dao.insertOrUpdateBadge(
      BadgeEntity(
        badgeId = "platinum_creator",
        title = "Platinum Badge",
        tierName = "Advanced Creator",
        description = "Unlocked via multi-modal image and document mastery.",
        isUnlocked = platinumProgress >= 1f,
        progress = platinumProgress
      )
    )
    dao.insertOrUpdateBadge(
      BadgeEntity(
        badgeId = "diamond_power_user",
        title = "Diamond Badge",
        tierName = "Power User",
        description = "Sustained engagement across productivity and career modules.",
        isUnlocked = diamondProgress >= 1f,
        progress = diamondProgress
      )
    )
    dao.insertOrUpdateBadge(
      BadgeEntity(
        badgeId = "ruby_elite",
        title = "Ruby Badge",
        tierName = "Elites of Hotaji",
        description = "Milestone badge for exceptional long-term interaction.",
        isUnlocked = rubyProgress >= 1f,
        progress = rubyProgress
      )
    )
    dao.insertOrUpdateBadge(
      BadgeEntity(
        badgeId = "elite_architect",
        title = "Elite Badge",
        tierName = "Master Architect",
        description = "Mastery across all internal AI agents over months.",
        isUnlocked = eliteProgress >= 1f,
        progress = eliteProgress
      )
    )
    dao.insertOrUpdateBadge(
      BadgeEntity(
        badgeId = "master_legend",
        title = "Master Legend Badge",
        tierName = "Ultimate Sovereign",
        description = "Peak tier representing complete personal AI operating system integration.",
        isUnlocked = masterLegendProgress >= 1f,
        progress = masterLegendProgress
      )
    )
  }

  private fun defaultBadges(): List<BadgeEntity> = listOf(
    BadgeEntity(
      badgeId = "bronze_explorer",
      title = "Bronze Badge",
      tierName = "Beginner Explorer",
      description = "Unlocked after 2 hours of total active platform engagement.",
      isUnlocked = true,
      progress = 1.0f,
      unlockedDate = "Unlocked Today"
    ),
    BadgeEntity(
      badgeId = "silver_practitioner",
      title = "Silver Badge",
      tierName = "Regular Practitioner",
      description = "Multi-day interaction across diverse agent modes.",
      isUnlocked = false,
      progress = 0.45f
    ),
    BadgeEntity(
      badgeId = "gold_scholar",
      title = "Gold Badge",
      tierName = "Dedicated Scholar",
      description = "Deep continuous usage (learning, coding, research).",
      isUnlocked = false,
      progress = 0.22f
    ),
    BadgeEntity(
      badgeId = "platinum_creator",
      title = "Platinum Badge",
      tierName = "Advanced Creator",
      description = "Unlocked via multi-modal image and document mastery.",
      isUnlocked = false,
      progress = 0.15f
    ),
    BadgeEntity(
      badgeId = "diamond_power_user",
      title = "Diamond Badge",
      tierName = "Power User",
      description = "Sustained engagement across productivity and career modules.",
      isUnlocked = false,
      progress = 0.10f
    ),
    BadgeEntity(
      badgeId = "ruby_elite",
      title = "Ruby Badge",
      tierName = "Elites of Hotaji",
      description = "Milestone badge for exceptional long-term interaction.",
      isUnlocked = false,
      progress = 0.05f
    ),
    BadgeEntity(
      badgeId = "elite_architect",
      title = "Elite Badge",
      tierName = "Master Architect",
      description = "Mastery across all internal AI agents over months.",
      isUnlocked = false,
      progress = 0.02f
    ),
    BadgeEntity(
      badgeId = "master_legend",
      title = "Master Legend Badge",
      tierName = "Ultimate Sovereign",
      description = "Peak tier representing complete personal AI integration.",
      isUnlocked = false,
      progress = 0.01f
    )
  )
}
