package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
  entities = [
    UserProfileEntity::class,
    MemoryEntity::class,
    GameScoreEntity::class,
    BadgeEntity::class
  ],
  version = 1,
  exportSchema = false
)
abstract class HotajiDatabase : RoomDatabase() {
  abstract fun hotajiDao(): HotajiDao

  companion object {
    @Volatile
    private var INSTANCE: HotajiDatabase? = null

    fun getDatabase(context: Context): HotajiDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          HotajiDatabase::class.java,
          "hotaji_paios_db"
        ).fallbackToDestructiveMigration().build()
        INSTANCE = instance
        instance
      }
    }
  }
}
