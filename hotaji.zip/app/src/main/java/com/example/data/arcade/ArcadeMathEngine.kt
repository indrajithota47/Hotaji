package com.example.data.arcade

import java.util.Random

enum class MathGradeLevel(val label: String, val description: String) {
  ALL("All Grades", "Mixed 1st to 5th Grade challenge"),
  GRADE_1("Grade 1", "Basic Addition & Subtraction (1-20)"),
  GRADE_2("Grade 2", "Double Digits & 2x, 5x, 10x Tables"),
  GRADE_3("Grade 3", "Multiplication, Division & Word Math"),
  GRADE_4("Grade 4", "Multi-step, Time, Measurement & Geometry"),
  GRADE_5("Grade 5", "BODMAS, Patterns, Fractions & Logic Puzzles")
}

data class MathQuestion(
  val id: Int,
  val prompt: String,
  val options: List<String>,
  val correctIndex: Int,
  val explanation: String,
  val gradeLevel: MathGradeLevel,
  val category: String
)

object ArcadeMathEngine {
  private val random = Random()

  // Curated handcrafted grade-level logic & word math problems
  private val curatedMathPuzzles = listOf(
    MathQuestion(
      id = 1001,
      prompt = "A basket has 12 mangoes. You take away 4. How many mangoes do YOU have?",
      options = listOf("4 mangoes", "8 mangoes", "12 mangoes", "0 mangoes"),
      correctIndex = 0,
      explanation = "You took away 4 mangoes, so you personally have 4 mangoes!",
      gradeLevel = MathGradeLevel.GRADE_1,
      category = "Logic Puzzle"
    ),
    MathQuestion(
      id = 1002,
      prompt = "If a cat has 4 legs, how many legs do 5 cats have in total?",
      options = listOf("20 legs", "15 legs", "25 legs", "16 legs"),
      correctIndex = 0,
      explanation = "5 cats × 4 legs each = 20 legs.",
      gradeLevel = MathGradeLevel.GRADE_2,
      category = "Word Arithmetic"
    ),
    MathQuestion(
      id = 1003,
      prompt = "What is the next number in this pattern: 2, 4, 8, 16, ___?",
      options = listOf("32", "24", "30", "64"),
      correctIndex = 0,
      explanation = "Each number doubles (multiplied by 2): 16 × 2 = 32.",
      gradeLevel = MathGradeLevel.GRADE_3,
      category = "Pattern Logic"
    ),
    MathQuestion(
      id = 1004,
      prompt = "How many hours are there in 3 full days?",
      options = listOf("72 hours", "48 hours", "60 hours", "96 hours"),
      correctIndex = 0,
      explanation = "1 day = 24 hours. 3 days × 24 = 72 hours.",
      gradeLevel = MathGradeLevel.GRADE_3,
      category = "Time & Measurement"
    ),
    MathQuestion(
      id = 1005,
      prompt = "A square has a side of 6 cm. What is its total perimeter?",
      options = listOf("24 cm", "36 cm", "18 cm", "12 cm"),
      correctIndex = 0,
      explanation = "Perimeter of a square = 4 × side = 4 × 6 = 24 cm.",
      gradeLevel = MathGradeLevel.GRADE_4,
      category = "Geometry Logic"
    ),
    MathQuestion(
      id = 1006,
      prompt = "Solve using BODMAS: 10 + 5 × 2 = ?",
      options = listOf("20", "30", "25", "15"),
      correctIndex = 0,
      explanation = "Multiply first: 5 × 2 = 10. Then add: 10 + 10 = 20.",
      gradeLevel = MathGradeLevel.GRADE_5,
      category = "Order of Operations"
    ),
    MathQuestion(
      id = 1007,
      prompt = "What number multiplied by itself equals 64?",
      options = listOf("8", "6", "7", "9"),
      correctIndex = 0,
      explanation = "8 × 8 = 64 (the square root of 64 is 8).",
      gradeLevel = MathGradeLevel.GRADE_4,
      category = "Square Numbers"
    ),
    MathQuestion(
      id = 1008,
      prompt = "If a train travels 60 km in 1 hour, how far will it travel in 4 hours?",
      options = listOf("240 km", "180 km", "300 km", "200 km"),
      correctIndex = 0,
      explanation = "Speed × Time = 60 km/h × 4 h = 240 km.",
      gradeLevel = MathGradeLevel.GRADE_4,
      category = "Speed & Distance"
    ),
    MathQuestion(
      id = 1009,
      prompt = "How many minutes are in 2 hours and 30 minutes?",
      options = listOf("150 mins", "120 mins", "180 mins", "140 mins"),
      correctIndex = 0,
      explanation = "(2 × 60) + 30 = 120 + 30 = 150 minutes.",
      gradeLevel = MathGradeLevel.GRADE_3,
      category = "Time Arithmetic"
    ),
    MathQuestion(
      id = 1010,
      prompt = "Solve: (100 - 25) ÷ 3 = ?",
      options = listOf("25", "30", "15", "35"),
      correctIndex = 0,
      explanation = "Inside brackets: 100 - 25 = 75. Then 75 ÷ 3 = 25.",
      gradeLevel = MathGradeLevel.GRADE_5,
      category = "BODMAS & Division"
    ),
    MathQuestion(
      id = 1011,
      prompt = "I am an even number between 30 and 40. My digits add up to 8. Who am I?",
      options = listOf("None", "35", "36", "38"),
      correctIndex = 0,
      explanation = "Between 30 and 40, digits adding to 8 is 35 (which is odd). So none of the even numbers work.",
      gradeLevel = MathGradeLevel.GRADE_5,
      category = "Number Riddle"
    ),
    MathQuestion(
      id = 1012,
      prompt = "If 1 dozen bananas is 12 bananas, how many bananas are in 4 dozen?",
      options = listOf("48 bananas", "44 bananas", "36 bananas", "52 bananas"),
      correctIndex = 0,
      explanation = "4 dozen × 12 = 48 bananas.",
      gradeLevel = MathGradeLevel.GRADE_2,
      category = "Word Arithmetic"
    ),
    MathQuestion(
      id = 1013,
      prompt = "What is half of 250?",
      options = listOf("125", "115", "135", "150"),
      correctIndex = 0,
      explanation = "250 ÷ 2 = 125.",
      gradeLevel = MathGradeLevel.GRADE_4,
      category = "Mental Math"
    ),
    MathQuestion(
      id = 1014,
      prompt = "How many sides does a regular Pentagon have?",
      options = listOf("5 sides", "6 sides", "8 sides", "4 sides"),
      correctIndex = 0,
      explanation = "A pentagon has 5 sides (penta = 5).",
      gradeLevel = MathGradeLevel.GRADE_3,
      category = "Geometry"
    ),
    MathQuestion(
      id = 1015,
      prompt = "Find the missing number: 40 + ___ = 100",
      options = listOf("60", "50", "70", "40"),
      correctIndex = 0,
      explanation = "100 - 40 = 60.",
      gradeLevel = MathGradeLevel.GRADE_2,
      category = "Missing Number"
    )
  )

  /**
   * Generates a completely dynamic math problem according to selected grade level.
   * Can generate thousands of distinct variations covering arithmetic, logic, and word problems.
   */
  fun generateQuestion(gradeChoice: MathGradeLevel = MathGradeLevel.ALL): MathQuestion {
    // 25% chance of picking a curated logic puzzle if grade matches or ALL
    if (random.nextInt(4) == 0) {
      val matchingCurated = if (gradeChoice == MathGradeLevel.ALL) {
        curatedMathPuzzles
      } else {
        curatedMathPuzzles.filter { it.gradeLevel == gradeChoice }
      }
      if (matchingCurated.isNotEmpty()) {
        val picked = matchingCurated[random.nextInt(matchingCurated.size)]
        return shuffleOptions(picked)
      }
    }

    val targetGrade = if (gradeChoice == MathGradeLevel.ALL) {
      val grades = listOf(
        MathGradeLevel.GRADE_1,
        MathGradeLevel.GRADE_2,
        MathGradeLevel.GRADE_3,
        MathGradeLevel.GRADE_4,
        MathGradeLevel.GRADE_5
      )
      grades[random.nextInt(grades.size)]
    } else {
      gradeChoice
    }

    return when (targetGrade) {
      MathGradeLevel.GRADE_1 -> generateGrade1Question()
      MathGradeLevel.GRADE_2 -> generateGrade2Question()
      MathGradeLevel.GRADE_3 -> generateGrade3Question()
      MathGradeLevel.GRADE_4 -> generateGrade4Question()
      MathGradeLevel.GRADE_5 -> generateGrade5Question()
      MathGradeLevel.ALL -> generateGrade3Question()
    }
  }

  // --- GRADE 1: Numbers up to 20, visual counting, basic +/- ---
  private fun generateGrade1Question(): MathQuestion {
    val id = random.nextInt(100000)
    val mode = random.nextInt(3)
    return when (mode) {
      0 -> {
        // Simple Addition (1 to 10 + 1 to 10)
        val a = random.nextInt(10) + 1
        val b = random.nextInt(10) + 1
        val ans = a + b
        val prompt = "$a + $b = ?"
        val options = createDistractors(ans)
        MathQuestion(
          id = id,
          prompt = prompt,
          options = options.first,
          correctIndex = options.second,
          explanation = "$a plus $b equals $ans.",
          gradeLevel = MathGradeLevel.GRADE_1,
          category = "Basic Addition"
        )
      }
      1 -> {
        // Simple Subtraction (up to 18)
        val b = random.nextInt(8) + 1
        val a = b + random.nextInt(10) + 1
        val ans = a - b
        val prompt = "$a - $b = ?"
        val options = createDistractors(ans)
        MathQuestion(
          id = id,
          prompt = prompt,
          options = options.first,
          correctIndex = options.second,
          explanation = "$a minus $b equals $ans.",
          gradeLevel = MathGradeLevel.GRADE_1,
          category = "Basic Subtraction"
        )
      }
      else -> {
        // Grade 1 Fun Word Problem
        val items = listOf("apples", "balloons", "pencils", "stars", "cookies", "candies", "flowers")
        val item = items[random.nextInt(items.size)]
        val a = random.nextInt(6) + 2
        val b = random.nextInt(5) + 1
        val ans = a + b
        val prompt = "You have $a $item. Your friend gives you $b more. How many $item do you have?"
        val options = createDistractors(ans, suffix = " $item")
        MathQuestion(
          id = id,
          prompt = prompt,
          options = options.first,
          correctIndex = options.second,
          explanation = "$a + $b = $ans $item in total.",
          gradeLevel = MathGradeLevel.GRADE_1,
          category = "Word Problem"
        )
      }
    }
  }

  // --- GRADE 2: Double digits, 2x, 5x, 10x tables, sequence ---
  private fun generateGrade2Question(): MathQuestion {
    val id = random.nextInt(100000)
    val mode = random.nextInt(4)
    return when (mode) {
      0 -> {
        // 2-digit Addition without carry or simple carry (10-50)
        val a = random.nextInt(40) + 10
        val b = random.nextInt(40) + 10
        val ans = a + b
        val prompt = "$a + $b = ?"
        val options = createDistractors(ans)
        MathQuestion(
          id = id,
          prompt = prompt,
          options = options.first,
          correctIndex = options.second,
          explanation = "$a + $b = $ans.",
          gradeLevel = MathGradeLevel.GRADE_2,
          category = "2-Digit Addition"
        )
      }
      1 -> {
        // 2-digit Subtraction
        val b = random.nextInt(30) + 10
        val a = b + random.nextInt(40) + 5
        val ans = a - b
        val prompt = "$a - $b = ?"
        val options = createDistractors(ans)
        MathQuestion(
          id = id,
          prompt = prompt,
          options = options.first,
          correctIndex = options.second,
          explanation = "$a - $b = $ans.",
          gradeLevel = MathGradeLevel.GRADE_2,
          category = "2-Digit Subtraction"
        )
      }
      2 -> {
        // Tables: 2, 5, or 10
        val base = listOf(2, 5, 10)[random.nextInt(3)]
        val multiplier = random.nextInt(10) + 1
        val ans = base * multiplier
        val prompt = "$base × $multiplier = ?"
        val options = createDistractors(ans)
        MathQuestion(
          id = id,
          prompt = prompt,
          options = options.first,
          correctIndex = options.second,
          explanation = "$base multiplied by $multiplier = $ans.",
          gradeLevel = MathGradeLevel.GRADE_2,
          category = "Multiplication Tables"
        )
      }
      else -> {
        // Skip counting / simple pattern
        val step = listOf(2, 5, 10, 3)[random.nextInt(4)]
        val start = random.nextInt(5) + 1
        val s1 = start
        val s2 = s1 + step
        val s3 = s2 + step
        val ans = s3 + step
        val prompt = "What is the next number: $s1, $s2, $s3, ___?"
        val options = createDistractors(ans)
        MathQuestion(
          id = id,
          prompt = prompt,
          options = options.first,
          correctIndex = options.second,
          explanation = "The pattern increases by +$step each time ($s3 + $step = $ans).",
          gradeLevel = MathGradeLevel.GRADE_2,
          category = "Number Pattern"
        )
      }
    }
  }

  // --- GRADE 3: Full 1-12 tables, Division, Word Problems ---
  private fun generateGrade3Question(): MathQuestion {
    val id = random.nextInt(100000)
    val mode = random.nextInt(4)
    return when (mode) {
      0 -> {
        // Tables 3 to 12
        val a = random.nextInt(10) + 3
        val b = random.nextInt(10) + 3
        val ans = a * b
        val prompt = "$a × $b = ?"
        val options = createDistractors(ans)
        MathQuestion(
          id = id,
          prompt = prompt,
          options = options.first,
          correctIndex = options.second,
          explanation = "$a × $b = $ans.",
          gradeLevel = MathGradeLevel.GRADE_3,
          category = "Multiplication"
        )
      }
      1 -> {
        // Exact Division
        val divisor = random.nextInt(8) + 2
        val quotient = random.nextInt(10) + 2
        val dividend = divisor * quotient
        val prompt = "$dividend ÷ $divisor = ?"
        val options = createDistractors(quotient)
        MathQuestion(
          id = id,
          prompt = prompt,
          options = options.first,
          correctIndex = options.second,
          explanation = "$dividend divided by $divisor is $quotient (since $divisor × $quotient = $dividend).",
          gradeLevel = MathGradeLevel.GRADE_3,
          category = "Division"
        )
      }
      2 -> {
        // Missing Number in Equation
        val a = random.nextInt(50) + 20
        val b = random.nextInt(40) + 10
        val total = a + b
        val prompt = "$a + ___ = $total"
        val options = createDistractors(b)
        MathQuestion(
          id = id,
          prompt = prompt,
          options = options.first,
          correctIndex = options.second,
          explanation = "$total - $a = $b.",
          gradeLevel = MathGradeLevel.GRADE_3,
          category = "Equation Solver"
        )
      }
      else -> {
        // Money / Cost Word problem
        val items = listOf("pencils", "ice creams", "notebooks", "chocolates", "erasers")
        val item = items[random.nextInt(items.size)]
        val costPerUnit = random.nextInt(8) + 3
        val count = random.nextInt(6) + 3
        val total = costPerUnit * count
        val prompt = "If 1 $item costs ₹$costPerUnit, how much do $count $item cost?"
        val options = createDistractors(total, prefix = "₹")
        MathQuestion(
          id = id,
          prompt = prompt,
          options = options.first,
          correctIndex = options.second,
          explanation = "$count × ₹$costPerUnit = ₹$total.",
          gradeLevel = MathGradeLevel.GRADE_3,
          category = "Money Arithmetic"
        )
      }
    }
  }

  // --- GRADE 4: Multi-step, Fractions, Geometry, Time ---
  private fun generateGrade4Question(): MathQuestion {
    val id = random.nextInt(100000)
    val mode = random.nextInt(4)
    return when (mode) {
      0 -> {
        // Multi-step addition & subtraction
        val a = random.nextInt(60) + 40
        val b = random.nextInt(30) + 15
        val c = random.nextInt(20) + 10
        val ans = a + b - c
        val prompt = "$a + $b - $c = ?"
        val options = createDistractors(ans)
        MathQuestion(
          id = id,
          prompt = prompt,
          options = options.first,
          correctIndex = options.second,
          explanation = "$a + $b = ${a + b}. Then ${a + b} - $c = $ans.",
          gradeLevel = MathGradeLevel.GRADE_4,
          category = "Multi-Step Arithmetic"
        )
      }
      1 -> {
        // Double digit multiplication
        val a = random.nextInt(15) + 11
        val b = random.nextInt(8) + 4
        val ans = a * b
        val prompt = "$a × $b = ?"
        val options = createDistractors(ans)
        MathQuestion(
          id = id,
          prompt = prompt,
          options = options.first,
          correctIndex = options.second,
          explanation = "$a × $b = $ans.",
          gradeLevel = MathGradeLevel.GRADE_4,
          category = "Multiplication"
        )
      }
      2 -> {
        // Time & Conversion
        val hours = random.nextInt(4) + 2
        val minutes = hours * 60
        val prompt = "How many minutes are in $hours hours?"
        val options = createDistractors(minutes, suffix = " mins")
        MathQuestion(
          id = id,
          prompt = prompt,
          options = options.first,
          correctIndex = options.second,
          explanation = "$hours × 60 minutes = $minutes minutes.",
          gradeLevel = MathGradeLevel.GRADE_4,
          category = "Time Conversion"
        )
      }
      else -> {
        // Rectangle area / perimeter
        val length = random.nextInt(8) + 4
        val width = random.nextInt(length - 2) + 2
        val area = length * width
        val prompt = "A rectangle has length $length cm and width $width cm. What is its Area?"
        val options = createDistractors(area, suffix = " sq cm")
        MathQuestion(
          id = id,
          prompt = prompt,
          options = options.first,
          correctIndex = options.second,
          explanation = "Area = Length × Width = $length × $width = $area sq cm.",
          gradeLevel = MathGradeLevel.GRADE_4,
          category = "Geometry Area"
        )
      }
    }
  }

  // --- GRADE 5: BODMAS, Patterns, Percentages, Squares ---
  private fun generateGrade5Question(): MathQuestion {
    val id = random.nextInt(100000)
    val mode = random.nextInt(4)
    return when (mode) {
      0 -> {
        // BODMAS brackets and operations: (a + b) × c or (a × b) + c
        val a = random.nextInt(10) + 4
        val b = random.nextInt(8) + 2
        val c = random.nextInt(6) + 3
        val isFirst = random.nextBoolean()
        if (isFirst) {
          val ans = (a + b) * c
          val prompt = "($a + $b) × $c = ?"
          val options = createDistractors(ans)
          MathQuestion(
            id = id,
            prompt = prompt,
            options = options.first,
            correctIndex = options.second,
            explanation = "Brackets first: $a + $b = ${a + b}. Then ${a + b} × $c = $ans.",
            gradeLevel = MathGradeLevel.GRADE_5,
            category = "BODMAS"
          )
        } else {
          val ans = (a * b) + c
          val prompt = "$a × $b + $c = ?"
          val options = createDistractors(ans)
          MathQuestion(
            id = id,
            prompt = prompt,
            options = options.first,
            correctIndex = options.second,
            explanation = "Multiply first: $a × $b = ${a * b}. Then add $c = $ans.",
            gradeLevel = MathGradeLevel.GRADE_5,
            category = "Order of Operations"
          )
        }
      }
      1 -> {
        // Simple Percentages (10%, 20%, 25%, 50%)
        val pct = listOf(10, 20, 25, 50)[random.nextInt(4)]
        val baseMultiplier = random.nextInt(6) + 2
        val num = when (pct) {
          10 -> baseMultiplier * 50
          20 -> baseMultiplier * 50
          25 -> baseMultiplier * 40
          else -> baseMultiplier * 20
        }
        val ans = (num * pct) / 100
        val prompt = "What is $pct% of $num?"
        val options = createDistractors(ans)
        MathQuestion(
          id = id,
          prompt = prompt,
          options = options.first,
          correctIndex = options.second,
          explanation = "($pct × $num) ÷ 100 = $ans.",
          gradeLevel = MathGradeLevel.GRADE_5,
          category = "Percentages"
        )
      }
      2 -> {
        // Square numbers
        val n = random.nextInt(12) + 4
        val ans = n * n
        val prompt = "What is the square of $n ($n²)? "
        val options = createDistractors(ans)
        MathQuestion(
          id = id,
          prompt = prompt,
          options = options.first,
          correctIndex = options.second,
          explanation = "$n × $n = $ans.",
          gradeLevel = MathGradeLevel.GRADE_5,
          category = "Squares & Powers"
        )
      }
      else -> {
        // Logic Pattern (Geometric sequence or Fibonacci style)
        val factor = random.nextInt(3) + 2
        val start = random.nextInt(4) + 2
        val s1 = start
        val s2 = s1 * factor
        val s3 = s2 * factor
        val ans = s3 * factor
        val prompt = "What is the next number: $s1, $s2, $s3, ___?"
        val options = createDistractors(ans)
        MathQuestion(
          id = id,
          prompt = prompt,
          options = options.first,
          correctIndex = options.second,
          explanation = "Each number is multiplied by $factor ($s3 × $factor = $ans).",
          gradeLevel = MathGradeLevel.GRADE_5,
          category = "Pattern Sequence"
        )
      }
    }
  }

  // Generates 3 intelligent distractors and returns a shuffled list + correct index
  private fun createDistractors(correct: Int, prefix: String = "", suffix: String = ""): Pair<List<String>, Int> {
    val offsets = listOf(1, -1, 2, -2, 5, -5, 10, -10, 3, -3, 4, -4).shuffled()
    val wrongSet = mutableSetOf<Int>()
    for (off in offsets) {
      val candidate = correct + off
      if (candidate > 0 && candidate != correct) {
        wrongSet.add(candidate)
      }
      if (wrongSet.size == 3) break
    }
    // Fallback if set not full
    while (wrongSet.size < 3) {
      val fallback = correct + (wrongSet.size + 1) * 3
      if (fallback != correct) wrongSet.add(fallback)
    }

    val allOptions = (wrongSet.toList() + correct).shuffled()
    val correctIndex = allOptions.indexOf(correct)
    val formatted = allOptions.map { "$prefix$it$suffix" }
    return Pair(formatted, correctIndex)
  }

  private fun shuffleOptions(q: MathQuestion): MathQuestion {
    val correctValue = q.options[q.correctIndex]
    val shuffled = q.options.shuffled()
    val newIdx = shuffled.indexOf(correctValue)
    return q.copy(options = shuffled, correctIndex = newIdx)
  }
}
