package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.HelpCenter
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.HotajiDatabase
import com.example.data.local.UserProfileEntity
import com.example.data.repository.HotajiRepository
import com.example.data.voice.VoiceEngine
import com.example.ui.components.AppDestination
import com.example.ui.components.HelpSupportBox
import com.example.ui.components.HotajiNavigationDrawerContent
import com.example.ui.components.SafetyBannerModal
import com.example.ui.screens.AgentsHubScreen
import com.example.ui.screens.ArcadeHubScreen
import com.example.ui.screens.BadgeVaultScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.SettingsSupportScreen
import com.example.ui.screens.VisionStudioScreen
import com.example.ui.screens.VoiceOperatingSystemScreen
import com.example.ui.theme.AestheticGold
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateElevated
import com.example.ui.theme.DarkSlateGlass
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateMuted
import com.example.ui.theme.SoftAqua
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

  private lateinit var voiceEngine: VoiceEngine
  private lateinit var repository: HotajiRepository

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    val db = HotajiDatabase.getDatabase(this)
    repository = HotajiRepository(db.hotajiDao())
    voiceEngine = VoiceEngine(this)

    setContent {
      MyApplicationTheme {
        HotajiApp(
          repository = repository,
          voiceEngine = voiceEngine
        )
      }
    }
  }

  override fun onDestroy() {
    super.onDestroy()
    voiceEngine.shutdown()
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HotajiApp(
  repository: HotajiRepository,
  voiceEngine: VoiceEngine
) {
  val coroutineScope = rememberCoroutineScope()
  val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
  var currentDestination by remember { mutableStateOf(AppDestination.VOICE_OS) }
  var isHelpVisible by remember { mutableStateOf(false) }
  var isSafetyModalOpen by remember { mutableStateOf(false) }

  val userProfile by repository.userProfile.collectAsState(initial = null)

  LaunchedEffect(Unit) {
    repository.initializeDefaultsIfNeeded()
  }

  val profile = userProfile ?: UserProfileEntity()

  if (!profile.isOnboarded) {
    OnboardingScreen(
      onCompleteOnboarding = { newProfile ->
        coroutineScope.launch {
          repository.updateUserProfile(newProfile)
          voiceEngine.playSuccessSound()
        }
      }
    )
    return
  }

  ModalNavigationDrawer(
    drawerState = drawerState,
    drawerContent = {
      ModalDrawerSheet(
        drawerContainerColor = ObsidianBlack,
        modifier = Modifier.testTag("modal_nav_drawer_sheet")
      ) {
        HotajiNavigationDrawerContent(
          currentDestination = currentDestination,
          onSelectDestination = { dest ->
            currentDestination = dest
            coroutineScope.launch { drawerState.close() }
            voiceEngine.playSuccessSound()
          }
        )
      }
    }
  ) {
    Scaffold(
      modifier = Modifier
        .fillMaxSize()
        .background(ObsidianBlack),
      containerColor = ObsidianBlack,
      topBar = {
        TopAppBar(
          title = {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Text(
                text = "Hotaji",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
                color = PureWhite
              )
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(AestheticGold.copy(alpha = 0.2f))
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(
                  text = "PAIOS v1.0",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = AestheticGold
                )
              }
            }
          },
          navigationIcon = {
            IconButton(
              onClick = { coroutineScope.launch { drawerState.open() } },
              modifier = Modifier.testTag("nav_drawer_toggle_button")
            ) {
              Icon(
                imageVector = Icons.Default.Menu,
                contentDescription = "Open Drawer",
                tint = PureWhite
              )
            }
          },
          actions = {
            // Mode Toggle indicator (Offline Arcade vs Live OS)
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(DarkSlateElevated)
                .border(1.dp, if (profile.offlineModeActive) AestheticGold else DarkSlateBorder, RoundedCornerShape(12.dp))
                .clickable {
                  coroutineScope.launch {
                    val updatedMode = !profile.offlineModeActive
                    repository.updateUserProfile(profile.copy(offlineModeActive = updatedMode))
                    if (updatedMode) {
                      currentDestination = AppDestination.ARCADE_HUB
                      voiceEngine.speak("Offline Low MB Arcade Hub activated", "en")
                    } else {
                      currentDestination = AppDestination.VOICE_OS
                      voiceEngine.speak("Live Voice Operating System active", "en")
                    }
                  }
                }
                .padding(horizontal = 8.dp, vertical = 4.dp)
                .testTag("top_bar_offline_toggle")
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
              ) {
                Icon(
                  imageVector = if (profile.offlineModeActive) Icons.Default.WifiOff else Icons.Default.Wifi,
                  contentDescription = null,
                  tint = if (profile.offlineModeActive) AestheticGold else SoftAqua,
                  modifier = Modifier.size(14.dp)
                )
                Text(
                  text = if (profile.offlineModeActive) "Offline Mode" else "Live AI",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (profile.offlineModeActive) AestheticGold else PureWhite
                )
              }
            }

            IconButton(
              onClick = { isHelpVisible = !isHelpVisible },
              modifier = Modifier.testTag("toggle_help_top_button")
            ) {
              Icon(
                imageVector = Icons.Default.HelpCenter,
                contentDescription = "Help & Support",
                tint = AestheticGold
              )
            }
          },
          colors = TopAppBarDefaults.topAppBarColors(
            containerColor = ObsidianBlack,
            titleContentColor = PureWhite,
            navigationIconContentColor = PureWhite,
            actionIconContentColor = PureWhite
          )
        )
      }
    ) { innerPadding ->
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(ObsidianBlack)
          .padding(innerPadding)
      ) {
        when (currentDestination) {
          AppDestination.VOICE_OS -> {
            VoiceOperatingSystemScreen(
              repository = repository,
              voiceEngine = voiceEngine,
              profile = profile,
              onSafetyTrigger = { isSafetyModalOpen = true }
            )
          }
          AppDestination.AGENTS_HUB -> {
            AgentsHubScreen(
              repository = repository,
              voiceEngine = voiceEngine,
              profile = profile,
              onSafetyTrigger = { isSafetyModalOpen = true }
            )
          }
          AppDestination.VISION_STUDIO -> {
            VisionStudioScreen(
              repository = repository,
              voiceEngine = voiceEngine,
              onSafetyTrigger = { isSafetyModalOpen = true }
            )
          }
          AppDestination.ARCADE_HUB -> {
            ArcadeHubScreen(
              repository = repository,
              voiceEngine = voiceEngine,
              profile = profile
            )
          }
          AppDestination.BADGE_VAULT -> {
            BadgeVaultScreen(
              repository = repository,
              profile = profile
            )
          }
          AppDestination.SETTINGS_SUPPORT -> {
            SettingsSupportScreen(
              repository = repository,
              voiceEngine = voiceEngine,
              profile = profile,
              onShowHelpDialog = { isHelpVisible = true }
            )
          }
        }

        // Overlay Help Box Assistant
        AnimatedVisibility(
          visible = isHelpVisible,
          enter = fadeIn(),
          exit = fadeOut(),
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .align(Alignment.TopCenter)
        ) {
          HelpSupportBox(onDismiss = { isHelpVisible = false })
        }

        // Safety Violation Warning Modal
        SafetyBannerModal(
          isOpen = isSafetyModalOpen,
          onDismiss = { isSafetyModalOpen = false }
        )
      }
    }
  }
}
