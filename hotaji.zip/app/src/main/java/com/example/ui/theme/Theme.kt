package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val HotajiColorScheme = darkColorScheme(
  primary = AestheticGold,
  onPrimary = ObsidianBlack,
  primaryContainer = DarkSlateElevated,
  onPrimaryContainer = MetallicGoldLight,
  secondary = OceanBlue,
  onSecondary = PureWhite,
  secondaryContainer = DarkSlateGlass,
  onSecondaryContainer = SoftAqua,
  tertiary = SoftAqua,
  onTertiary = ObsidianBlack,
  background = ObsidianBlack,
  onBackground = PureWhite,
  surface = DarkSlateGlass,
  onSurface = PureWhite,
  surfaceVariant = DarkSlateElevated,
  onSurfaceVariant = SlateMuted,
  outline = DarkSlateBorder,
  error = ErrorRed,
  onError = PureWhite
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force ultra-professional dark glassmorphic theme
  dynamicColor: Boolean = false, // Keep brand consistency
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = HotajiColorScheme,
    typography = Typography,
    content = content
  )
}
