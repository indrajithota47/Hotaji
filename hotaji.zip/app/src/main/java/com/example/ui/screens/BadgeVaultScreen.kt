package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.BadgeEntity
import com.example.data.local.UserProfileEntity
import com.example.data.repository.HotajiRepository
import com.example.ui.components.GlassmorphicCard
import com.example.ui.theme.AestheticGold
import com.example.ui.theme.BadgeBronze
import com.example.ui.theme.BadgeDiamond
import com.example.ui.theme.BadgeElite
import com.example.ui.theme.BadgeGold
import com.example.ui.theme.BadgeMasterLegend
import com.example.ui.theme.BadgePlatinum
import com.example.ui.theme.BadgeRuby
import com.example.ui.theme.BadgeSilver
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateElevated
import com.example.ui.theme.DarkSlateGlass
import com.example.ui.theme.MetallicGoldLight
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OceanBlue
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateMuted
import com.example.ui.theme.SoftAqua

@Composable
fun BadgeVaultScreen(
  repository: HotajiRepository,
  profile: UserProfileEntity,
  modifier: Modifier = Modifier
) {
  val badges by repository.allBadges.collectAsState(initial = emptyList())
  val scores by repository.allScores.collectAsState(initial = emptyList())

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(ObsidianBlack)
      .padding(horizontal = 16.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Spacer(modifier = Modifier.height(6.dp))

      // Header
      Column {
        Text(
          text = "Gamified Badge Vault Hub",
          style = MaterialTheme.typography.headlineLarge,
          fontWeight = FontWeight.Black,
          color = PureWhite
        )
        Text(
          text = "8-Tier Sovereign Progression & Engagement Analytics",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = AestheticGold
        )
      }

      // Engagement Stats Hero Card
      GlassmorphicCard(
        modifier = Modifier.fillMaxWidth().testTag("engagement_stats_card"),
        backgroundColor = DarkSlateElevated,
        borderColor = AestheticGold.copy(alpha = 0.5f),
        highlightGold = true
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "Active Platform Engagement",
                style = MaterialTheme.typography.titleMedium,
                color = PureWhite
              )
              Text(
                text = "Tier Status: Active Scholar",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = SoftAqua
              )
            }

            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(AestheticGold.copy(alpha = 0.2f))
                .border(1.dp, AestheticGold, RoundedCornerShape(12.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
              Text(
                text = "${profile.activeEngagementMinutes} Minutes",
                fontWeight = FontWeight.Black,
                fontSize = 12.sp,
                color = AestheticGold
              )
            }
          }

          LinearProgressIndicator(
            progress = { (profile.activeEngagementMinutes.toFloat() / 600f).coerceIn(0f, 1f) },
            modifier = Modifier
              .fillMaxWidth()
              .height(8.dp)
              .clip(RoundedCornerShape(4.dp)),
            color = AestheticGold,
            trackColor = DarkSlateBorder,
            strokeCap = StrokeCap.Round
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = "Total Arcade Sessions: ${scores.size}", fontSize = 11.sp, color = SlateMuted)
            Text(text = "Next Tier: Gold Scholar", fontSize = 11.sp, color = MetallicGoldLight, fontWeight = FontWeight.Bold)
          }
        }
      }

      Text(
        text = "8-TIER PROGRESSIVE BADGE REGISTRY",
        fontSize = 10.sp,
        fontWeight = FontWeight.Black,
        letterSpacing = 1.2.sp,
        color = SlateMuted
      )

      // Badges List
      badges.forEach { badge ->
        BadgeItemRow(badge = badge)
      }

      Spacer(modifier = Modifier.height(20.dp))
    }
  }
}

@Composable
private fun BadgeItemRow(badge: BadgeEntity) {
  val badgeColor = when (badge.badgeId) {
    "bronze_explorer" -> BadgeBronze
    "silver_practitioner" -> BadgeSilver
    "gold_scholar" -> BadgeGold
    "platinum_creator" -> BadgePlatinum
    "diamond_power_user" -> BadgeDiamond
    "ruby_elite" -> BadgeRuby
    "elite_architect" -> BadgeElite
    else -> BadgeMasterLegend
  }

  GlassmorphicCard(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("badge_card_${badge.badgeId}"),
    backgroundColor = if (badge.isUnlocked) DarkSlateElevated else DarkSlateGlass,
    borderColor = if (badge.isUnlocked) badgeColor.copy(alpha = 0.8f) else DarkSlateBorder,
    highlightGold = badge.isUnlocked
  ) {
    Row(
      modifier = Modifier.padding(12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Box(
        modifier = Modifier
          .size(46.dp)
          .clip(CircleShape)
          .background(if (badge.isUnlocked) badgeColor.copy(alpha = 0.2f) else DarkSlateElevated)
          .border(1.5.dp, if (badge.isUnlocked) badgeColor else DarkSlateBorder, CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = if (badge.isUnlocked) Icons.Default.WorkspacePremium else Icons.Default.Lock,
          contentDescription = badge.title,
          tint = if (badge.isUnlocked) badgeColor else SlateMuted,
          modifier = Modifier.size(24.dp)
        )
      }

      Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Text(
            text = badge.title,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            color = if (badge.isUnlocked) PureWhite else SlateMuted
          )
          Text(
            text = "• ${badge.tierName}",
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (badge.isUnlocked) badgeColor else SlateMuted
          )
        }

        Text(
          text = badge.description,
          fontSize = 11.sp,
          color = SlateMuted
        )

        if (!badge.isUnlocked) {
          Spacer(modifier = Modifier.height(2.dp))
          LinearProgressIndicator(
            progress = { badge.progress },
            modifier = Modifier
              .fillMaxWidth()
              .height(4.dp)
              .clip(RoundedCornerShape(2.dp)),
            color = badgeColor,
            trackColor = DarkSlateBorder
          )
        } else {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = badgeColor, modifier = Modifier.size(12.dp))
            Text(text = badge.unlockedDate ?: "Unlocked & Verified", fontSize = 10.sp, color = badgeColor, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}
