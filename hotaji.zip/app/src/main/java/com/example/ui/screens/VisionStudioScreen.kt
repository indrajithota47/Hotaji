package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ai.EpistemicParser
import com.example.data.repository.HotajiRepository
import com.example.data.voice.VoiceEngine
import com.example.ui.components.EpistemicResponseView
import com.example.ui.components.GlassmorphicCard
import com.example.ui.theme.AestheticGold
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateElevated
import com.example.ui.theme.DarkSlateGlass
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MetallicGoldLight
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OceanBlue
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateMuted
import com.example.ui.theme.SoftAqua
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class VisionTab { OCR_DOCUMENT, TEXT_TO_IMAGE, SAFETY_TEST }

@Composable
fun VisionStudioScreen(
  repository: HotajiRepository,
  voiceEngine: VoiceEngine,
  onSafetyTrigger: () -> Unit,
  modifier: Modifier = Modifier
) {
  val coroutineScope = rememberCoroutineScope()
  var activeTab by remember { mutableStateOf(VisionTab.OCR_DOCUMENT) }
  var imagePrompt by remember { mutableStateOf("Golden glowing Konark Sun Temple chakra with futuristic quantum data beams") }
  var selectedAspectRatio by remember { mutableStateOf("1:1") }
  var isSynthesizing by remember { mutableStateOf(false) }

  var ocrScanResult by remember {
    mutableStateOf(
      "[FACT] OCR Scan: 'ଓଡ଼ିଶା ରାଜ୍ୟ ଐତିହ୍ୟ ସଂଗ୍ରହାଳୟ - ସୂଚନା ନଥିକା ୨୦୨୬'. [INTERPRETATION] Document represents an archival cultural catalogue indexed with high-fidelity devanagari and odia ligature recognition."
    )
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(ObsidianBlack)
      .padding(horizontal = 16.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Spacer(modifier = Modifier.height(6.dp))

      Column {
        Text(
          text = "Multi-Modal Vision Studio",
          style = MaterialTheme.typography.headlineLarge,
          fontWeight = FontWeight.Black,
          color = PureWhite
        )
        Text(
          text = "Camera OCR Document Parsing & Visual Synthesis",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = AestheticGold
        )
      }

      // Tab selector
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        VisionTab.values().forEach { tab ->
          val isSel = tab == activeTab
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .background(if (isSel) DarkSlateElevated else DarkSlateGlass)
              .border(1.dp, if (isSel) AestheticGold else DarkSlateBorder, RoundedCornerShape(10.dp))
              .clickable {
                activeTab = tab
                voiceEngine.playSuccessSound()
              }
              .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = when (tab) {
                VisionTab.OCR_DOCUMENT -> "OCR Scan"
                VisionTab.TEXT_TO_IMAGE -> "Text-to-Image"
                VisionTab.SAFETY_TEST -> "Safety Policy"
              },
              fontSize = 11.sp,
              fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
              color = if (isSel) PureWhite else SlateMuted
            )
          }
        }
      }

      when (activeTab) {
        VisionTab.OCR_DOCUMENT -> {
          GlassmorphicCard(modifier = Modifier.fillMaxWidth().testTag("ocr_doc_card")) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                  Icon(imageVector = Icons.Default.DocumentScanner, contentDescription = null, tint = AestheticGold, modifier = Modifier.size(18.dp))
                  Text(text = "Live Document OCR & Diagram Parser", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PureWhite)
                }
              }

              // OCR Viewfinder Preview Box
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .height(160.dp)
                  .clip(RoundedCornerShape(12.dp))
                  .background(DarkSlateElevated)
                  .border(1.dp, DarkSlateBorder, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
              ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                  Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null, tint = SoftAqua, modifier = Modifier.size(36.dp))
                  Text(text = "Optical Character Recognition Ready", fontSize = 12.sp, color = PureWhite, fontWeight = FontWeight.SemiBold)
                  Text(text = "Supports Odia, English, Hindi, and mathematical diagrams", fontSize = 10.sp, color = SlateMuted)
                }
              }

              Button(
                onClick = {
                  voiceEngine.playLaserSound()
                  coroutineScope.launch {
                    ocrScanResult = "[FACT] OCR Extracted: 'ଶ୍ରୀ ଜଗନ୍ନାଥ ସଂସ୍କୃତି ଓ ଓଡ଼ିଶାର କଳା ଐତିହ୍ୟ'. [INTERPRETATION] Archival document dated 1920 verified for structural syntax."
                    voiceEngine.speak("Optical character extraction complete. Document in Odia identified.", "en")
                  }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AestheticGold, contentColor = ObsidianBlack),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth().testTag("scan_sample_doc_button")
              ) {
                Text(text = "Perform Live OCR Scan", fontWeight = FontWeight.Bold)
              }

              EpistemicResponseView(segments = EpistemicParser.parseEpistemicTags(ocrScanResult))
            }
          }
        }

        VisionTab.TEXT_TO_IMAGE -> {
          GlassmorphicCard(modifier = Modifier.fillMaxWidth().testTag("text_to_image_card")) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
              Text(text = "AI Visual Synthesis Studio", fontWeight = FontWeight.Bold, color = PureWhite, fontSize = 14.sp)

              OutlinedTextField(
                value = imagePrompt,
                onValueChange = { imagePrompt = it },
                label = { Text("Prompt description", color = SlateMuted) },
                colors = OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = AestheticGold,
                  unfocusedBorderColor = DarkSlateBorder,
                  focusedTextColor = PureWhite,
                  unfocusedTextColor = PureWhite,
                  focusedContainerColor = DarkSlateElevated,
                  unfocusedContainerColor = DarkSlateElevated
                ),
                modifier = Modifier.fillMaxWidth().testTag("image_prompt_input")
              )

              // Aspect ratio chips
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("1:1", "16:9", "9:16", "4:3").forEach { ratio ->
                  val isR = ratio == selectedAspectRatio
                  Box(
                    modifier = Modifier
                      .clip(RoundedCornerShape(8.dp))
                      .background(if (isR) AestheticGold.copy(alpha = 0.2f) else DarkSlateGlass)
                      .border(1.dp, if (isR) AestheticGold else DarkSlateBorder, RoundedCornerShape(8.dp))
                      .clickable { selectedAspectRatio = ratio }
                      .padding(horizontal = 10.dp, vertical = 6.dp)
                  ) {
                    Text(text = ratio, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isR) AestheticGold else SlateMuted)
                  }
                }
              }

              Button(
                onClick = {
                  if (EpistemicParser.checkSafetyViolation(imagePrompt)) {
                    onSafetyTrigger()
                  } else {
                    isSynthesizing = true
                    coroutineScope.launch {
                      voiceEngine.playLaserSound()
                      delay(1200)
                      isSynthesizing = false
                      voiceEngine.speak("Visual synthesis generated successfully for ratio $selectedAspectRatio", "en")
                    }
                  }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AestheticGold, contentColor = ObsidianBlack),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth().testTag("synthesize_image_button")
              ) {
                Text(text = if (isSynthesizing) "Synthesizing Canvas..." else "Generate Visual Asset", fontWeight = FontWeight.Bold)
              }
            }
          }
        }

        VisionTab.SAFETY_TEST -> {
          GlassmorphicCard(
            modifier = Modifier.fillMaxWidth().testTag("safety_policy_card"),
            borderColor = ErrorRed.copy(alpha = 0.6f)
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(20.dp))
                Text(text = "Cyber Safety Guardrail & Verification", fontWeight = FontWeight.Bold, color = ErrorRed, fontSize = 14.sp)
              }

              Text(
                text = "Hotaji PAIOS enforces an automated real-time safety boundary. Inappropriate or dangerous prompts immediately trigger the official cyber safety warning modal.",
                fontSize = 12.sp,
                color = PureWhite
              )

              Button(
                onClick = onSafetyTrigger,
                colors = ButtonDefaults.buttonColors(containerColor = ErrorRed, contentColor = PureWhite),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().testTag("trigger_safety_modal_button")
              ) {
                Text(text = "Test Safety Violation Modal", fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(20.dp))
    }
  }
}
