package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AestheticGold
import com.example.ui.theme.MetallicGoldLight
import com.example.ui.theme.OceanBlue
import com.example.ui.theme.SoftAqua

enum class OrbState {
  IDLE,
  LISTENING,
  THINKING,
  SPEAKING
}

@Composable
fun VoiceOrb(
  state: OrbState,
  modifier: Modifier = Modifier,
  size: Dp = 190.dp,
  onClick: () -> Unit = {}
) {
  val infiniteTransition = rememberInfiniteTransition(label = "OrbAnimation")

  // Breathing scale animation
  val scaleAnim by infiniteTransition.animateFloat(
    initialValue = when (state) {
      OrbState.IDLE -> 0.96f
      OrbState.LISTENING -> 0.98f
      OrbState.THINKING -> 0.94f
      OrbState.SPEAKING -> 0.92f
    },
    targetValue = when (state) {
      OrbState.IDLE -> 1.04f
      OrbState.LISTENING -> 1.15f
      OrbState.THINKING -> 1.08f
      OrbState.SPEAKING -> 1.18f
    },
    animationSpec = infiniteRepeatable(
      animation = tween(
        durationMillis = when (state) {
          OrbState.IDLE -> 2400
          OrbState.LISTENING -> 800
          OrbState.THINKING -> 600
          OrbState.SPEAKING -> 900
        },
        easing = FastOutSlowInEasing
      ),
      repeatMode = RepeatMode.Reverse
    ),
    label = "Scale"
  )

  // Rotation for 3D gradient movement
  val rotationAnim by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(
        durationMillis = when (state) {
          OrbState.IDLE -> 12000
          OrbState.THINKING -> 3000
          OrbState.SPEAKING -> 5000
          OrbState.LISTENING -> 6000
        },
        easing = LinearEasing
      )
    ),
    label = "Rotation"
  )

  // Outer glow pulse
  val glowAlpha by infiniteTransition.animateFloat(
    initialValue = 0.25f,
    targetValue = if (state == OrbState.IDLE) 0.55f else 0.85f,
    animationSpec = infiniteRepeatable(
      animation = tween(1400, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "GlowAlpha"
  )

  val interactionSource = remember { MutableInteractionSource() }

  Box(
    contentAlignment = Alignment.Center,
    modifier = modifier
      .size(size)
      .scale(scaleAnim)
      .clip(CircleShape)
      .clickable(
        interactionSource = interactionSource,
        indication = null,
        onClick = onClick
      )
      .testTag("voice_orb")
  ) {
    Canvas(modifier = Modifier.size(size)) {
      val centerOffset = Offset(size.toPx() / 2f, size.toPx() / 2f)
      val radius = size.toPx() / 2.3f

      // Outer radial aura (#457B9D & #D4AF37)
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(
            AestheticGold.copy(alpha = glowAlpha * 0.45f),
            OceanBlue.copy(alpha = glowAlpha * 0.30f),
            Color.Transparent
          ),
          center = centerOffset,
          radius = radius * 1.35f
        ),
        radius = radius * 1.35f,
        center = centerOffset
      )

      // Frequency ring ripples
      if (state == OrbState.LISTENING || state == OrbState.SPEAKING) {
        drawCircle(
          color = AestheticGold.copy(alpha = glowAlpha * 0.5f),
          radius = radius * 1.12f,
          center = centerOffset,
          style = Stroke(width = 2.dp.toPx())
        )
        drawCircle(
          color = SoftAqua.copy(alpha = glowAlpha * 0.35f),
          radius = radius * 1.24f,
          center = centerOffset,
          style = Stroke(width = 1.5.dp.toPx())
        )
      }

      // Dynamic 3D Sphere mixing #457B9D (Ocean Blue) and #D4AF37 (Gold)
      val angleRad = Math.toRadians(rotationAnim.toDouble())
      val highlightOffsetX = centerOffset.x + (radius * 0.35f * Math.cos(angleRad)).toFloat()
      val highlightOffsetY = centerOffset.y + (radius * 0.35f * Math.sin(angleRad)).toFloat()

      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(
            MetallicGoldLight,
            AestheticGold,
            OceanBlue,
            Color(0xFF0F1A2A),
            Color(0xFF070B12)
          ),
          center = Offset(highlightOffsetX, highlightOffsetY),
          radius = radius
        ),
        radius = radius,
        center = centerOffset
      )

      // Glass inner specular highlight
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(
            Color.White.copy(alpha = 0.55f),
            Color.White.copy(alpha = 0.05f),
            Color.Transparent
          ),
          center = Offset(centerOffset.x - radius * 0.28f, centerOffset.y - radius * 0.28f),
          radius = radius * 0.45f
        ),
        radius = radius * 0.45f,
        center = Offset(centerOffset.x - radius * 0.28f, centerOffset.y - radius * 0.28f)
      )

      // Perimeter gold micro-rim
      drawCircle(
        brush = Brush.sweepGradient(
          colors = listOf(
            AestheticGold.copy(alpha = 0.8f),
            OceanBlue.copy(alpha = 0.4f),
            SoftAqua.copy(alpha = 0.8f),
            AestheticGold.copy(alpha = 0.8f)
          ),
          center = centerOffset
        ),
        radius = radius,
        center = centerOffset,
        style = Stroke(width = 1.5.dp.toPx())
      )
    }
  }
}
