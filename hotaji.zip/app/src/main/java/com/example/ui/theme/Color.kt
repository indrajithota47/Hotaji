package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Hotaji Obsidian Dark Glassmorphic Theme Palette
// Guardrail: Strictly NO green or purple shades used!
val ObsidianBlack = Color(0xFF0B0F17) // Pitch Black Matte Canvas
val DarkSlateGlass = Color(0xFF161F2E) // Surface / Card Background
val DarkSlateBorder = Color(0xFF2A384C) // 1px Glass Border
val DarkSlateElevated = Color(0xFF1E2B3E) // Slightly elevated surface

// Accent Colors
val OceanBlue = Color(0xFF457B9D) // Ocean Blue for Voice Sphere & Highlights
val SoftAqua = Color(0xFFA8DADC) // Soft Aqua for Overlays & Subtitles
val PureWhite = Color(0xFFFFFFFF) // High contrast white
val OffWhite = Color(0xFFE2E8F0) // High legibility body text
val SlateMuted = Color(0xFF8B9CB3) // Muted description text

// Primary Action Metallic Gold
val AestheticGold = Color(0xFFD4AF37) // Primary Accent & Voice Sphere Gold
val MetallicGoldLight = Color(0xFFE6C280) // Button Gradient Top
val MetallicGoldDark = Color(0xFFB88E28) // Button Gradient Bottom

// Status & Badge Accents (No green / No purple)
val BadgeBronze = Color(0xFFCD7F32)
val BadgeSilver = Color(0xFFC0C0C0)
val BadgeGold = Color(0xFFD4AF37)
val BadgePlatinum = Color(0xFFE5E4E2)
val BadgeDiamond = Color(0xFF70D6FF)
val BadgeRuby = Color(0xFFFF4D6D)
val BadgeElite = Color(0xFFFF9E00)
val BadgeMasterLegend = Color(0xFFFFD700)

val ErrorRed = Color(0xFFFF334B)
val WarningAmber = Color(0xFFFFB703)
val FactBlue = Color(0xFF3A86FF)
val InterpretationGold = Color(0xFFE0A96D)
val BeliefOrange = Color(0xFFFB8500)

