package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateElevated
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateMuted
import com.example.ui.theme.WarningAmber

@Composable
fun SafetyBannerModal(
  isOpen: Boolean,
  onDismiss: () -> Unit
) {
  if (!isOpen) return

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = DarkSlateElevated,
      border = androidx.compose.foundation.BorderStroke(1.5.dp, ErrorRed),
      modifier = Modifier
        .fillMaxWidth()
        .testTag("safety_violation_modal")
    ) {
      Column(
        modifier = Modifier.padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        Box(
          modifier = Modifier
            .size(54.dp)
            .clip(CircleShape)
            .background(ErrorRed.copy(alpha = 0.15f))
            .border(1.dp, ErrorRed, CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Security,
            contentDescription = "Safety Alert",
            tint = ErrorRed,
            modifier = Modifier.size(30.dp)
          )
        }

        Text(
          text = "Cyber Safety Violation Detected",
          style = MaterialTheme.typography.headlineMedium,
          color = ErrorRed,
          fontWeight = FontWeight.Black,
          fontSize = 17.sp
        )

        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(ObsidianBlack)
            .border(1.dp, DarkSlateBorder, RoundedCornerShape(10.dp))
            .padding(12.dp)
        ) {
          Text(
            text = "Repeat offenses involving explicit, abusive, or harmful content may lead to account suspension and reporting to cyber authorities.",
            style = MaterialTheme.typography.bodyMedium,
            color = PureWhite,
            fontWeight = FontWeight.Medium,
            fontSize = 13.sp,
            lineHeight = 19.sp
          )
        }

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Warning,
            contentDescription = null,
            tint = WarningAmber,
            modifier = Modifier.size(16.dp)
          )
          Text(
            text = "Zero-tolerance policy enforced on PAIOS",
            fontSize = 11.sp,
            color = SlateMuted,
            fontWeight = FontWeight.SemiBold
          )
        }

        Button(
          onClick = onDismiss,
          colors = ButtonDefaults.buttonColors(
            containerColor = ErrorRed,
            contentColor = PureWhite
          ),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(44.dp)
            .testTag("safety_modal_acknowledge_button")
        ) {
          Text(
            text = "I Understand & Comply",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
          )
        }
      }
    }
  }
}
