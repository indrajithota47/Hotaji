package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CrisisAlert
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.arcade.ArcadeMathEngine
import com.example.data.arcade.ArcadeTriviaBank
import com.example.data.arcade.MathGradeLevel
import com.example.data.arcade.MathQuestion
import com.example.data.arcade.TriviaCategory
import com.example.data.arcade.TriviaQuestion
import com.example.data.local.UserProfileEntity
import com.example.data.repository.HotajiRepository
import com.example.data.voice.VoiceEngine
import com.example.ui.components.GlassmorphicCard
import com.example.ui.theme.AestheticGold
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateElevated
import com.example.ui.theme.DarkSlateGlass
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MetallicGoldLight
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OceanBlue
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateMuted
import com.example.ui.theme.SoftAqua
import com.example.ui.theme.WarningAmber
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Random

enum class ArcadeGameType(val id: String, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
  SHOOTER("shooter", "Letter & Number Shooter", Icons.Default.CrisisAlert),
  TYPING("typing", "Speed Typing Test", Icons.Default.Keyboard),
  MATH("math", "Rapid Math & Equations", Icons.Default.Calculate),
  TRIVIA("trivia", "Funny Odia & Science Trivia", Icons.Default.Psychology)
}

data class TargetEntity(
  val id: Int,
  val text: String,
  val pronunciationEn: String,
  val pronunciationOr: String,
  var posX: Float,
  var posY: Float,
  val isNumber: Boolean = false
)

@Composable
fun ArcadeHubScreen(
  repository: HotajiRepository,
  voiceEngine: VoiceEngine,
  profile: UserProfileEntity,
  modifier: Modifier = Modifier
) {
  var selectedGame by remember { mutableStateOf(ArcadeGameType.SHOOTER) }
  var audioLangOdia by remember { mutableStateOf(profile.arcadeVoiceLanguage == "Odia") }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(ObsidianBlack)
      .padding(horizontal = 16.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Spacer(modifier = Modifier.height(6.dp))

      // Header with Audio Language Toggle
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "Offline Arcade Hub",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Black,
            color = PureWhite
          )
          Text(
            text = "<5 MB Footprint • 100% Offline Playable",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = AestheticGold
          )
        }

        // Language Audio Toggle (Odia vs English)
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(DarkSlateElevated)
            .border(1.dp, AestheticGold, RoundedCornerShape(16.dp))
            .clickable {
              audioLangOdia = !audioLangOdia
              voiceEngine.playSuccessSound()
              voiceEngine.speak(if (audioLangOdia) "ଓଡ଼ିଆ ଧ୍ୱନି ସକ୍ରିୟ" else "English audio active", if (audioLangOdia) "or" else "en")
            }
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .testTag("arcade_lang_toggle")
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Icon(imageVector = Icons.Default.VolumeUp, contentDescription = null, tint = AestheticGold, modifier = Modifier.size(14.dp))
            Text(
              text = if (audioLangOdia) "Audio: ଓଡ଼ିଆ" else "Audio: English",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = PureWhite
            )
          }
        }
      }

      // Game Tabs
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        ArcadeGameType.values().forEach { game ->
          val isSel = game == selectedGame
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .background(if (isSel) DarkSlateElevated else DarkSlateGlass)
              .border(1.dp, if (isSel) AestheticGold else DarkSlateBorder, RoundedCornerShape(10.dp))
              .clickable {
                selectedGame = game
                voiceEngine.playSuccessSound()
              }
              .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
              Icon(
                imageVector = game.icon,
                contentDescription = game.title,
                tint = if (isSel) AestheticGold else SoftAqua,
                modifier = Modifier.size(18.dp)
              )
              Text(
                text = game.title.split(" ").first(),
                fontSize = 10.sp,
                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                color = if (isSel) PureWhite else SlateMuted
              )
            }
          }
        }
      }

      // Active Game Canvas
      when (selectedGame) {
        ArcadeGameType.SHOOTER -> LetterShooterGame(voiceEngine, repository, audioLangOdia)
        ArcadeGameType.TYPING -> SpeedTypingGame(voiceEngine, repository, audioLangOdia)
        ArcadeGameType.MATH -> RapidMathGame(voiceEngine, repository, audioLangOdia)
        ArcadeGameType.TRIVIA -> FunnyTriviaGame(voiceEngine, repository, audioLangOdia)
      }

      Spacer(modifier = Modifier.height(20.dp))
    }
  }
}

// ----------------------------------------------------
// GAME 1: Letter & Number Shooter (Instant Laser SFX + Vocal Pronunciation)
// ----------------------------------------------------
@Composable
private fun LetterShooterGame(
  voiceEngine: VoiceEngine,
  repository: HotajiRepository,
  isOdiaAudio: Boolean
) {
  val coroutineScope = rememberCoroutineScope()
  var score by remember { mutableIntStateOf(0) }
  var streak by remember { mutableIntStateOf(0) }
  var isPlaying by remember { mutableStateOf(false) }
  var timeLeft by remember { mutableIntStateOf(30) }

  val targets = remember { mutableStateListOf<TargetEntity>() }
  val random = remember { Random() }

  val targetBank = listOf(
    TargetEntity(1, "A", "Letter A", "ଅ", 50f, 60f),
    TargetEntity(2, "B", "Letter B", "ବ", 180f, 100f),
    TargetEntity(3, "7", "Number Seven", "ସାତ", 90f, 160f, true),
    TargetEntity(4, "K", "Letter K", "କ", 220f, 40f),
    TargetEntity(5, "100", "One Hundred", "ଏକ ଶହ", 40f, 210f, true),
    TargetEntity(6, "Z", "Letter Z", "ଜେଡ୍", 160f, 190f),
    TargetEntity(7, "50000", "Fifty Thousand", "ପଚାଶ ହଜାର", 200f, 240f, true),
    TargetEntity(8, "M", "Letter M", "ମ", 110f, 80f),
    TargetEntity(9, "9", "Number Nine", "ନଅ", 70f, 130f, true),
    TargetEntity(10, "12000", "Twelve Thousand", "ବାର ହଜାର", 140f, 220f, true)
  )

  fun spawnTargets() {
    targets.clear()
    val shuffled = targetBank.shuffled(random).take(5)
    targets.addAll(shuffled)
  }

  LaunchedEffect(isPlaying) {
    if (isPlaying) {
      timeLeft = 30
      score = 0
      streak = 0
      spawnTargets()
      while (timeLeft > 0 && isPlaying) {
        delay(1000)
        timeLeft -= 1
      }
      if (isPlaying) {
        isPlaying = false
        repository.recordGameScore("SHOOTER", score, 100, "Standard")
        voiceEngine.speak(if (isOdiaAudio) "ଖେଳ ସମାପ୍ତ! ଆପଣଙ୍କ ସ୍କୋର: $score" else "Game finished! Your score is $score", if (isOdiaAudio) "or" else "en")
      }
    }
  }

  GlassmorphicCard(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("letter_shooter_card"),
    backgroundColor = DarkSlateElevated,
    borderColor = AestheticGold.copy(alpha = 0.5f),
    highlightGold = true
  ) {
    Column(
      modifier = Modifier.padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = "Letter & Number Defender", fontWeight = FontWeight.Bold, color = PureWhite, fontSize = 14.sp)
          Text(text = "Tap floating glyphs to shoot & vocalize", fontSize = 11.sp, color = SlateMuted)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          Text(text = "Score: $score", fontWeight = FontWeight.Black, color = AestheticGold, fontSize = 14.sp)
          Text(text = "Time: ${timeLeft}s", fontWeight = FontWeight.Bold, color = if (timeLeft < 10) ErrorRed else SoftAqua, fontSize = 14.sp)
        }
      }

      // Play Arena
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(280.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(ObsidianBlack)
          .border(1.dp, DarkSlateBorder, RoundedCornerShape(12.dp))
      ) {
        if (!isPlaying) {
          Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
          ) {
            Icon(imageVector = Icons.Default.CrisisAlert, contentDescription = null, tint = AestheticGold, modifier = Modifier.size(44.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "Alphabet & Digit Shooter", fontWeight = FontWeight.Bold, color = PureWhite, fontSize = 15.sp)
            Text(text = "Instant Laser SFX + Native Odia & English Speech", fontSize = 11.sp, color = SlateMuted)
            Spacer(modifier = Modifier.height(14.dp))
            Button(
              onClick = { isPlaying = true },
              colors = ButtonDefaults.buttonColors(containerColor = AestheticGold, contentColor = ObsidianBlack),
              shape = RoundedCornerShape(20.dp),
              modifier = Modifier.testTag("start_shooter_button")
            ) {
              Text(text = "Start Shooting", fontWeight = FontWeight.Black)
            }
          }
        } else {
          // Render floating targets
          targets.forEach { target ->
            Box(
              modifier = Modifier
                .offset { IntOffset(target.posX.toInt().dp.roundToPx(), target.posY.toInt().dp.roundToPx()) }
                .size(if (target.text.length > 2) 58.dp else 46.dp)
                .clip(CircleShape)
                .background(if (target.isNumber) OceanBlue.copy(alpha = 0.8f) else AestheticGold.copy(alpha = 0.85f))
                .border(1.5.dp, PureWhite, CircleShape)
                .clickable {
                  // Instant laser sound synthesis
                  voiceEngine.playLaserSound()
                  // Instant pronunciation
                  val pronounceText = if (isOdiaAudio) target.pronunciationOr else target.pronunciationEn
                  voiceEngine.speak(pronounceText, if (isOdiaAudio) "or" else "en")

                  score += if (target.isNumber) 20 else 10
                  streak += 1

                  // Remove target and spawn new one
                  targets.remove(target)
                  val next = targetBank.filterNot { it.id == target.id }.random()
                  targets.add(next.copy(posX = random.nextInt(220).toFloat(), posY = random.nextInt(210).toFloat()))
                }
                .testTag("target_glyph_${target.text}"),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = target.text,
                fontSize = if (target.text.length > 3) 11.sp else 16.sp,
                fontWeight = FontWeight.Black,
                color = ObsidianBlack
              )
            }
          }
        }
      }
    }
  }
}

// ----------------------------------------------------
// GAME 2: Speed Typing & Text Reaction Test
// ----------------------------------------------------
@Composable
private fun SpeedTypingGame(
  voiceEngine: VoiceEngine,
  repository: HotajiRepository,
  isOdiaAudio: Boolean
) {
  val coroutineScope = rememberCoroutineScope()
  var inputWord by remember { mutableStateOf("") }
  var currentWordIndex by remember { mutableIntStateOf(0) }
  var score by remember { mutableIntStateOf(0) }
  var isPlaying by remember { mutableStateOf(false) }
  var timeLeft by remember { mutableIntStateOf(30) }

  val wordsList = listOf(
    "ନମସ୍କାର", "ଜୟ ଜଗନ୍ନାଥ", "କଳାହାଣ୍ଡି", "କୋଣାର୍କ", "ଓଡ଼ିଶା",
    "Hotaji", "PAIOS", "Algorithm", "Architecture", "Sovereign",
    "ମଧୁସୂଦନ", "ବର୍ଣ୍ଣବୋଧ", "Intelligence", "Quantum", "Odisha"
  )

  val currentTargetWord = wordsList[currentWordIndex % wordsList.size]

  LaunchedEffect(isPlaying) {
    if (isPlaying) {
      timeLeft = 30
      score = 0
      while (timeLeft > 0 && isPlaying) {
        delay(1000)
        timeLeft -= 1
      }
      if (isPlaying) {
        isPlaying = false
        repository.recordGameScore("TYPING", score, 100, "Standard")
        voiceEngine.playSuccessSound()
      }
    }
  }

  GlassmorphicCard(
    modifier = Modifier.fillMaxWidth().testTag("speed_typing_card"),
    backgroundColor = DarkSlateElevated
  ) {
    Column(
      modifier = Modifier.padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = "Speed Typing & Reaction Test", fontWeight = FontWeight.Bold, color = PureWhite, fontSize = 14.sp)
          Text(text = "Type regional Odia terms and tech keywords", fontSize = 11.sp, color = SlateMuted)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(text = "Score: $score", fontWeight = FontWeight.Black, color = AestheticGold, fontSize = 14.sp)
          Text(text = "Time: ${timeLeft}s", fontWeight = FontWeight.Bold, color = SoftAqua, fontSize = 14.sp)
        }
      }

      if (!isPlaying) {
        Button(
          onClick = { isPlaying = true; inputWord = "" },
          colors = ButtonDefaults.buttonColors(containerColor = AestheticGold, contentColor = ObsidianBlack),
          shape = RoundedCornerShape(20.dp),
          modifier = Modifier.fillMaxWidth().testTag("start_typing_button")
        ) {
          Text(text = "Start Speed Typing Challenge", fontWeight = FontWeight.Bold)
        }
      } else {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(ObsidianBlack)
            .border(1.dp, AestheticGold, RoundedCornerShape(10.dp))
            .padding(16.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = currentTargetWord,
            fontSize = 22.sp,
            fontWeight = FontWeight.Black,
            color = PureWhite
          )
        }

        OutlinedTextField(
          value = inputWord,
          onValueChange = { input ->
            inputWord = input
            if (input.trim().equals(currentTargetWord.trim(), ignoreCase = true)) {
              voiceEngine.playLaserSound()
              voiceEngine.speak(currentTargetWord, if (currentTargetWord.any { it in '\u0B00'..'\u0B7F' }) "or" else "en")
              score += 25
              currentWordIndex++
              inputWord = ""
            }
          },
          placeholder = { Text("Type word exactly as shown...", color = SlateMuted) },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = AestheticGold,
            unfocusedBorderColor = DarkSlateBorder,
            focusedTextColor = PureWhite,
            unfocusedTextColor = PureWhite,
            focusedContainerColor = DarkSlateGlass,
            unfocusedContainerColor = DarkSlateGlass
          ),
          modifier = Modifier.fillMaxWidth().testTag("typing_input_field")
        )
      }
    }
  }
}

// ----------------------------------------------------
// GAME 3: Rapid Math & Equation Solver (Grade 1 to 5 + Logic Puzzles)
// ----------------------------------------------------
@Composable
private fun RapidMathGame(
  voiceEngine: VoiceEngine,
  repository: HotajiRepository,
  isOdiaAudio: Boolean
) {
  val coroutineScope = rememberCoroutineScope()
  var selectedGrade by remember { mutableStateOf(MathGradeLevel.ALL) }
  var currentQuestion by remember { mutableStateOf(ArcadeMathEngine.generateQuestion(MathGradeLevel.ALL)) }
  var score by remember { mutableIntStateOf(0) }
  var streak by remember { mutableIntStateOf(0) }
  var isPlaying by remember { mutableStateOf(false) }
  var selectedOptionIndex by remember { mutableStateOf<Int?>(null) }
  var feedbackText by remember { mutableStateOf<String?>(null) }
  var isAnswerCorrect by remember { mutableStateOf<Boolean?>(null) }

  fun nextMathProblem() {
    selectedOptionIndex = null
    feedbackText = null
    isAnswerCorrect = null
    currentQuestion = ArcadeMathEngine.generateQuestion(selectedGrade)
  }

  GlassmorphicCard(
    modifier = Modifier.fillMaxWidth().testTag("rapid_math_card"),
    backgroundColor = DarkSlateElevated
  ) {
    Column(
      modifier = Modifier.padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(imageVector = Icons.Default.Calculate, contentDescription = null, tint = AestheticGold, modifier = Modifier.size(18.dp))
            Text(text = "Rapid Math & Logic Solver", fontWeight = FontWeight.Bold, color = PureWhite, fontSize = 14.sp)
          }
          Text(text = "1000+ Dynamic Grade 1–5 & Logic Problems", fontSize = 11.sp, color = SlateMuted)
        }

        Column(horizontalAlignment = Alignment.End) {
          Text(text = "Score: $score", fontWeight = FontWeight.Black, color = AestheticGold, fontSize = 14.sp)
          if (streak > 1) {
            Text(text = "🔥 Streak: ${streak}x", fontWeight = FontWeight.Bold, color = SoftAqua, fontSize = 11.sp)
          }
        }
      }

      // Grade Level Selector Chips
      Text(text = "Select Grade Level / Difficulty:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SoftAqua)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        MathGradeLevel.values().take(3).forEach { grade ->
          val isSel = grade == selectedGrade
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(8.dp))
              .background(if (isSel) AestheticGold.copy(alpha = 0.2f) else DarkSlateGlass)
              .border(1.dp, if (isSel) AestheticGold else DarkSlateBorder, RoundedCornerShape(8.dp))
              .clickable {
                selectedGrade = grade
                if (isPlaying) nextMathProblem()
              }
              .padding(vertical = 6.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = grade.label,
              fontSize = 11.sp,
              fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
              color = if (isSel) AestheticGold else SlateMuted
            )
          }
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        MathGradeLevel.values().drop(3).forEach { grade ->
          val isSel = grade == selectedGrade
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(8.dp))
              .background(if (isSel) AestheticGold.copy(alpha = 0.2f) else DarkSlateGlass)
              .border(1.dp, if (isSel) AestheticGold else DarkSlateBorder, RoundedCornerShape(8.dp))
              .clickable {
                selectedGrade = grade
                if (isPlaying) nextMathProblem()
              }
              .padding(vertical = 6.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = grade.label,
              fontSize = 11.sp,
              fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
              color = if (isSel) AestheticGold else SlateMuted
            )
          }
        }
      }

      if (!isPlaying) {
        Button(
          onClick = {
            isPlaying = true
            score = 0
            streak = 0
            nextMathProblem()
            voiceEngine.playSuccessSound()
            voiceEngine.speak(if (isOdiaAudio) "ଗଣିତ ପରୀକ୍ଷା ଆରମ୍ଭ!" else "Math Challenge started!", if (isOdiaAudio) "or" else "en")
          },
          colors = ButtonDefaults.buttonColors(containerColor = AestheticGold, contentColor = ObsidianBlack),
          shape = RoundedCornerShape(20.dp),
          modifier = Modifier.fillMaxWidth().testTag("start_math_button")
        ) {
          Text(text = "Start Rapid Math Solver", fontWeight = FontWeight.Bold)
        }
      } else {
        // Active Question Card
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(ObsidianBlack)
            .border(1.5.dp, AestheticGold.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
            .padding(14.dp)
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(OceanBlue.copy(alpha = 0.25f))
                  .border(1.dp, SoftAqua.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(
                  text = "${currentQuestion.gradeLevel.label} • ${currentQuestion.category}",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = SoftAqua
                )
              }
            }

            Text(
              text = currentQuestion.prompt,
              fontSize = 18.sp,
              fontWeight = FontWeight.Black,
              color = PureWhite
            )
          }
        }

        // 4 Multiple Choice Options (2x2 Grid)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          for (row in 0 until 2) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              for (col in 0 until 2) {
                val optIndex = row * 2 + col
                if (optIndex < currentQuestion.options.size) {
                  val optText = currentQuestion.options[optIndex]
                  val isCorrect = optIndex == currentQuestion.correctIndex
                  val isSelected = selectedOptionIndex == optIndex

                  val btnBg = when {
                    selectedOptionIndex != null && isCorrect -> AestheticGold.copy(alpha = 0.3f)
                    selectedOptionIndex != null && isSelected && !isCorrect -> ErrorRed.copy(alpha = 0.3f)
                    else -> DarkSlateGlass
                  }

                  val btnBorder = when {
                    selectedOptionIndex != null && isCorrect -> AestheticGold
                    selectedOptionIndex != null && isSelected && !isCorrect -> ErrorRed
                    else -> DarkSlateBorder
                  }

                  Button(
                    onClick = {
                      if (selectedOptionIndex == null) {
                        selectedOptionIndex = optIndex
                        if (isCorrect) {
                          isAnswerCorrect = true
                          streak++
                          val pts = 15 + (streak * 5)
                          score += pts
                          feedbackText = "Correct! (+${pts} pts) ${currentQuestion.explanation}"
                          voiceEngine.playSuccessSound()
                          voiceEngine.speak(if (isOdiaAudio) "ଠିକ୍ ଉତ୍ତର!" else "Correct!", if (isOdiaAudio) "or" else "en")
                        } else {
                          isAnswerCorrect = false
                          streak = 0
                          feedbackText = "Not quite! ${currentQuestion.explanation}"
                          voiceEngine.playExplosionSound()
                          voiceEngine.speak(if (isOdiaAudio) "ଭୁଲ ଉତ୍ତର!" else "Incorrect", if (isOdiaAudio) "or" else "en")
                        }
                      }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = btnBg, contentColor = PureWhite),
                    border = androidx.compose.foundation.BorderStroke(1.dp, btnBorder),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                      .weight(1f)
                      .testTag("math_option_$optIndex")
                  ) {
                    Text(
                      text = optText,
                      fontWeight = FontWeight.Bold,
                      fontSize = 14.sp,
                      color = if (selectedOptionIndex != null && isCorrect) AestheticGold else PureWhite
                    )
                  }
                }
              }
            }
          }
        }

        // Explanation & Feedback Box
        feedbackText?.let { fb ->
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(if (isAnswerCorrect == true) AestheticGold.copy(alpha = 0.15f) else ErrorRed.copy(alpha = 0.15f))
              .border(1.dp, if (isAnswerCorrect == true) AestheticGold else ErrorRed, RoundedCornerShape(8.dp))
              .padding(10.dp)
          ) {
            Text(
              text = fb,
              color = if (isAnswerCorrect == true) AestheticGold else ErrorRed,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
          ) {
            Button(
              onClick = { nextMathProblem() },
              colors = ButtonDefaults.buttonColors(containerColor = DarkSlateElevated, contentColor = SoftAqua),
              border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
              shape = RoundedCornerShape(16.dp),
              modifier = Modifier.testTag("next_math_button")
            ) {
              Text(text = "Next Equation →", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }
}

// ----------------------------------------------------
// GAME 4: Funny Knowledge & Trivia Arcade (1000+ Pool & Category Filter)
// ----------------------------------------------------
@Composable
private fun FunnyTriviaGame(
  voiceEngine: VoiceEngine,
  repository: HotajiRepository,
  isOdiaAudio: Boolean
) {
  val coroutineScope = rememberCoroutineScope()
  var selectedCategory by remember { mutableStateOf(TriviaCategory.ALL) }
  var currentTrivia by remember { mutableStateOf(ArcadeTriviaBank.getRandomQuestion(TriviaCategory.ALL)) }
  var score by remember { mutableIntStateOf(0) }
  var questionCount by remember { mutableIntStateOf(1) }
  var selectedAnswerIdx by remember { mutableStateOf<Int?>(null) }
  var feedback by remember { mutableStateOf<String?>(null) }
  var isAnswerCorrect by remember { mutableStateOf<Boolean?>(null) }

  fun fetchNextTrivia() {
    selectedAnswerIdx = null
    feedback = null
    isAnswerCorrect = null
    questionCount++
    currentTrivia = ArcadeTriviaBank.getRandomQuestion(selectedCategory)
  }

  GlassmorphicCard(
    modifier = Modifier.fillMaxWidth().testTag("funny_trivia_card"),
    backgroundColor = DarkSlateElevated
  ) {
    Column(
      modifier = Modifier.padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(imageVector = Icons.Default.Psychology, contentDescription = null, tint = AestheticGold, modifier = Modifier.size(18.dp))
            Text(text = "Trivia & Knowledge Arcade", fontWeight = FontWeight.Bold, color = PureWhite, fontSize = 14.sp)
          }
          Text(text = "1000+ Curated & Dynamic Knowledge Pool", fontSize = 11.sp, color = SlateMuted)
        }
        Column(horizontalAlignment = Alignment.End) {
          Text(text = "Score: $score", fontWeight = FontWeight.Black, color = AestheticGold, fontSize = 14.sp)
          Text(text = "Q #$questionCount", fontWeight = FontWeight.Bold, color = SoftAqua, fontSize = 11.sp)
        }
      }

      // Category Selector Chips
      Text(text = "Select Knowledge Category:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AestheticGold)
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          TriviaCategory.values().take(3).forEach { cat ->
            val isSel = cat == selectedCategory
            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(8.dp))
                .background(if (isSel) AestheticGold.copy(alpha = 0.2f) else DarkSlateGlass)
                .border(1.dp, if (isSel) AestheticGold else DarkSlateBorder, RoundedCornerShape(8.dp))
                .clickable {
                  selectedCategory = cat
                  fetchNextTrivia()
                }
                .padding(vertical = 6.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = cat.displayName.split(" ").first(),
                fontSize = 11.sp,
                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                color = if (isSel) AestheticGold else SlateMuted
              )
            }
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          TriviaCategory.values().drop(3).forEach { cat ->
            val isSel = cat == selectedCategory
            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(8.dp))
                .background(if (isSel) AestheticGold.copy(alpha = 0.2f) else DarkSlateGlass)
                .border(1.dp, if (isSel) AestheticGold else DarkSlateBorder, RoundedCornerShape(8.dp))
                .clickable {
                  selectedCategory = cat
                  fetchNextTrivia()
                }
                .padding(vertical = 6.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = cat.displayName.split(" ").first(),
                fontSize = 11.sp,
                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                color = if (isSel) AestheticGold else SlateMuted
              )
            }
          }
        }
      }

      // Question Container
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
          .background(ObsidianBlack)
          .border(1.5.dp, DarkSlateBorder, RoundedCornerShape(12.dp))
          .padding(14.dp)
      ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(OceanBlue.copy(alpha = 0.25f))
              .border(1.dp, SoftAqua.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              text = currentTrivia.category.displayName,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = SoftAqua
            )
          }

          Text(
            text = currentTrivia.question,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = PureWhite
          )
        }
      }

      // 4 Trivia Options
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        currentTrivia.options.forEachIndexed { idx, opt ->
          val isCorrect = idx == currentTrivia.correctIndex
          val isSelected = selectedAnswerIdx == idx

          val btnBg = when {
            selectedAnswerIdx != null && isCorrect -> AestheticGold.copy(alpha = 0.3f)
            selectedAnswerIdx != null && isSelected && !isCorrect -> ErrorRed.copy(alpha = 0.3f)
            else -> DarkSlateGlass
          }

          val btnBorder = when {
            selectedAnswerIdx != null && isCorrect -> AestheticGold
            selectedAnswerIdx != null && isSelected && !isCorrect -> ErrorRed
            else -> DarkSlateBorder
          }

          Button(
            onClick = {
              if (selectedAnswerIdx == null) {
                selectedAnswerIdx = idx
                if (isCorrect) {
                  isAnswerCorrect = true
                  score += 20
                  feedback = "Correct! [FACT] ${currentTrivia.explanation}"
                  voiceEngine.playSuccessSound()
                  voiceEngine.speak(if (isOdiaAudio) "ଠିକ୍ ଉତ୍ତର!" else "Correct answer!", if (isOdiaAudio) "or" else "en")
                } else {
                  isAnswerCorrect = false
                  feedback = "Oops! [CORRECT ANSWER]: ${currentTrivia.options[currentTrivia.correctIndex]}. ${currentTrivia.explanation}"
                  voiceEngine.playExplosionSound()
                  voiceEngine.speak(if (isOdiaAudio) "ଭୁଲ ଉତ୍ତର!" else "Oops! Incorrect.", if (isOdiaAudio) "or" else "en")
                }
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = btnBg, contentColor = PureWhite),
            border = androidx.compose.foundation.BorderStroke(1.dp, btnBorder),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth().testTag("trivia_option_$idx")
          ) {
            Text(
              text = opt,
              fontSize = 13.sp,
              fontWeight = if (selectedAnswerIdx != null && isCorrect) FontWeight.Bold else FontWeight.Medium,
              color = if (selectedAnswerIdx != null && isCorrect) AestheticGold else PureWhite,
              modifier = Modifier.fillMaxWidth()
            )
          }
        }
      }

      // Feedback & Explanation
      feedback?.let { fb ->
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (isAnswerCorrect == true) AestheticGold.copy(alpha = 0.15f) else ErrorRed.copy(alpha = 0.15f))
            .border(1.dp, if (isAnswerCorrect == true) AestheticGold else ErrorRed, RoundedCornerShape(8.dp))
            .padding(10.dp),
          verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Text(
            text = fb,
            color = if (isAnswerCorrect == true) AestheticGold else ErrorRed,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
          if (currentTrivia.odiaTranslation.isNotBlank()) {
            Text(
              text = "ଓଡ଼ିଆ ଅନୁବାଦ: ${currentTrivia.odiaTranslation}",
              fontSize = 11.sp,
              color = PureWhite
            )
          }
        }
      }

      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        Button(
          onClick = { fetchNextTrivia() },
          colors = ButtonDefaults.buttonColors(containerColor = DarkSlateElevated, contentColor = SoftAqua),
          border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.testTag("next_trivia_button")
        ) {
          Text(text = "Next Question →", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

