package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ai.AgentType
import com.example.data.ai.EpistemicParser
import com.example.data.local.UserProfileEntity
import com.example.data.repository.HotajiRepository
import com.example.data.voice.VoiceEngine
import com.example.ui.components.EpistemicResponseView
import com.example.ui.components.GlassmorphicCard
import com.example.ui.theme.AestheticGold
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateElevated
import com.example.ui.theme.DarkSlateGlass
import com.example.ui.theme.MetallicGoldLight
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OceanBlue
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateMuted
import com.example.ui.theme.SoftAqua
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AgentsHubScreen(
  repository: HotajiRepository,
  voiceEngine: VoiceEngine,
  profile: UserProfileEntity,
  onSafetyTrigger: () -> Unit,
  modifier: Modifier = Modifier
) {
  val coroutineScope = rememberCoroutineScope()
  var selectedAgent by remember { mutableStateOf(AgentType.SPIRITUAL_LIBRARY) }
  var userPrompt by remember { mutableStateOf("") }
  var isConsulting by remember { mutableStateOf(false) }
  var currentResponse by remember {
    mutableStateOf(
      "[TRADITIONAL BELIEF] ଭକ୍ତକବି ମଧୁସୂଦନ ରାଓଙ୍କ ପ୍ରଣୀତ 'ବର୍ଣ୍ଣବୋଧ' ଓଡ଼ିଆ ଭାଷାର ସର୍ବଶ୍ରେଷ୍ଠ ଶିକ୍ଷା ଗ୍ରନ୍ଥ। [FACT] 'କମଳ ଲୋଚନ ଶ୍ରୀହରି' ପ୍ରାର୍ଥନାରୁ ଏହାର ଆରମ୍ଭ ହୋଇଥାଏ।"
    )
  }
  var parsedSegments by remember { mutableStateOf(EpistemicParser.parseEpistemicTags(currentResponse)) }

  val barnabodhaVowels = listOf(
    Pair("ଅ", "A - ଅ"), Pair("ଆ", "AA - ଆ"), Pair("ଇ", "I - ହ୍ରସ୍ବ ଇ"),
    Pair("ଈ", "EE - ଦୀର୍ଘ ଈ"), Pair("ଉ", "U - ହ୍ରସ୍ବ ଉ"), Pair("ଊ", "OO - ଦୀର୍ଘ ଊ"),
    Pair("ଋ", "RU - ଋ"), Pair("ଏ", "E - ଏ"), Pair("ଐ", "AI - ଐ"),
    Pair("ଓ", "O - ଓ"), Pair("ଔ", "OU - ଔ")
  )

  val barnabodhaConsonants = listOf(
    Pair("କ", "Ka"), Pair("ଖ", "Kha"), Pair("ଗ", "Ga"), Pair("ଘ", "Gha"), Pair("ଙ", "Unga"),
    Pair("ଚ", "Cha"), Pair("ଛ", "Chha"), Pair("ଜ", "Ja"), Pair("ଝ", "Jha"), Pair("ଞ", "Nia"),
    Pair("ଟ", "Ta"), Pair("ଠ", "Tha"), Pair("ଡ", "Da"), Pair("ଢ", "Dha"), Pair("ଣ", "Na"),
    Pair("ତ", "Ta"), Pair("ଥ", "Tha"), Pair("ଦ", "Da"), Pair("ଧ", "Dha"), Pair("ନ", "Na"),
    Pair("ପ", "Pa"), Pair("ଫ", "Pha"), Pair("ବ", "Ba"), Pair("ଭ", "Bha"), Pair("ମ", "Ma"),
    Pair("ଯ", "Ja"), Pair("ର", "Ra"), Pair("ଳ", "La"), Pair("ଶ", "Tala-Bya Sha"),
    Pair("ଷ", "Murdhanya Sha"), Pair("ସ", "Dantya Sa"), Pair("ହ", "Ha"), Pair("କ୍ଷ", "Kshya")
  )

  fun submitQuery(query: String) {
    if (query.isBlank()) return
    if (EpistemicParser.checkSafetyViolation(query)) {
      onSafetyTrigger()
      return
    }

    isConsulting = true
    coroutineScope.launch {
      val res = repository.getAiResponse(
        agent = selectedAgent,
        query = query,
        languageName = profile.selectedLanguage
      )
      currentResponse = res
      parsedSegments = EpistemicParser.parseEpistemicTags(res)
      isConsulting = false

      val langCode = if (profile.selectedLanguage.contains("Odia")) "or" else "en"
      val speech = res.replace(Regex("""\[.*?\]"""), "").trim()
      voiceEngine.speak(speech, langCode)
    }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(ObsidianBlack)
      .padding(horizontal = 16.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Spacer(modifier = Modifier.height(6.dp))

      // Header
      Column {
        Text(
          text = "Specialized AI Agent Hub",
          style = MaterialTheme.typography.headlineLarge,
          fontWeight = FontWeight.Black,
          color = PureWhite
        )
        Text(
          text = "7 Autonomous Agents • Universal Scriptures & Odia Barnabodha",
          fontSize = 11.sp,
          fontWeight = FontWeight.SemiBold,
          color = AestheticGold
        )
      }

      // Horizontal Agent Selector Row
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(horizontal = 2.dp)
      ) {
        items(AgentType.values()) { agent ->
          val isSelected = agent == selectedAgent
          val icon = getAgentIcon(agent)

          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(12.dp))
              .background(if (isSelected) DarkSlateElevated else DarkSlateGlass)
              .border(1.dp, if (isSelected) AestheticGold else DarkSlateBorder, RoundedCornerShape(12.dp))
              .clickable {
                selectedAgent = agent
                voiceEngine.playSuccessSound()
                submitQuery("Introduce yourself and your scope in ${profile.selectedLanguage}.")
              }
              .padding(horizontal = 12.dp, vertical = 10.dp)
              .testTag("agent_tab_${agent.id}")
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Icon(
                imageVector = icon,
                contentDescription = agent.displayName,
                tint = if (isSelected) AestheticGold else SoftAqua,
                modifier = Modifier.size(18.dp)
              )
              Column {
                Text(
                  text = agent.displayName,
                  fontSize = 12.sp,
                  fontWeight = if (isSelected) FontWeight.Black else FontWeight.SemiBold,
                  color = if (isSelected) PureWhite else OffWhite()
                )
                Text(
                  text = agent.tag,
                  fontSize = 9.sp,
                  color = if (isSelected) SoftAqua else SlateMuted
                )
              }
            }
          }
        }
      }

      // Selected Agent Profile Card
      GlassmorphicCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = DarkSlateElevated,
        borderColor = AestheticGold.copy(alpha = 0.4f),
        highlightGold = true
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Box(
            modifier = Modifier
              .size(44.dp)
              .clip(CircleShape)
              .background(AestheticGold.copy(alpha = 0.2f))
              .border(1.dp, AestheticGold, CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = getAgentIcon(selectedAgent),
              contentDescription = null,
              tint = AestheticGold,
              modifier = Modifier.size(24.dp)
            )
          }
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = selectedAgent.displayName,
              style = MaterialTheme.typography.titleMedium,
              color = PureWhite
            )
            Text(
              text = selectedAgent.description,
              style = MaterialTheme.typography.bodyMedium,
              fontSize = 12.sp,
              color = SlateMuted
            )
          }
        }
      }

      // Odia Barnabodha (ବର୍ଣ୍ଣବୋଧ) Interactive Phonetic Matrix (When in Spiritual or Academic agent)
      if (selectedAgent == AgentType.SPIRITUAL_LIBRARY || selectedAgent == AgentType.ACADEMIC) {
        GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
          Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.AutoStories,
                  contentDescription = null,
                  tint = AestheticGold,
                  modifier = Modifier.size(18.dp)
                )
                Text(
                  text = "ଓଡ଼ିଆ ବର୍ଣ୍ଣବୋଧ (Odia Barnabodha Phonetic Hub)",
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  color = PureWhite
                )
              }
              Text(
                text = "Tap to Pronounce",
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                color = SoftAqua
              )
            }

            Text(
              text = "ସ୍ୱରବର୍ଣ୍ଣ (Vowels):",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = AestheticGold
            )

            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              barnabodhaVowels.forEach { (char, label) ->
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkSlateElevated)
                    .border(1.dp, DarkSlateBorder, RoundedCornerShape(8.dp))
                    .clickable {
                      voiceEngine.playSuccessSound()
                      voiceEngine.speak(char, "or")
                    }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                  Text(
                    text = char,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    color = PureWhite
                  )
                }
              }
            }

            Text(
              text = "ବ୍ୟଞ୍ଜନବର୍ଣ୍ଣ (Consonants):",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = SoftAqua
            )

            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              barnabodhaConsonants.take(15).forEach { (char, label) ->
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkSlateGlass)
                    .border(1.dp, DarkSlateBorder, RoundedCornerShape(8.dp))
                    .clickable {
                      voiceEngine.playSuccessSound()
                      voiceEngine.speak(char, "or")
                    }
                    .padding(horizontal = 9.dp, vertical = 6.dp)
                ) {
                  Text(
                    text = char,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MetallicGoldLight
                  )
                }
              }
            }
          }
        }
      }

      // Epistemic Output View
      GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
        Column(
          modifier = Modifier.padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Agent Output (${selectedAgent.displayName})",
              style = MaterialTheme.typography.titleMedium,
              fontSize = 13.sp,
              color = PureWhite
            )
            IconButton(
              onClick = {
                val clean = currentResponse.replace(Regex("""\[.*?\]"""), "").trim()
                val lang = if (profile.selectedLanguage.contains("Odia")) "or" else "en"
                voiceEngine.speak(clean, lang)
              },
              modifier = Modifier.size(28.dp)
            ) {
              Icon(
                imageVector = Icons.Default.VolumeUp,
                contentDescription = "Read aloud",
                tint = AestheticGold,
                modifier = Modifier.size(18.dp)
              )
            }
          }

          EpistemicResponseView(segments = parsedSegments)
        }
      }

      // Query Input Box
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        OutlinedTextField(
          value = userPrompt,
          onValueChange = { userPrompt = it },
          placeholder = {
            Text("Ask ${selectedAgent.displayName}...", color = SlateMuted, fontSize = 13.sp)
          },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = AestheticGold,
            unfocusedBorderColor = DarkSlateBorder,
            focusedTextColor = PureWhite,
            unfocusedTextColor = PureWhite,
            focusedContainerColor = DarkSlateGlass,
            unfocusedContainerColor = DarkSlateGlass
          ),
          shape = RoundedCornerShape(24.dp),
          modifier = Modifier
            .weight(1f)
            .testTag("agent_prompt_input")
        )

        IconButton(
          onClick = {
            if (userPrompt.isNotBlank()) {
              val p = userPrompt
              userPrompt = ""
              submitQuery(p)
            }
          },
          modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(AestheticGold)
            .testTag("submit_agent_prompt_button")
        ) {
          Icon(
            imageVector = Icons.Default.Send,
            contentDescription = "Submit Prompt",
            tint = ObsidianBlack,
            modifier = Modifier.size(20.dp)
          )
        }
      }
    }
  }
}

private fun getAgentIcon(agent: AgentType): ImageVector {
  return when (agent) {
    AgentType.PERSONAL_LIFE -> Icons.Default.Person
    AgentType.ACADEMIC -> Icons.Default.School
    AgentType.FINANCE -> Icons.Default.MonetizationOn
    AgentType.CAREER_WRITING -> Icons.Default.Create
    AgentType.CODE_ARCHITECT -> Icons.Default.Code
    AgentType.LIFESTYLE -> Icons.Default.FitnessCenter
    AgentType.SPIRITUAL_LIBRARY -> Icons.Default.AutoStories
  }
}

private fun OffWhite(): Color = PureWhite.copy(alpha = 0.85f)
