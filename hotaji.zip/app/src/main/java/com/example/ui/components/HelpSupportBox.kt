package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.HelpCenter
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AestheticGold
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateElevated
import com.example.ui.theme.DarkSlateGlass
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OceanBlue
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateMuted
import com.example.ui.theme.SoftAqua

@Composable
fun HelpSupportBox(
  modifier: Modifier = Modifier,
  onDismiss: () -> Unit = {}
) {
  var expandedTip by remember { mutableStateOf<String?>(null) }

  GlassmorphicCard(
    modifier = modifier
      .fillMaxWidth()
      .testTag("help_support_box"),
    backgroundColor = DarkSlateElevated,
    borderColor = AestheticGold.copy(alpha = 0.5f),
    highlightGold = true
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(
            modifier = Modifier
              .size(32.dp)
              .clip(CircleShape)
              .background(AestheticGold.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.HelpCenter,
              contentDescription = "Help Icon",
              tint = AestheticGold,
              modifier = Modifier.size(18.dp)
            )
          }
          Column {
            Text(
              text = "Hotaji PAIOS Support Assistant",
              style = MaterialTheme.typography.titleMedium,
              color = PureWhite
            )
            Text(
              text = "Real-time navigation & voice guidance",
              style = MaterialTheme.typography.labelSmall,
              color = SoftAqua
            )
          }
        }
        IconButton(
          onClick = onDismiss,
          modifier = Modifier.size(28.dp).testTag("close_help_button")
        ) {
          Icon(
            imageVector = Icons.Default.Close,
            contentDescription = "Close Help",
            tint = SlateMuted,
            modifier = Modifier.size(16.dp)
          )
        }
      }

      Text(
        text = "Quick Guidance Topics:",
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        color = AestheticGold
      )

      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        HelpTopicRow(
          icon = Icons.Default.Mic,
          title = "Voice OS & 9 Regional Avatars",
          detail = "Tap the Central Voice Orb or pill CTA to activate live voice. Swipe avatar chips to switch between Arjun, Jeet, Gita, Priya, and Dual-Tone.",
          isExpanded = expandedTip == "voice",
          onClick = { expandedTip = if (expandedTip == "voice") null else "voice" }
        )
        HelpTopicRow(
          icon = Icons.Default.SportsEsports,
          title = "Offline Low-MB Arcade Hub (<5 MB)",
          detail = "When internet is disconnected, Hotaji automatically pauses online queries and launches 4 offline games: Letter/Number Shooter, Speed Typing, Math, and Odia Trivia with audio pronunciation.",
          isExpanded = expandedTip == "arcade",
          onClick = { expandedTip = if (expandedTip == "arcade") null else "arcade" }
        )
        HelpTopicRow(
          icon = Icons.Default.Translate,
          title = "Odia First & 15+ Regional Languages",
          detail = "Odia (ମୁଖ୍ୟ ଫୋକସ୍) is fully native alongside Hindi, English, Santhali (Ol Chiki), Ho, Sanskrit, and 10+ Indian regional languages with dialect tuning.",
          isExpanded = expandedTip == "lang",
          onClick = { expandedTip = if (expandedTip == "lang") null else "lang" }
        )
        HelpTopicRow(
          icon = Icons.Default.VpnKey,
          title = "End-to-End Privacy & Memory Controls",
          detail = "Say 'Remember this: [fact]' or 'Forget this' anytime. Manage all active AI memories from the Privacy tab.",
          isExpanded = expandedTip == "privacy",
          onClick = { expandedTip = if (expandedTip == "privacy") null else "privacy" }
        )
      }
    }
  }
}

@Composable
private fun HelpTopicRow(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  title: String,
  detail: String,
  isExpanded: Boolean,
  onClick: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(8.dp))
      .background(DarkSlateGlass)
      .border(1.dp, if (isExpanded) AestheticGold.copy(alpha = 0.6f) else DarkSlateBorder, RoundedCornerShape(8.dp))
      .clickable { onClick() }
      .padding(10.dp)
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Icon(imageVector = icon, contentDescription = null, tint = SoftAqua, modifier = Modifier.size(16.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontSize = 13.sp,
        color = PureWhite
      )
    }
    if (isExpanded) {
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = detail,
        style = MaterialTheme.typography.bodyMedium,
        fontSize = 12.sp,
        color = SlateMuted
      )
    }
  }
}
