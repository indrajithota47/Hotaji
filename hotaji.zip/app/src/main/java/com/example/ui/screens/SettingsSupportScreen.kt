package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.UserProfileEntity
import com.example.data.repository.HotajiRepository
import com.example.data.voice.VoiceAvatar
import com.example.data.voice.VoiceEngine
import com.example.ui.components.GlassmorphicCard
import com.example.ui.theme.AestheticGold
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateElevated
import com.example.ui.theme.DarkSlateGlass
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MetallicGoldLight
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OceanBlue
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateMuted
import com.example.ui.theme.SoftAqua
import kotlinx.coroutines.launch

@Composable
fun SettingsSupportScreen(
  repository: HotajiRepository,
  voiceEngine: VoiceEngine,
  profile: UserProfileEntity,
  onShowHelpDialog: () -> Unit,
  modifier: Modifier = Modifier
) {
  val coroutineScope = rememberCoroutineScope()
  val memories by repository.allMemories.collectAsState(initial = emptyList())
  val currentAvatar by voiceEngine.currentAvatar.collectAsState()

  var memoryKey by remember { mutableStateOf("") }
  var memoryVal by remember { mutableStateOf("") }

  val languagesList = listOf(
    "Odia (ଓଡ଼ିଆ - ମୁଖ୍ୟ ଫୋକସ୍)",
    "Hindi (हिन्दी)",
    "English (India / Global)",
    "Santhali (Ol Chiki - ᱥᱟᱱᱛᱟᱲᱤ)",
    "Ho (Warang Citi)",
    "Sanskrit (संस्कृतम्)",
    "Bengali (বাংলা)",
    "Marathi (मराठी)",
    "Gujarati (ગુજરાતી)",
    "Punjabi (ਪੰਜਾਬੀ)",
    "Tamil (தமிழ்)",
    "Telugu (తెలుగు)",
    "Kannada (ಕನ್ನಡ)",
    "Malayalam (മലയാളം)"
  )

  val accentsList = listOf(
    "Cuttack-Bhubaneswar Standard",
    "Sambalpuri-Western Dialect",
    "Berhampur-Southern Dialect",
    "Baleswari-Northern Dialect",
    "Standard Hindi Dialect",
    "Indian English Cadence"
  )

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(ObsidianBlack)
      .padding(horizontal = 16.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Spacer(modifier = Modifier.height(6.dp))

      Column {
        Text(
          text = "Settings & Support Hub",
          style = MaterialTheme.typography.headlineLarge,
          fontWeight = FontWeight.Black,
          color = PureWhite
        )
        Text(
          text = "Voice Personas, AI Memory, Accents & Platform Support",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = AestheticGold
        )
      }

      // Help Assistant Quick Trigger Card
      GlassmorphicCard(
        modifier = Modifier.fillMaxWidth().testTag("open_help_assistant_card"),
        backgroundColor = DarkSlateElevated,
        borderColor = AestheticGold.copy(alpha = 0.5f),
        highlightGold = true
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clickable { onShowHelpDialog() }
            .padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(AestheticGold.copy(alpha = 0.2f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(imageVector = Icons.Default.HelpOutline, contentDescription = null, tint = AestheticGold, modifier = Modifier.size(20.dp))
            }
            Column {
              Text(text = "Open In-App Assistance & Help Box", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PureWhite)
              Text(text = "Real-time navigation, arcade tips, and voice tuning", fontSize = 11.sp, color = SoftAqua)
            }
          }
        }
      }

      // Voice Avatar Tuning
      GlassmorphicCard(modifier = Modifier.fillMaxWidth().testTag("voice_avatar_settings_card")) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(imageVector = Icons.Default.RecordVoiceOver, contentDescription = null, tint = AestheticGold, modifier = Modifier.size(18.dp))
            Text(text = "Voice Avatar Tuning (9 Personas)", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = PureWhite)
          }

          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            VoiceAvatar.values().forEach { avatar ->
              val isSel = avatar == currentAvatar
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(8.dp))
                  .background(if (isSel) DarkSlateElevated else DarkSlateGlass)
                  .border(1.dp, if (isSel) AestheticGold else DarkSlateBorder, RoundedCornerShape(8.dp))
                  .clickable {
                    voiceEngine.setAvatar(avatar)
                    voiceEngine.playSuccessSound()
                    voiceEngine.speak("Avatar ${avatar.displayName} selected.", "en")
                  }
                  .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Column {
                  Text(
                    text = "${avatar.displayName} (${avatar.gender})",
                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                    fontSize = 12.sp,
                    color = if (isSel) PureWhite else OffWhite()
                  )
                  Text(text = avatar.trait, fontSize = 10.sp, color = if (isSel) SoftAqua else SlateMuted)
                }

                if (isSel) {
                  Text(text = "ACTIVE", fontSize = 10.sp, fontWeight = FontWeight.Black, color = AestheticGold)
                }
              }
            }
          }
        }
      }

      // Language & Accent Selection
      GlassmorphicCard(modifier = Modifier.fillMaxWidth().testTag("lang_accent_settings_card")) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(imageVector = Icons.Default.Translate, contentDescription = null, tint = SoftAqua, modifier = Modifier.size(18.dp))
            Text(text = "Target Language & Accent Dialect", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = PureWhite)
          }

          Text(text = "Select System Operating Language:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AestheticGold)

          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            languagesList.take(5).forEach { lang ->
              val isSel = profile.selectedLanguage.contains(lang.split(" ").first())
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(8.dp))
                  .background(if (isSel) DarkSlateElevated else DarkSlateGlass)
                  .border(1.dp, if (isSel) AestheticGold else DarkSlateBorder, RoundedCornerShape(8.dp))
                  .clickable {
                    coroutineScope.launch {
                      repository.updateUserProfile(profile.copy(selectedLanguage = lang))
                      voiceEngine.playSuccessSound()
                    }
                  }
                  .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(text = lang, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = if (isSel) PureWhite else OffWhite())
                if (isSel) Text(text = "SELECTED", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = AestheticGold)
              }
            }
          }

          Text(text = "Select Accent Modulation:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SoftAqua)

          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            accentsList.take(4).forEach { acc ->
              val isSel = profile.selectedAccent == acc
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(8.dp))
                  .background(if (isSel) DarkSlateElevated else DarkSlateGlass)
                  .border(1.dp, if (isSel) AestheticGold else DarkSlateBorder, RoundedCornerShape(8.dp))
                  .clickable {
                    coroutineScope.launch {
                      repository.updateUserProfile(profile.copy(selectedAccent = acc))
                      voiceEngine.playSuccessSound()
                    }
                  }
                  .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(text = acc, fontSize = 12.sp, color = if (isSel) PureWhite else OffWhite())
                if (isSel) Text(text = "ACTIVE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SoftAqua)
              }
            }
          }
        }
      }

      // AI Memory Management ("Remember this / Forget this")
      GlassmorphicCard(modifier = Modifier.fillMaxWidth().testTag("ai_memory_management_card")) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = AestheticGold, modifier = Modifier.size(18.dp))
              Text(text = "End-to-End AI Memory Controls", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = PureWhite)
            }
            if (memories.isNotEmpty()) {
              IconButton(
                onClick = { coroutineScope.launch { repository.clearMemories() } },
                modifier = Modifier.size(24.dp)
              ) {
                Icon(imageVector = Icons.Default.Delete, contentDescription = "Clear All Memories", tint = ErrorRed, modifier = Modifier.size(16.dp))
              }
            }
          }

          Text(
            text = "Teach Hotaji facts ('Remember this') or delete saved preferences ('Forget this').",
            fontSize = 11.sp,
            color = SlateMuted
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedTextField(
              value = memoryKey,
              onValueChange = { memoryKey = it },
              placeholder = { Text("Topic (e.g. Diet)", color = SlateMuted, fontSize = 12.sp) },
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AestheticGold,
                unfocusedBorderColor = DarkSlateBorder,
                focusedTextColor = PureWhite,
                unfocusedTextColor = PureWhite,
                focusedContainerColor = DarkSlateElevated,
                unfocusedContainerColor = DarkSlateElevated
              ),
              modifier = Modifier.weight(1f).testTag("memory_key_input")
            )
            OutlinedTextField(
              value = memoryVal,
              onValueChange = { memoryVal = it },
              placeholder = { Text("Fact (e.g. Vegetarian)", color = SlateMuted, fontSize = 12.sp) },
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AestheticGold,
                unfocusedBorderColor = DarkSlateBorder,
                focusedTextColor = PureWhite,
                unfocusedTextColor = PureWhite,
                focusedContainerColor = DarkSlateElevated,
                unfocusedContainerColor = DarkSlateElevated
              ),
              modifier = Modifier.weight(1.3f).testTag("memory_value_input")
            )
            IconButton(
              onClick = {
                if (memoryKey.isNotBlank() && memoryVal.isNotBlank()) {
                  val k = memoryKey
                  val v = memoryVal
                  memoryKey = ""
                  memoryVal = ""
                  coroutineScope.launch {
                    repository.remember(k, v)
                    voiceEngine.playSuccessSound()
                  }
                }
              },
              modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(AestheticGold)
                .testTag("save_memory_button")
            ) {
              Icon(imageVector = Icons.Default.Add, contentDescription = "Save Memory", tint = ObsidianBlack)
            }
          }

          // List of saved memories
          if (memories.isEmpty()) {
            Text(text = "No custom memories saved yet. All operations run in sovereign privacy mode.", fontSize = 11.sp, color = SlateMuted)
          } else {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
              memories.forEach { mem ->
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkSlateElevated)
                    .border(1.dp, DarkSlateBorder, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(text = "${mem.key}: ${mem.value}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = PureWhite)
                    Text(text = mem.category, fontSize = 9.sp, color = SoftAqua)
                  }
                  IconButton(
                    onClick = { coroutineScope.launch { repository.forget(mem.id) } },
                    modifier = Modifier.size(24.dp)
                  ) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Forget", tint = SlateMuted, modifier = Modifier.size(14.dp))
                  }
                }
              }
            }
          }
        }
      }

      // Official Platform Support & Contribution QR Code Widget
      GlassmorphicCard(
        modifier = Modifier.fillMaxWidth().testTag("official_support_qr_card"),
        backgroundColor = DarkSlateElevated,
        borderColor = AestheticGold.copy(alpha = 0.6f),
        highlightGold = true
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(imageVector = Icons.Default.QrCode2, contentDescription = null, tint = AestheticGold, modifier = Modifier.size(20.dp))
            Text(
              text = "Support & Contribution QR Widget",
              fontWeight = FontWeight.Black,
              fontSize = 14.sp,
              color = PureWhite
            )
          }

          Image(
            painter = painterResource(id = R.drawable.hotaji_qr_support_1788446792520),
            contentDescription = "Official Support QR Code",
            modifier = Modifier
              .size(160.dp)
              .clip(RoundedCornerShape(12.dp))
              .border(1.5.dp, AestheticGold, RoundedCornerShape(12.dp)),
            contentScale = ContentScale.Crop
          )

          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(ObsidianBlack)
              .border(1.dp, DarkSlateBorder, RoundedCornerShape(8.dp))
              .padding(8.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "Payment/donation is optional.",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = MetallicGoldLight
            )
          }
        }
      }

      // Founder & Legal Attribution
      GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
        Column(
          modifier = Modifier.padding(14.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Text(
            text = "Hotaji App (PAIOS v1.0)",
            fontWeight = FontWeight.Black,
            fontSize = 14.sp,
            color = PureWhite
          )
          Text(
            text = "Founder & Owner: Indrajit Hota",
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = AestheticGold
          )
          Text(
            text = "Origin: Made in Odisha | Made in India",
            fontWeight = FontWeight.SemiBold,
            fontSize = 11.sp,
            color = SoftAqua
          )
          Text(
            text = "Official Copyright © owned entirely by Indrajit Hota.",
            fontSize = 10.sp,
            color = SlateMuted
          )
        }
      }

      Spacer(modifier = Modifier.height(20.dp))
    }
  }
}

private fun OffWhite(): Color = PureWhite.copy(alpha = 0.85f)
