package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.AestheticGold
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateElevated
import com.example.ui.theme.DarkSlateGlass
import com.example.ui.theme.MetallicGoldLight
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OceanBlue
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateMuted
import com.example.ui.theme.SoftAqua

enum class AppDestination(
  val id: String,
  val label: String,
  val subLabel: String,
  val icon: ImageVector
) {
  VOICE_OS("voice_os", "Voice Operating System", "Live Breathing Orb & 9 Avatars", Icons.Default.Mic),
  AGENTS_HUB("agents_hub", "Specialized AI Agents", "7 Domain Agents + Barnabodha", Icons.Default.SmartToy),
  VISION_STUDIO("vision_studio", "Multi-Modal Vision", "Camera OCR & Text-to-Image", Icons.Default.DocumentScanner),
  ARCADE_HUB("arcade_hub", "Offline Arcade Hub", "4 Low-MB Games (<5 MB)", Icons.Default.SportsEsports),
  BADGE_VAULT("badge_vault", "Badge Vault Hub", "8 Progressive Tiers & Stats", Icons.Default.EmojiEvents),
  SETTINGS_SUPPORT("settings_support", "Settings & Support", "Voice Tuning, Memory & QR", Icons.Default.Settings)
}

@Composable
fun HotajiNavigationDrawerContent(
  currentDestination: AppDestination,
  onSelectDestination: (AppDestination) -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxHeight()
      .width(310.dp)
      .background(ObsidianBlack)
      .border(1.dp, DarkSlateBorder)
      .padding(horizontal = 16.dp, vertical = 20.dp)
      .verticalScroll(rememberScrollState())
      .testTag("hotaji_nav_drawer")
  ) {
    // Top Brand Header
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Box(
        modifier = Modifier
          .size(46.dp)
          .clip(CircleShape)
          .background(
            Brush.radialGradient(listOf(AestheticGold, OceanBlue, ObsidianBlack))
          )
          .border(1.5.dp, AestheticGold, CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.AutoAwesome,
          contentDescription = "Hotaji Logo",
          tint = ObsidianBlack,
          modifier = Modifier.size(24.dp)
        )
      }

      Column {
        Text(
          text = "Hotaji App",
          style = MaterialTheme.typography.headlineLarge,
          fontWeight = FontWeight.Black,
          color = PureWhite
        )
        Text(
          text = "PAIOS v1.0 • Personal AI OS",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = AestheticGold
        )
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Mandatory Founder & Origin Box
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(10.dp))
        .background(DarkSlateElevated)
        .border(1.dp, AestheticGold.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
        .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
      Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
          text = "Founder: Indrajit Hota",
          fontWeight = FontWeight.ExtraBold,
          fontSize = 13.sp,
          color = MetallicGoldLight
        )
        Text(
          text = "Origin: Made in Odisha | Made in India",
          fontWeight = FontWeight.SemiBold,
          fontSize = 11.sp,
          color = SoftAqua
        )
      }
    }

    Spacer(modifier = Modifier.height(16.dp))
    HorizontalDivider(color = DarkSlateBorder, thickness = 1.dp)
    Spacer(modifier = Modifier.height(12.dp))

    Text(
      text = "CORE SYSTEM MODULES",
      fontSize = 10.sp,
      fontWeight = FontWeight.Black,
      letterSpacing = 1.2.sp,
      color = SlateMuted
    )

    Spacer(modifier = Modifier.height(8.dp))

    // Navigation Items
    AppDestination.values().forEach { destination ->
      val isSelected = destination == currentDestination
      val bg = if (isSelected) DarkSlateElevated else Color.Transparent
      val borderCol = if (isSelected) AestheticGold else Color.Transparent

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(10.dp))
          .background(bg)
          .border(1.dp, borderCol, RoundedCornerShape(10.dp))
          .clickable { onSelectDestination(destination) }
          .padding(horizontal = 12.dp, vertical = 10.dp)
          .testTag("nav_item_${destination.id}"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Icon(
          imageVector = destination.icon,
          contentDescription = destination.label,
          tint = if (isSelected) AestheticGold else SoftAqua,
          modifier = Modifier.size(20.dp)
        )
        Column {
          Text(
            text = destination.label,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
            fontSize = 13.sp,
            color = if (isSelected) PureWhite else OffWhite(0.9f)
          )
          Text(
            text = destination.subLabel,
            fontSize = 10.sp,
            color = if (isSelected) SoftAqua else SlateMuted
          )
        }
      }
      Spacer(modifier = Modifier.height(4.dp))
    }

    Spacer(modifier = Modifier.height(14.dp))
    HorizontalDivider(color = DarkSlateBorder, thickness = 1.dp)
    Spacer(modifier = Modifier.height(12.dp))

    // Embedded QR Support Box Adjacent to Nav
    GlassmorphicCard(
      modifier = Modifier
        .fillMaxWidth()
        .testTag("nav_support_qr_card"),
      backgroundColor = DarkSlateElevated,
      borderColor = AestheticGold.copy(alpha = 0.3f),
      shape = RoundedCornerShape(12.dp)
    ) {
      Column(
        modifier = Modifier.padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Icon(
            imageVector = Icons.Default.QrCode2,
            contentDescription = null,
            tint = AestheticGold,
            modifier = Modifier.size(16.dp)
          )
          Text(
            text = "Platform Support & Contribution",
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = PureWhite
          )
        }

        Image(
          painter = painterResource(id = R.drawable.hotaji_qr_support_1788446792520),
          contentDescription = "Official Support QR Code",
          modifier = Modifier
            .size(110.dp)
            .clip(RoundedCornerShape(8.dp))
            .border(1.dp, AestheticGold.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
          contentScale = ContentScale.Crop
        )

        Text(
          text = "Payment/donation is optional.",
          fontSize = 10.sp,
          fontWeight = FontWeight.Medium,
          color = SlateMuted
        )
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Footer & Legal Credits
    Column(
      modifier = Modifier.fillMaxWidth(),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
      Text(
        text = "Official Copyright © owned entirely by Indrajit Hota.",
        fontSize = 9.sp,
        fontWeight = FontWeight.Medium,
        color = SlateMuted
      )
      Text(
        text = "100% Free • Unlimited • Ad-Free",
        fontSize = 9.sp,
        fontWeight = FontWeight.Bold,
        color = AestheticGold
      )
    }
  }
}

private fun OffWhite(alpha: Float = 1f): Color = PureWhite.copy(alpha = alpha)
