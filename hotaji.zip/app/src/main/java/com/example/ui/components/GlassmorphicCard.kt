package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AestheticGold
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateGlass

@Composable
fun GlassmorphicCard(
  modifier: Modifier = Modifier,
  shape: Shape = RoundedCornerShape(16.dp),
  backgroundColor: Color = DarkSlateGlass,
  borderColor: Color = DarkSlateBorder,
  borderWidth: Dp = 1.dp,
  highlightGold: Boolean = false,
  content: @Composable BoxScope.() -> Unit
) {
  val border = if (highlightGold) {
    BorderStroke(
      borderWidth,
      Brush.horizontalGradient(listOf(AestheticGold.copy(alpha = 0.8f), DarkSlateBorder))
    )
  } else {
    BorderStroke(borderWidth, borderColor)
  }

  Surface(
    modifier = modifier.clip(shape),
    shape = shape,
    color = backgroundColor,
    border = border
  ) {
    Box(modifier = Modifier.padding(0.dp), content = content)
  }
}
