package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ai.EpistemicSegment
import com.example.ui.theme.AestheticGold
import com.example.ui.theme.BeliefOrange
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateGlass
import com.example.ui.theme.FactBlue
import com.example.ui.theme.InterpretationGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SoftAqua
import com.example.ui.theme.WarningAmber

@Composable
fun EpistemicBadge(
  tag: String,
  modifier: Modifier = Modifier
) {
  val (bgColor, textColor, icon) = when (tag.uppercase()) {
    "FACT" -> Triple(FactBlue.copy(alpha = 0.2f), FactBlue, Icons.Default.CheckCircle)
    "INTERPRETATION" -> Triple(InterpretationGold.copy(alpha = 0.2f), InterpretationGold, Icons.Default.Psychology)
    "TRADITIONAL BELIEF" -> Triple(BeliefOrange.copy(alpha = 0.2f), BeliefOrange, Icons.Default.AutoStories)
    "OPINION" -> Triple(SoftAqua.copy(alpha = 0.2f), SoftAqua, Icons.Default.Info)
    "UNCERTAIN" -> Triple(WarningAmber.copy(alpha = 0.2f), WarningAmber, Icons.Default.HelpOutline)
    else -> Triple(AestheticGold.copy(alpha = 0.2f), AestheticGold, Icons.Default.Star)
  }

  Row(
    verticalAlignment = Alignment.CenterVertically,
    modifier = modifier
      .clip(RoundedCornerShape(6.dp))
      .background(bgColor)
      .border(1.dp, textColor.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
      .padding(horizontal = 8.dp, vertical = 3.dp)
  ) {
    Icon(
      imageVector = icon,
      contentDescription = tag,
      tint = textColor,
      modifier = Modifier.size(12.dp)
    )
    Spacer(modifier = Modifier.width(4.dp))
    Text(
      text = "[$tag]",
      color = textColor,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      letterSpacing = 0.5.sp
    )
  }
}

@Composable
fun EpistemicResponseView(
  segments: List<EpistemicSegment>,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(12.dp))
      .background(DarkSlateGlass)
      .border(1.dp, DarkSlateBorder, RoundedCornerShape(12.dp))
      .padding(14.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    segments.forEach { segment ->
      Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        if (segment.tag != "NONE") {
          EpistemicBadge(tag = segment.tag)
        }
        Text(
          text = segment.content,
          style = MaterialTheme.typography.bodyLarge,
          color = PureWhite
        )
      }
    }
  }
}
