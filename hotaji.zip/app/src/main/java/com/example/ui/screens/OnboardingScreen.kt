package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Female
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Male
import androidx.compose.material.icons.filled.Transgender
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.UserProfileEntity
import com.example.ui.components.GlassmorphicCard
import com.example.ui.theme.AestheticGold
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateElevated
import com.example.ui.theme.DarkSlateGlass
import com.example.ui.theme.MetallicGoldDark
import com.example.ui.theme.MetallicGoldLight
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OceanBlue
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateMuted
import com.example.ui.theme.SoftAqua

@Composable
fun OnboardingScreen(
  onCompleteOnboarding: (UserProfileEntity) -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedGender by remember { mutableStateOf("Male") }
  var fullName by remember { mutableStateOf("Indrajit Hota") }
  var email by remember { mutableStateOf("indrajithota5@gmail.com") }
  var encryptionEnabled by remember { mutableStateOf(true) }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(ObsidianBlack)
      .padding(20.dp),
    contentAlignment = Alignment.Center
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .verticalScroll(rememberScrollState()),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Top Glowing Emblem
      Box(
        modifier = Modifier
          .size(64.dp)
          .clip(CircleShape)
          .background(
            Brush.radialGradient(listOf(AestheticGold, OceanBlue, ObsidianBlack))
          )
          .border(2.dp, AestheticGold, CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.AutoAwesome,
          contentDescription = null,
          tint = ObsidianBlack,
          modifier = Modifier.size(32.dp)
        )
      }

      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
          text = "Hotaji App",
          style = MaterialTheme.typography.displayMedium,
          fontWeight = FontWeight.Black,
          color = PureWhite
        )
        Text(
          text = "Personal AI Operating System (PAIOS v1.0)",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = AestheticGold
        )
        Text(
          text = "Founder: Indrajit Hota • Made in Odisha | Made in India",
          style = MaterialTheme.typography.labelMedium,
          color = SoftAqua
        )
      }

      // Zero-Friction Feature Callout Card
      GlassmorphicCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = DarkSlateElevated,
        borderColor = AestheticGold.copy(alpha = 0.4f),
        highlightGold = true
      ) {
        Column(
          modifier = Modifier.padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Text(
            text = "Zero-Friction Sovereign Access",
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            color = MetallicGoldLight
          )
          Text(
            text = "100% Free • Unlimited • Ad-Free • No OTPs or Payment Walls",
            fontWeight = FontWeight.SemiBold,
            fontSize = 11.sp,
            color = PureWhite
          )
        }
      }

      // Gender Selection (Mandatory Step)
      GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Text(
            text = "Step 1: Gender Selection",
            style = MaterialTheme.typography.titleMedium,
            color = PureWhite
          )
          Text(
            text = "Used to calibrate vocal frequency ranges and personalized avatar responses.",
            style = MaterialTheme.typography.bodyMedium,
            color = SlateMuted
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            GenderOptionButton(
              title = "Male",
              icon = Icons.Default.Male,
              isSelected = selectedGender == "Male",
              modifier = Modifier.weight(1f),
              onClick = { selectedGender = "Male" }
            )
            GenderOptionButton(
              title = "Female",
              icon = Icons.Default.Female,
              isSelected = selectedGender == "Female",
              modifier = Modifier.weight(1f),
              onClick = { selectedGender = "Female" }
            )
            GenderOptionButton(
              title = "Non-Binary",
              icon = Icons.Default.Transgender,
              isSelected = selectedGender == "Non-Binary",
              modifier = Modifier.weight(1f),
              onClick = { selectedGender = "Non-Binary" }
            )
          }
        }
      }

      // 1-Click Google SSO / Gmail Account
      GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Text(
            text = "Step 2: 1-Click Google SSO (Gmail OAuth)",
            style = MaterialTheme.typography.titleMedium,
            color = PureWhite
          )

          OutlinedTextField(
            value = fullName,
            onValueChange = { fullName = it },
            label = { Text("User Profile Name", color = SlateMuted) },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AestheticGold,
              unfocusedBorderColor = DarkSlateBorder,
              focusedTextColor = PureWhite,
              unfocusedTextColor = PureWhite,
              focusedContainerColor = ObsidianBlack,
              unfocusedContainerColor = ObsidianBlack
            ),
            modifier = Modifier.fillMaxWidth().testTag("onboarding_name_input")
          )

          OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Google Account (Gmail)", color = SlateMuted) },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = AestheticGold,
              unfocusedBorderColor = DarkSlateBorder,
              focusedTextColor = PureWhite,
              unfocusedTextColor = PureWhite,
              focusedContainerColor = ObsidianBlack,
              unfocusedContainerColor = ObsidianBlack
            ),
            modifier = Modifier.fillMaxWidth().testTag("onboarding_email_input")
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = SoftAqua, modifier = Modifier.size(16.dp))
              Text(
                text = "End-to-End Encryption & AI Memory",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = PureWhite
              )
            }
            Switch(
              checked = encryptionEnabled,
              onCheckedChange = { encryptionEnabled = it },
              colors = SwitchDefaults.colors(
                checkedThumbColor = ObsidianBlack,
                checkedTrackColor = AestheticGold,
                uncheckedThumbColor = SlateMuted,
                uncheckedTrackColor = DarkSlateElevated
              )
            )
          }
        }
      }

      // Enter Hotaji PAIOS Button
      Button(
        onClick = {
          onCompleteOnboarding(
            UserProfileEntity(
              id = 1,
              fullName = fullName.ifBlank { "Indrajit Hota" },
              email = email.ifBlank { "indrajithota5@gmail.com" },
              gender = selectedGender,
              isOnboarded = true,
              privacyEncryptionEnabled = encryptionEnabled
            )
          )
        },
        colors = ButtonDefaults.buttonColors(
          containerColor = AestheticGold,
          contentColor = ObsidianBlack
        ),
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .border(1.dp, MetallicGoldLight, RoundedCornerShape(28.dp))
          .testTag("complete_onboarding_button")
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = ObsidianBlack)
          Text(
            text = "Launch Hotaji PAIOS",
            fontWeight = FontWeight.Black,
            fontSize = 15.sp,
            color = ObsidianBlack
          )
        }
      }
    }
  }
}

@Composable
private fun GenderOptionButton(
  title: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  isSelected: Boolean,
  modifier: Modifier = Modifier,
  onClick: () -> Unit
) {
  val bg = if (isSelected) AestheticGold.copy(alpha = 0.2f) else DarkSlateGlass
  val border = if (isSelected) AestheticGold else DarkSlateBorder

  Column(
    modifier = modifier
      .clip(RoundedCornerShape(10.dp))
      .background(bg)
      .border(1.dp, border, RoundedCornerShape(10.dp))
      .clickable { onClick() }
      .padding(vertical = 12.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(4.dp)
  ) {
    Icon(
      imageVector = icon,
      contentDescription = title,
      tint = if (isSelected) AestheticGold else SoftAqua,
      modifier = Modifier.size(20.dp)
    )
    Text(
      text = title,
      fontSize = 12.sp,
      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
      color = if (isSelected) PureWhite else SlateMuted
    )
  }
}
