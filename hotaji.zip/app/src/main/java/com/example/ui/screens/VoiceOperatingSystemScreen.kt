package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ai.AgentType
import com.example.data.ai.EpistemicParser
import com.example.data.ai.EpistemicSegment
import com.example.data.local.UserProfileEntity
import com.example.data.repository.HotajiRepository
import com.example.data.voice.VoiceAvatar
import com.example.data.voice.VoiceEngine
import com.example.ui.components.EpistemicBadge
import com.example.ui.components.EpistemicResponseView
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.OrbState
import com.example.ui.components.VoiceOrb
import com.example.ui.theme.AestheticGold
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateElevated
import com.example.ui.theme.DarkSlateGlass
import com.example.ui.theme.MetallicGoldLight
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OceanBlue
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateMuted
import com.example.ui.theme.SoftAqua
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun VoiceOperatingSystemScreen(
  repository: HotajiRepository,
  voiceEngine: VoiceEngine,
  profile: UserProfileEntity,
  onSafetyTrigger: () -> Unit,
  modifier: Modifier = Modifier
) {
  val coroutineScope = rememberCoroutineScope()
  var isVoiceActive by remember { mutableStateOf(false) }
  var orbState by remember { mutableStateOf(OrbState.IDLE) }
  var userSpeechTranscript by remember { mutableStateOf("") }
  var activeAiResponse by remember {
    mutableStateOf(
      "[FACT] Hotaji Live Voice OS is active and listening with high-cadence modulation. [INTERPRETATION] Speak in Odia (ଓଡ଼ିଆ), Hindi, or English to begin real-time consultation."
    )
  }
  var parsedSegments by remember { mutableStateOf(EpistemicParser.parseEpistemicTags(activeAiResponse)) }

  val currentAvatar by voiceEngine.currentAvatar.collectAsState()
  val isSpeaking by voiceEngine.isSpeaking.collectAsState()

  LaunchedEffect(isSpeaking) {
    if (isSpeaking) {
      orbState = OrbState.SPEAKING
    } else if (isVoiceActive) {
      orbState = OrbState.LISTENING
    } else {
      orbState = OrbState.IDLE
    }
  }

  fun handleUserQuery(query: String) {
    if (query.isBlank()) return

    if (EpistemicParser.checkSafetyViolation(query)) {
      onSafetyTrigger()
      return
    }

    userSpeechTranscript = query
    orbState = OrbState.THINKING

    coroutineScope.launch {
      delay(400)
      val responseText = repository.getAiResponse(
        agent = AgentType.PERSONAL_LIFE,
        query = query,
        languageName = profile.selectedLanguage
      )
      activeAiResponse = responseText
      parsedSegments = EpistemicParser.parseEpistemicTags(responseText)

      // Speak response through VoiceEngine
      val langCode = if (profile.selectedLanguage.contains("Odia")) "or" else if (profile.selectedLanguage.contains("Hindi")) "hi" else "en"
      // Strip bracket tags before speaking
      val cleanSpeechText = responseText.replace(Regex("""\[.*?\]"""), "").trim()
      voiceEngine.speak(cleanSpeechText, langCode)
    }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(ObsidianBlack)
      .padding(horizontal = 16.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState()),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Spacer(modifier = Modifier.height(6.dp))

      // Top Header Callout
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "Hotaji Live Voice OS",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Black,
            color = PureWhite
          )
          Text(
            text = "Native Multi-Accent Modulation • Odia (ମୁଖ୍ୟ ଫୋକସ୍)",
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = SoftAqua
          )
        }

        // Live Mode Indicator
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (isVoiceActive) AestheticGold.copy(alpha = 0.2f) else DarkSlateGlass)
            .border(1.dp, if (isVoiceActive) AestheticGold else DarkSlateBorder, RoundedCornerShape(20.dp))
            .padding(horizontal = 10.dp, vertical = 5.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Box(
              modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (isVoiceActive) AestheticGold else SlateMuted)
            )
            Text(
              text = if (isVoiceActive) "LIVE" else "STANDBY",
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = if (isVoiceActive) AestheticGold else SlateMuted
            )
          }
        }
      }

      // Voice Avatar Selection Carousel (Paging & Dot Indicators)
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "SELECT VOICE AVATAR (9 REGIONAL PERSONAS)",
            fontSize = 10.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp,
            color = SlateMuted
          )
          Text(
            text = "Active: ${currentAvatar.displayName} (${currentAvatar.trait})",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = AestheticGold
          )
        }

        LazyRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          contentPadding = PaddingValues(horizontal = 2.dp)
        ) {
          items(VoiceAvatar.values()) { avatar ->
            val isSelected = avatar == currentAvatar
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(if (isSelected) DarkSlateElevated else DarkSlateGlass)
                .border(1.dp, if (isSelected) AestheticGold else DarkSlateBorder, RoundedCornerShape(12.dp))
                .clickable {
                  voiceEngine.setAvatar(avatar)
                  voiceEngine.playSuccessSound()
                  val introText = "Avatar ${avatar.displayName} activated. ${avatar.voiceDescription}"
                  voiceEngine.speak(introText, "en")
                }
                .padding(horizontal = 12.dp, vertical = 8.dp)
                .testTag("avatar_chip_${avatar.id}")
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                  text = avatar.displayName,
                  fontSize = 12.sp,
                  fontWeight = if (isSelected) FontWeight.Black else FontWeight.SemiBold,
                  color = if (isSelected) PureWhite else OffWhite()
                )
                Text(
                  text = avatar.trait,
                  fontSize = 9.sp,
                  color = if (isSelected) SoftAqua else SlateMuted
                )
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(4.dp))

      // Central Voice Orb with Breathing 3D Glowing Animation
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
      ) {
        VoiceOrb(
          state = orbState,
          size = 200.dp,
          onClick = {
            isVoiceActive = !isVoiceActive
            if (isVoiceActive) {
              orbState = OrbState.LISTENING
              voiceEngine.playSuccessSound()
              handleUserQuery("ନମସ୍କାର Hotaji, explain today's prime focus in Odia and English.")
            } else {
              orbState = OrbState.IDLE
              voiceEngine.stop()
            }
          }
        )
      }

      // Elevation Pill "Start Voice" CTA
      Button(
        onClick = {
          isVoiceActive = !isVoiceActive
          if (isVoiceActive) {
            orbState = OrbState.LISTENING
            voiceEngine.playSuccessSound()
            handleUserQuery("Hello Hotaji, I am ready for our daily briefing.")
          } else {
            orbState = OrbState.IDLE
            voiceEngine.stop()
          }
        },
        colors = ButtonDefaults.buttonColors(
          containerColor = if (isVoiceActive) OceanBlue else AestheticGold,
          contentColor = if (isVoiceActive) PureWhite else ObsidianBlack
        ),
        shape = RoundedCornerShape(30.dp),
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .border(1.5.dp, MetallicGoldLight, RoundedCornerShape(30.dp))
          .testTag("start_voice_cta")
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(
            imageVector = if (isVoiceActive) Icons.Default.MicOff else Icons.Default.Mic,
            contentDescription = null,
            tint = if (isVoiceActive) PureWhite else ObsidianBlack
          )
          Text(
            text = if (isVoiceActive) "PAUSE VOICE STREAM" else "START VOICE (PAIOS LIVE)",
            fontWeight = FontWeight.Black,
            fontSize = 14.sp,
            letterSpacing = 0.5.sp,
            color = if (isVoiceActive) PureWhite else ObsidianBlack
          )
        }
      }

      // Quick Starter Prompt Chips
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(horizontal = 2.dp)
      ) {
        val samplePrompts = listOf(
          "କଳାହାଣ୍ଡି ଓ ଓଡ଼ିଶାର ଐତିହ୍ୟ କୁହ",
          "ବର୍ଣ୍ଣବୋଧର ମହତ୍ତ୍ୱ କ'ଣ?",
          "Explain quantum entanglement",
          "Give me a 6-month budget blueprint",
          "Draft an executive strategy memo"
        )
        items(samplePrompts) { prompt ->
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(16.dp))
              .background(DarkSlateGlass)
              .border(1.dp, DarkSlateBorder, RoundedCornerShape(16.dp))
              .clickable { handleUserQuery(prompt) }
              .padding(horizontal = 12.dp, vertical = 6.dp)
          ) {
            Text(
              text = prompt,
              fontSize = 11.sp,
              fontWeight = FontWeight.Medium,
              color = SoftAqua
            )
          }
        }
      }

      // Epistemic Subtitle / Response Output Card
      GlassmorphicCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = if (isSpeaking) AestheticGold else DarkSlateBorder,
        highlightGold = isSpeaking
      ) {
        Column(
          modifier = Modifier.padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Icon(
                imageVector = Icons.Default.GraphicEq,
                contentDescription = null,
                tint = AestheticGold,
                modifier = Modifier.size(16.dp)
              )
              Text(
                text = "Live Epistemic Subtitles",
                style = MaterialTheme.typography.titleMedium,
                fontSize = 13.sp,
                color = PureWhite
              )
            }
            if (isSpeaking) {
              Text(
                text = "SPEAKING...",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = AestheticGold
              )
            }
          }

          EpistemicResponseView(segments = parsedSegments)
        }
      }

      // Manual Query Input Field for hybrid text/voice mode
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        var textInput by remember { mutableStateOf("") }

        OutlinedTextField(
          value = textInput,
          onValueChange = { textInput = it },
          placeholder = { Text("Speak or type prompt for Hotaji...", color = SlateMuted, fontSize = 13.sp) },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = AestheticGold,
            unfocusedBorderColor = DarkSlateBorder,
            focusedTextColor = PureWhite,
            unfocusedTextColor = PureWhite,
            focusedContainerColor = DarkSlateGlass,
            unfocusedContainerColor = DarkSlateGlass
          ),
          shape = RoundedCornerShape(24.dp),
          modifier = Modifier
            .weight(1f)
            .testTag("voice_text_query_input")
        )

        IconButton(
          onClick = {
            if (textInput.isNotBlank()) {
              val q = textInput
              textInput = ""
              handleUserQuery(q)
            }
          },
          modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(AestheticGold)
            .testTag("send_voice_query_button")
        ) {
          Icon(
            imageVector = Icons.Default.Send,
            contentDescription = "Send Query",
            tint = ObsidianBlack,
            modifier = Modifier.size(20.dp)
          )
        }
      }
    }
  }
}

private fun OffWhite(): Color = PureWhite.copy(alpha = 0.85f)
